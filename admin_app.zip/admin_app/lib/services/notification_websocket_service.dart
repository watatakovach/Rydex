import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';

class NotificationWebSocketService {
  WebSocketChannel? _channel;

  void connect({
    required int userId,
    required String token,
    required String baseUrl,
    required void Function(Map<String, dynamic>) onNotification,
    void Function(Object error)? onError,
    void Function()? onDone,
  }) {
    disconnect();

    final wsScheme = baseUrl.startsWith('https') ? 'wss' : 'ws';
    final hostPort = baseUrl.replaceAll(RegExp(r'^https?://'), '');

    final uri = Uri.parse(
      '$wsScheme://$hostPort/notifications/ws/$userId?token=${Uri.encodeComponent(token)}',
    );

    _channel = WebSocketChannel.connect(uri);

    _channel!.stream.listen(
      (message) {
        try {
          final decoded = jsonDecode(message);
          if (decoded is Map) {
            onNotification(Map<String, dynamic>.from(decoded));
          }
        } catch (e) {
          onError?.call(e);
        }
      },
      onError: onError,
      onDone: onDone,
      cancelOnError: false,
    );
  }

  void disconnect() {
    _channel?.sink.close();
    _channel = null;
  }
}
