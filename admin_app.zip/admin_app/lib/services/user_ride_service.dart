import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/user_ride.dart';

class UserRideService {
  static const String baseUrl = "http://10.0.2.2:8000";

  Future<List<UserRide>> getUserRides({
    required String token,
    required int userId,
  }) async {
    final response = await http.get(
      Uri.parse("$baseUrl/admin/users/$userId/rides"),
      headers: {
        "Authorization": "Bearer $token",
        "Content-Type": "application/json",
      },
    );

    if (response.statusCode != 200) {
      throw Exception("Failed to load ride history");
    }

    final List data = jsonDecode(response.body);

    return data
        .map((ride) => UserRide.fromJson(ride))
        .toList();
  }
}