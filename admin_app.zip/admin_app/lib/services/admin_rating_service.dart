import 'dart:convert';

import 'package:http/http.dart' as http;

import '../core/admin_config.dart';
import 'auth_service.dart';

class AdminRatingService {

  static Future<List<dynamic>> getDriverRatings(
      int driverId) async {

    final token = await AuthService.getToken();

    final response = await http.get(
      Uri.parse(
        "${AdminConfig.baseUrl}/admin/ratings/$driverId",
      ),
      headers: {
        "Authorization": "Bearer $token",
      },
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }

    throw Exception(
      "Failed to load driver ratings",
    );
  }


  static Future<Map<String, dynamic>>
      getDriverRatingSummary(
      int driverId) async {

    final token = await AuthService.getToken();

    final response = await http.get(
      Uri.parse(
        "${AdminConfig.baseUrl}/admin/ratings/$driverId/summary",
      ),
      headers: {
        "Authorization": "Bearer $token",
      },
    );


    if (response.statusCode == 200) {

      return jsonDecode(response.body);

    }


    throw Exception(
      "Failed to load rating summary",
    );
  }
}