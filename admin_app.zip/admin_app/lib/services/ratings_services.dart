import 'dart:convert';

import 'package:http/http.dart' as http;

import '../core/admin_config.dart';
import '../models/driver_rating.dart';
import 'auth_service.dart';

class RatingsService {
  static Future<Map<String, String>> _headers() async {
    final token = await AuthService.getToken();

    return {
      "Authorization": "Bearer $token",
      "Content-Type": "application/json",
    };
  }

  static Future<DriverRatingSummary>
      getPlatformRatings() async {
    final response = await http.get(
      Uri.parse(
        "${AdminConfig.baseUrl}/ratings/admin",
      ),
      headers: await _headers(),
    );

    if (response.statusCode != 200) {
      throw Exception(
        "Failed to load ratings",
      );
    }

    return DriverRatingSummary.fromJson(
      jsonDecode(response.body),
    );
  }

  static Future<List<DriverRating>>
      getDriverReviews(
    int driverId,
  ) async {
    final response = await http.get(
      Uri.parse(
        "${AdminConfig.baseUrl}/ratings/driver/$driverId",
      ),
      headers: await _headers(),
    );

    if (response.statusCode != 200) {
      throw Exception(
        "Unable to fetch driver reviews",
      );
    }

    final data = jsonDecode(response.body);

    return (data as List)
        .map(
          (e) => DriverRating.fromJson(e),
        )
        .toList();
  }
}