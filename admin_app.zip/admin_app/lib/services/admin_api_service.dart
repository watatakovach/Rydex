
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../core/admin_config.dart';

class AdminApiService {
  // ==========================================================
  // BASE URL
  // ==========================================================

  static String get baseUrl => AdminConfig.baseUrl;

  // Android Emulator:
  // static const String baseUrl = "http://10.0.2.2:8000";

  // Physical Android Device:
  // static const String baseUrl = "http://192.168.1.XXX:8000";

  String? _token;

  // ==========================================================
  // AUTH TOKEN
  // ==========================================================

  void setToken(String token) {
    _token = token;
    print("ADMIN TOKEN SET: ${_token != null}");
  }

  void clearToken() {
    _token = null;
  }

  String? get token => _token;

  Map<String, String> get _headers {
    final headers = <String, String>{
      "Content-Type": "application/json",
      "Accept": "application/json",
    };

    if (_token != null && _token!.isNotEmpty) {
      headers["Authorization"] = "Bearer $_token";
    }

    return headers;
  }

  // ==========================================================
  // LOGIN
  // ==========================================================

  Future<Map<String, dynamic>> login({
    required String username,
    required String password,
  }) async {
    final response = await http.post(
      Uri.parse("$baseUrl/auth/login"),
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: {
        "username": username,
        "password": password,
      },
    );

    print("LOGIN STATUS: ${response.statusCode}");
    print("LOGIN RESPONSE: ${response.body}");

    if (response.statusCode != 200) {
      throw Exception(
        "Login failed: ${response.body}",
      );
    }

    final data =
        jsonDecode(response.body) as Map<String, dynamic>;

    final accessToken = data["access_token"];

    if (accessToken == null ||
        accessToken.toString().isEmpty) {
      throw Exception(
        "Login succeeded but no access token was returned.",
      );
    }

    _token = accessToken.toString();

    print("ADMIN LOGIN SUCCESS");
    print("TOKEN STORED: true");

    return data;
  }

  // ==========================================================
  // USERS
  // ==========================================================

  Future<List<dynamic>> getUsers() async {
    final response = await http.get(
      Uri.parse("$baseUrl/admin/users"),
      headers: _headers,
    );

    _checkAuthResponse(response, "load users");

    return jsonDecode(response.body) as List<dynamic>;
  }

  // ==========================================================
  // USER DETAILS
  // ==========================================================

  Future<Map<String, dynamic>> getUser(int id) async {
    final response = await http.get(
      Uri.parse("$baseUrl/admin/users/$id"),
      headers: _headers,
    );

    _checkAuthResponse(response, "load user");

    return jsonDecode(response.body)
        as Map<String, dynamic>;
  }

  // ==========================================================
  // UPDATE USER STATUS
  // ==========================================================

  Future<Map<String, dynamic>> updateUserStatus({
    required int userId,
    required bool isActive,
  }) async {
    final response = await http.patch(
      Uri.parse(
        "$baseUrl/admin/users/$userId/status",
      ),
      headers: _headers,
      body: jsonEncode({
        "is_active": isActive,
      }),
    );

    _checkAuthResponse(response, "update user");

    return jsonDecode(response.body)
        as Map<String, dynamic>;
  }

  // ==========================================================
  // DASHBOARD STATS
  // ==========================================================

  Future<Map<String, dynamic>> getDashboardStats() async {
    final response = await http.get(
      Uri.parse(
        "$baseUrl/admin/dashboard/stats",
      ),
      headers: _headers,
    );

    _checkAuthResponse(response, "load dashboard");

    return jsonDecode(response.body)
        as Map<String, dynamic>;
  }

  // ==========================================================
  // DASHBOARD ANALYTICS
  // ==========================================================

  Future<Map<String, dynamic>> getDashboardAnalytics() async {
    final response = await http.get(
      Uri.parse(
        "$baseUrl/admin/dashboard/analytics",
      ),
      headers: _headers,
    );

    _checkAuthResponse(response, "load analytics");

    return jsonDecode(response.body)
        as Map<String, dynamic>;
  }

  // ==========================================================
  // RIDES
  // ==========================================================

  Future<List<dynamic>> getRides() async {
    final response = await http.get(
      Uri.parse("$baseUrl/admin/rides"),
      headers: _headers,
    );

    _checkAuthResponse(response, "load rides");

    return jsonDecode(response.body) as List<dynamic>;
  }

  // ==========================================================
  // RIDE DETAILS
  // ==========================================================

  Future<Map<String, dynamic>> getRideDetails(int id) async {
    final response = await http.get(
      Uri.parse("$baseUrl/admin/rides/$id"),
      headers: _headers,
    );

    _checkAuthResponse(response, "load ride");

    return jsonDecode(response.body)
        as Map<String, dynamic>;
  }

  // ==========================================================
  // CANCEL RIDE
  // ==========================================================

  Future<void> cancelRide(int id) async {
    final response = await http.patch(
      Uri.parse(
        "$baseUrl/admin/rides/$id/cancel",
      ),
      headers: _headers,
      body: jsonEncode({}),
    );

    _checkAuthResponse(response, "cancel ride");
  }

  // ==========================================================
  // COMPLETE RIDE
  // ==========================================================

  Future<void> completeRide(int id) async {
    final response = await http.patch(
      Uri.parse(
        "$baseUrl/admin/rides/$id/complete",
      ),
      headers: _headers,
      body: jsonEncode({}),
    );

    _checkAuthResponse(response, "complete ride");
  }

    // ==========================================================
  // ADMIN NOTIFICATIONS
  // ==========================================================

  Future<Map<String, dynamic>> getNotifications() async {
    final response = await http.get(
      Uri.parse("$baseUrl/admin/notifications"),
      headers: _headers,
    );

    _checkAuthResponse(
      response,
      "load notifications",
    );

    return jsonDecode(response.body)
        as Map<String, dynamic>;
  }

  // ==========================================================
  // NOTIFICATION DETAILS
  // ==========================================================

  Future<Map<String, dynamic>> getNotification(
    int notificationId,
  ) async {
    final response = await http.get(
      Uri.parse(
        "$baseUrl/admin/notifications/$notificationId",
      ),
      headers: _headers,
    );

    _checkAuthResponse(
      response,
      "load notification",
    );

    return jsonDecode(response.body)
        as Map<String, dynamic>;
  }

  // ==========================================================
  // SEND NOTIFICATION
  // ==========================================================

  Future<Map<String, dynamic>> createNotification({
    required int userId,
    required String type,
    required String title,
    required String message,
    String? entityType,
    int? entityId,
    Map<String, dynamic>? data,
  }) async {
    final response = await http.post(
      Uri.parse("$baseUrl/admin/notifications"),
      headers: _headers,
      body: jsonEncode({
        "user_id": userId,
        "type": type,
        "title": title,
        "message": message,
        "entity_type": entityType,
        "entity_id": entityId,
        "data": data,
      }),
    );

    _checkAuthResponse(
      response,
      "create notification",
    );

    return jsonDecode(response.body)
        as Map<String, dynamic>;
  }

  // ==========================================================
  // BROADCAST NOTIFICATION
  // ==========================================================

  Future<Map<String, dynamic>> broadcastNotification({
    required String type,
    required String title,
    required String message,
    String? entityType,
    int? entityId,
    Map<String, dynamic>? data,
  }) async {
    final response = await http.post(
      Uri.parse(
        "$baseUrl/admin/notifications/broadcast",
      ),
      headers: _headers,
      body: jsonEncode({
        "type": type,
        "title": title,
        "message": message,
        "entity_type": entityType,
        "entity_id": entityId,
        "data": data,
      }),
    );

    _checkAuthResponse(
      response,
      "broadcast notification",
    );

    return jsonDecode(response.body)
        as Map<String, dynamic>;
  }

  // ==========================================================
  // MARK NOTIFICATION READ
  // ==========================================================

  Future<void> markNotificationRead(
    int notificationId,
  ) async {
    final response = await http.patch(
      Uri.parse(
        "$baseUrl/admin/notifications/$notificationId/read",
      ),
      headers: _headers,
      body: jsonEncode({}),
    );

    _checkAuthResponse(
      response,
      "mark notification as read",
    );
  }

  // ==========================================================
  // MARK ALL NOTIFICATIONS READ
  // ==========================================================

  Future<void> markAllNotificationsRead() async {
    final response = await http.patch(
      Uri.parse(
        "$baseUrl/admin/notifications/read-all",
      ),
      headers: _headers,
      body: jsonEncode({}),
    );

    _checkAuthResponse(
      response,
      "mark all notifications as read",
    );
  }

  // ==========================================================
  // DELETE NOTIFICATION
  // ==========================================================

  Future<void> deleteNotification(
    int notificationId,
  ) async {
    final response = await http.delete(
      Uri.parse(
        "$baseUrl/admin/notifications/$notificationId",
      ),
      headers: _headers,
    );

    _checkAuthResponse(
      response,
      "delete notification",
    );
  }

  // ==========================================================
  // DRIVERS
  // ==========================================================

  Future<List<dynamic>> getDrivers() async {
    final response = await http.get(
      Uri.parse("$baseUrl/admin/drivers"),
      headers: _headers,
    );

    _checkAuthResponse(response, "load drivers");

    return jsonDecode(response.body) as List<dynamic>;
  }

  // ==========================================================
  // DRIVER DETAILS
  // ==========================================================

  Future<Map<String, dynamic>> getDriverDetails(int id) async {
    final response = await http.get(
      Uri.parse("$baseUrl/admin/drivers/$id"),
      headers: _headers,
    );

    _checkAuthResponse(response, "load driver");

    return jsonDecode(response.body)
        as Map<String, dynamic>;
  }

  // ==========================================================
  // DRIVER PERFORMANCE
  // ==========================================================

  Future<Map<String, dynamic>> getDriverPerformance(
    int driverId,
  ) async {
    final response = await http.get(
      Uri.parse(
        "$baseUrl/admin/drivers/$driverId/performance",
      ),
      headers: _headers,
    );

    _checkAuthResponse(
      response,
      "load driver performance",
    );

    return jsonDecode(response.body)
        as Map<String, dynamic>;
  }

  // ==========================================================
  // DRIVER EARNINGS
  // ==========================================================

  Future<Map<String, dynamic>> getDriverEarnings(
    int driverId,
  ) async {
    final response = await http.get(
      Uri.parse(
        "$baseUrl/admin/drivers/$driverId/earnings",
      ),
      headers: _headers,
    );

    _checkAuthResponse(
      response,
      "load driver earnings",
    );

    return jsonDecode(response.body)
        as Map<String, dynamic>;
  }

  // ==========================================================
  // PENDING DRIVERS
  // ==========================================================

  Future<List<dynamic>> getPendingDrivers() async {
    final response = await http.get(
      Uri.parse(
        "$baseUrl/admin/drivers/pending",
      ),
      headers: _headers,
    );

    _checkAuthResponse(
      response,
      "load pending drivers",
    );

    return jsonDecode(response.body) as List<dynamic>;
  }

  // ==========================================================
  // VERIFY DRIVER
  // ==========================================================

  Future<void> verifyDriver(
    int driverId, {
    bool isVerified = true,
  }) async {
    final response = await http.patch(
      Uri.parse(
        "$baseUrl/admin/drivers/$driverId/verify",
      ),
      headers: _headers,
      body: jsonEncode({
        "is_verified": isVerified,
      }),
    );

    _checkAuthResponse(
      response,
      "verify driver",
    );
  }

  // ==========================================================
  // UPDATE DRIVER STATUS
  // ==========================================================

  Future<void> updateDriverStatus({
    required int driverId,
    required bool isActive,
  }) async {
    final response = await http.patch(
      Uri.parse(
        "$baseUrl/admin/drivers/$driverId/status",
      ),
      headers: _headers,
      body: jsonEncode({
        "is_active": isActive,
      }),
    );

    _checkAuthResponse(
      response,
      "update driver status",
    );
  }

  // ==========================================================
  // CREATE DRIVER
  // ==========================================================

  Future<Map<String, dynamic>> createDriver({
    required int userId,
    required String licenseNumber,
  }) async {
    final response = await http.post(
      Uri.parse("$baseUrl/admin/drivers"),
      headers: _headers,
      body: jsonEncode({
        "user_id": userId,
        "license_number": licenseNumber,
      }),
    );

    _checkAuthResponse(
      response,
      "create driver",
    );

    return jsonDecode(response.body)
        as Map<String, dynamic>;
  }

  // ==========================================================
  // PASSENGERS
  // ==========================================================

  Future<List<dynamic>> getPassengers() async {
    final response = await http.get(
      Uri.parse("$baseUrl/admin/passengers"),
      headers: _headers,
    );

    _checkAuthResponse(
      response,
      "load passengers",
    );

    return jsonDecode(response.body) as List<dynamic>;
  }

  // ==========================================================
  // PASSENGER DETAILS
  // ==========================================================

  Future<Map<String, dynamic>> getPassengerDetails(
    int userId,
  ) async {
    final response = await http.get(
      Uri.parse("$baseUrl/admin/users/$userId"),
      headers: _headers,
    );

    _checkAuthResponse(
      response,
      "load passenger details",
    );

    return jsonDecode(response.body)
        as Map<String, dynamic>;
  }

  // ==========================================================
  // UPDATE PASSENGER STATUS
  // ==========================================================

  Future<Map<String, dynamic>> updatePassengerStatus({
    required int userId,
    required bool isActive,
  }) async {
    final response = await http.patch(
      Uri.parse(
        "$baseUrl/admin/users/$userId/status",
      ),
      headers: _headers,
      body: jsonEncode({
        "is_active": isActive,
      }),
    );

    _checkAuthResponse(
      response,
      "update passenger status",
    );

    return jsonDecode(response.body)
        as Map<String, dynamic>;
  }

  // ==========================================================
  // PASSENGER RIDE HISTORY
  // ==========================================================

  Future<List<dynamic>> getPassengerRides(
    int userId,
  ) async {
    final response = await http.get(
      Uri.parse(
        "$baseUrl/admin/users/$userId/rides",
      ),
      headers: _headers,
    );

    _checkAuthResponse(
      response,
      "load passenger rides",
    );

    return jsonDecode(response.body)
        as List<dynamic>;
  }

  // ==========================================================
  // PASSENGER CANCELLATION HISTORY
  // ==========================================================

  Future<List<dynamic>> getPassengerCancellations(
    int userId,
  ) async {
    final response = await http.get(
      Uri.parse(
        "$baseUrl/admin/users/$userId/cancellations",
      ),
      headers: _headers,
    );

    _checkAuthResponse(
      response,
      "load passenger cancellations",
    );

    return jsonDecode(response.body)
        as List<dynamic>;
  }

  // ==========================================================
  // DRIVER PAYMENT HISTORY
  // ==========================================================

  Future<List<dynamic>> getDriverPaymentHistory(
    int userId,
  ) async {
    final response = await http.get(
      Uri.parse(
        "$baseUrl/admin/users/$userId/payments",
      ),
      headers: _headers,
    );

    _checkAuthResponse(
      response,
      "load driver payments",
    );

    return jsonDecode(response.body)
        as List<dynamic>;
  }

  // ==========================================================
  // ALL USERS
  // ==========================================================

  Future<List<dynamic>> getAllUsers({
    String? search,
    String? statusFilter,
    String? role,
    bool newUsers = false,
  }) async {
    final queryParameters = <String, String>{};

    if (search != null && search.trim().isNotEmpty) {
      queryParameters["search"] = search.trim();
    }

    if (statusFilter != null &&
        statusFilter.trim().isNotEmpty) {
      queryParameters["status_filter"] =
          statusFilter.trim();
    }

    if (role != null && role.trim().isNotEmpty) {
      queryParameters["role"] = role.trim();
    }

    if (newUsers) {
      queryParameters["new_users"] = "true";
    }

    final uri = Uri.parse(
      "$baseUrl/admin/users",
    ).replace(
      queryParameters: queryParameters.isEmpty
          ? null
          : queryParameters,
    );

    final response = await http.get(
      uri,
      headers: _headers,
    );

    _checkAuthResponse(
      response,
      "load all users",
    );

    return jsonDecode(response.body) as List<dynamic>;
  }

  // ==========================================================
  // USER DETAILS
  // ==========================================================

  Future<Map<String, dynamic>> getUserDetails(
    int userId,
  ) async {
    final response = await http.get(
      Uri.parse(
        "$baseUrl/admin/users/$userId",
      ),
      headers: _headers,
    );

    _checkAuthResponse(
      response,
      "load user details",
    );

    return jsonDecode(response.body)
        as Map<String, dynamic>;
  }

  // ==========================================================
  // USER RIDE HISTORY
  // ==========================================================

  Future<List<dynamic>> getUserRides(
    int userId,
  ) async {
    final response = await http.get(
      Uri.parse(
        "$baseUrl/admin/users/$userId/rides",
      ),
      headers: _headers,
    );

    _checkAuthResponse(
      response,
      "load user rides",
    );

    return jsonDecode(response.body)
        as List<dynamic>;
  }

  // ==========================================================
  // USER CANCELLATION HISTORY
  // ==========================================================

  Future<List<dynamic>> getUserCancellations(
    int userId,
  ) async {
    final response = await http.get(
      Uri.parse(
        "$baseUrl/admin/users/$userId/cancellations",
      ),
      headers: _headers,
    );

    _checkAuthResponse(
      response,
      "load user cancellations",
    );

    return jsonDecode(response.body)
        as List<dynamic>;
  }

  // ==========================================================
  // USER PAYMENT HISTORY
  // ==========================================================

  Future<List<dynamic>> getUserPayments(
    int userId,
  ) async {
    final response = await http.get(
      Uri.parse(
        "$baseUrl/admin/users/$userId/payments",
      ),
      headers: _headers,
    );

    _checkAuthResponse(
      response,
      "load user payments",
    );

    return jsonDecode(response.body)
        as List<dynamic>;
  }

  // ==========================================================
  // UPDATE USER STATUS
  // ==========================================================

  Future<Map<String, dynamic>> updateUserAccountStatus({
    required int userId,
    required bool isActive,
  }) async {
    final response = await http.patch(
      Uri.parse(
        "$baseUrl/admin/users/$userId/status",
      ),
      headers: _headers,
      body: jsonEncode({
        "is_active": isActive,
      }),
    );

    _checkAuthResponse(
      response,
      "update user account status",
    );

    return jsonDecode(response.body)
        as Map<String, dynamic>;
  }



  // ==========================================================
// ADMIN SETTINGS
// ==========================================================

Future<Map<String, dynamic>> getSettings() async {
  final response = await http.get(
    Uri.parse("$baseUrl/admin/settings"),
    headers: _headers,
  );

  _checkAuthResponse(
    response,
    "load admin settings",
  );

  return jsonDecode(response.body)
      as Map<String, dynamic>;
}


// ==========================================================
// UPDATE ADMIN SETTINGS
// ==========================================================

Future<Map<String, dynamic>> updateSettings({
  required Map<String, dynamic> settings,
}) async {
  final response = await http.patch(
    Uri.parse("$baseUrl/admin/settings"),
    headers: _headers,
    body: jsonEncode(settings),
  );

  _checkAuthResponse(
    response,
    "update admin settings",
  );

  return jsonDecode(response.body)
      as Map<String, dynamic>;
}


// ==========================================================
// RESET ADMIN SETTINGS
// ==========================================================

Future<Map<String, dynamic>> resetSettings() async {
  final response = await http.post(
    Uri.parse("$baseUrl/admin/settings/reset"),
    headers: _headers,
  );

  _checkAuthResponse(
    response,
    "reset admin settings",
  );

  return jsonDecode(response.body)
      as Map<String, dynamic>;
}

  // ==========================================================
  // AUTH RESPONSE CHECK
  // ==========================================================

  void _checkAuthResponse(
    http.Response response,
    String action,
  ) {
    if (response.statusCode == 401) {
      print("==========================================");
      print("AUTHENTICATION FAILED");
      print("ACTION: $action");
      print("TOKEN EXISTS: ${_token != null}");
      print(
        "TOKEN EMPTY: ${_token == null || _token!.isEmpty}",
      );
      print("RESPONSE: ${response.body}");
      print("==========================================");

      throw Exception(
        "Authentication failed. Please login again.",
      );
    }

    if (response.statusCode == 403) {
      print("==========================================");
      print("ADMIN PERMISSION DENIED");
      print("ACTION: $action");
      print("RESPONSE: ${response.body}");
      print("==========================================");

      throw Exception(
        "You do not have permission to perform this action.",
      );
    }

    if (response.statusCode < 200 ||
        response.statusCode >= 300) {
      throw Exception(
        "Failed to $action: ${response.body}",
      );
    }
  }
}
