import 'dart:convert';

import 'package:http/http.dart' as http;

import '../core/admin_config.dart';
import '../models/admin_user.dart';
import '../models/user_payment.dart';
import '../models/user_ride.dart';
import '../models/user_complaint.dart';

class AdminUserService {
  static String get baseUrl => AdminConfig.baseUrl;

  // ============================================================
  // GET ALL USERS
  // ============================================================

  Future<List<AdminUser>> getUsers({
    required String token,
    String? search,
    String? role,
    String? statusFilter,
    bool? newUsers,
  }) async {
    final query = <String, String>{};

    if (search != null && search.trim().isNotEmpty) {
      query["search"] = search.trim();
    }

    if (role != null && role.isNotEmpty) {
      query["role"] = role;
    }

    if (statusFilter != null && statusFilter.isNotEmpty) {
      query["status_filter"] = statusFilter;
    }

    if (newUsers == true) {
      query["new_users"] = "true";
    }

    final uri = Uri.parse(
      "$baseUrl/admin/users",
    ).replace(
      queryParameters: query.isEmpty ? null : query,
    );

    final response = await http.get(
      uri,
      headers: {
        "Authorization": "Bearer $token",
        "Accept": "application/json",
      },
    );

    if (response.statusCode != 200) {
      throw Exception("Failed to load users");
    }

    final List<dynamic> data = jsonDecode(response.body);

    return data
        .map(
          (e) => AdminUser.fromJson(
            e as Map<String, dynamic>,
          ),
        )
        .toList();
  }

  // ============================================================
  // GET USER DETAILS
  // ============================================================

  Future<AdminUser> getUser({
    required String token,
    required int userId,
  }) async {
    final response = await http.get(
      Uri.parse("$baseUrl/admin/users/$userId"),
      headers: {
        "Authorization": "Bearer $token",
        "Accept": "application/json",
      },
    );

    if (response.statusCode != 200) {
      throw Exception("Failed to load user");
    }

    return AdminUser.fromJson(
      jsonDecode(response.body),
    );
  }

  // ============================================================
  // USER RIDE HISTORY
  // ============================================================

  Future<List<UserRide>> getUserRides({
    required String token,
    required int userId,
  }) async {
    final response = await http.get(
      Uri.parse("$baseUrl/admin/users/$userId/rides"),
      headers: {
        "Authorization": "Bearer $token",
        "Content-Type": "application/json",
      },
    );

    if (response.statusCode != 200) {
      throw Exception("Failed to load ride history");
    }

    final List data = jsonDecode(response.body);

    return data
        .map((e) => UserRide.fromJson(e))
        .toList();
  }

  // ============================================================
  // USER PAYMENT HISTORY
  // ============================================================

  Future<List<UserPayment>> getUserPayments({
    required String token,
    required int userId,
  }) async {
    final response = await http.get(
      Uri.parse("$baseUrl/admin/users/$userId/payments"),
      headers: {
        "Authorization": "Bearer $token",
        "Content-Type": "application/json",
      },
    );

    if (response.statusCode != 200) {
      throw Exception("Failed to load payment history");
    }

    final List data = jsonDecode(response.body);

    return data
        .map((e) => UserPayment.fromJson(e))
        .toList();
  }

  // ============================================================
// USER COMPLAINTS
// ============================================================

Future<List<UserComplaint>> getUserComplaints({
  required String token,
  required int userId,
}) async {
  final response = await http.get(
    Uri.parse("$baseUrl/admin/users/$userId/complaints"),
    headers: {
      "Authorization": "Bearer $token",
      "Content-Type": "application/json",
    },
  );

  if (response.statusCode != 200) {
    throw Exception("Failed to load complaints");
  }

  final List data = jsonDecode(response.body);

  return data
      .map((e) => UserComplaint.fromJson(e))
      .toList();
}




  // ============================================================
  // UPDATE USER STATUS
  // ============================================================

  Future<void> updateUserStatus({
    required String token,
    required int userId,
    required bool isActive,
  }) async {
    final response = await http.patch(
      Uri.parse("$baseUrl/admin/users/$userId/status"),
      headers: {
        "Authorization": "Bearer $token",
        "Content-Type": "application/json",
        "Accept": "application/json",
      },
      body: jsonEncode({
        "is_active": isActive,
      }),
    );

    if (response.statusCode != 200) {
      throw Exception("Failed to update user status");
    }
  }
}