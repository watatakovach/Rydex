
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'providers/user_provider.dart';

import 'screens/auth/admin_login_screen.dart';
import 'features/screens/general_settings_screen.dart';
import 'screens/passengers/passengers_screen.dart';
import 'screens/verification/driver_verification_screen.dart';
import 'screens/drivers/drivers_screen.dart';
import 'screens/rides/rides_screen.dart';
import 'screens/notification/notification_screen.dart';

import 'services/admin_api_service.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => UserProvider(),
        ),
      ],
      child: const RydexAdminApp(),
    ),
  );
}

// ================================================================
// RYDEX ADMIN APP
// ================================================================

class RydexAdminApp extends StatelessWidget {
  const RydexAdminApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'RYDEX Admin',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.green,
        scaffoldBackgroundColor: const Color(0xFFF5F7FA),
        fontFamily: 'Arial',
      ),
      home: const AdminLoginScreen(),
    );
  }
}

// ================================================================
// ADMIN DASHBOARD
// ================================================================

class AdminDashboard extends StatefulWidget {
  final String adminToken;

  const AdminDashboard({
    super.key,
    required this.adminToken,
  });

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  final AdminApiService apiService = AdminApiService();

  // ================================================================
  // NAVIGATION
  // ================================================================

  int selectedIndex = 0;

  // ================================================================
  // DASHBOARD DATA
  // ================================================================

  Map<String, dynamic> dashboardStats = {};

  Map<String, dynamic> dashboardAnalytics = {};

  List<dynamic> recentRides = [];

  // ================================================================
  // LOADING STATES
  // ================================================================

  bool isDashboardLoading = true;

  bool isAnalyticsLoading = true;

  bool isRidesLoading = true;

  // ================================================================
  // ERROR STATES
  // ================================================================

  String? dashboardError;

  String? analyticsError;

  String? ridesError;

  // ================================================================
  // PAGE TITLES
  // ================================================================

  final List<String> pageTitles = [
    'Dashboard',
    'Drivers',
    'Driver Verification',
    'Passengers',
    'Rides',
    'Settings',
  ];

  // ================================================================
  // INIT
  // ================================================================

  @override
  void initState() {
    super.initState();

    apiService.setToken(widget.adminToken);

    _loadDashboard();
  }

  // ================================================================
  // LOAD COMPLETE DASHBOARD
  // ================================================================

  Future<void> _loadDashboard() async {
    await Future.wait([
      _loadDashboardStats(),
      _loadDashboardAnalytics(),
      _loadRecentRides(),
    ]);
  }

  // ================================================================
  // LOAD DASHBOARD STATISTICS
  // ================================================================

  Future<void> _loadDashboardStats() async {
    if (!mounted) return;

    setState(() {
      isDashboardLoading = true;
      dashboardError = null;
    });

    try {
      final data = await apiService.getDashboardStats();

      if (!mounted) return;

      setState(() {
        dashboardStats = data;
        isDashboardLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isDashboardLoading = false;
        dashboardError = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  // ================================================================
  // LOAD DASHBOARD ANALYTICS
  // ================================================================

  Future<void> _loadDashboardAnalytics() async {
    if (!mounted) return;

    setState(() {
      isAnalyticsLoading = true;
      analyticsError = null;
    });

    try {
      final data = await apiService.getDashboardAnalytics();

      if (!mounted) return;

      setState(() {
        dashboardAnalytics = data;
        isAnalyticsLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isAnalyticsLoading = false;
        analyticsError = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  // ================================================================
  // LOAD RECENT RIDES
  // ================================================================

  Future<void> _loadRecentRides() async {
    if (!mounted) return;

    setState(() {
      isRidesLoading = true;
      ridesError = null;
    });

    try {
      final rides = await apiService.getRides();

      if (!mounted) return;

      setState(() {
        recentRides = rides.take(5).toList();
        isRidesLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isRidesLoading = false;
        ridesError = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  // ================================================================
  // GET DASHBOARD STAT VALUE
  // ================================================================

  String _statValue(String key) {
    final value = dashboardStats[key];

    if (value == null) {
      return '0';
    }

    return value.toString();
  }

  // ================================================================
  // GET ANALYTICS VALUE
  // ================================================================

  String _analyticsValue(String key) {
    final value = dashboardAnalytics[key];

    if (value == null) {
      return '0';
    }

    return value.toString();
  }

  // ================================================================
  // BUILD
  // ================================================================

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final bool isMobile = constraints.maxWidth < 800;

        return Scaffold(
          backgroundColor: const Color(0xFFF5F7FA),

          // ----------------------------------------------------------
          // MOBILE DRAWER
          // ----------------------------------------------------------

          drawer: isMobile ? _buildMobileDrawer() : null,

          body: Row(
            children: [
              // ------------------------------------------------------
              // DESKTOP SIDEBAR
              // ------------------------------------------------------

              if (!isMobile) _buildSidebar(),

              // ------------------------------------------------------
              // MAIN CONTENT
              // ------------------------------------------------------

              Expanded(
                child: Column(
                  children: [
                    _buildTopBar(isMobile),

                    Expanded(
                      child: _buildPage(),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ================================================================
  // DESKTOP SIDEBAR
  // ================================================================

  Widget _buildSidebar() {
    return Container(
      width: 250,
      color: const Color(0xFF111827),
      child: Column(
        children: [
          const SizedBox(height: 30),

          // ----------------------------------------------------------
          // LOGO
          // ----------------------------------------------------------

          const Text(
            'RYDEX',
            style: TextStyle(
              color: Color(0xFFFFC107),
              fontSize: 28,
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
            ),
          ),

          const SizedBox(height: 5),

          const Text(
            'ADMINISTRATION',
            style: TextStyle(
              color: Colors.white54,
              fontSize: 11,
              letterSpacing: 2,
            ),
          ),

          const SizedBox(height: 40),

          // ----------------------------------------------------------
          // MENU
          // ----------------------------------------------------------

          _menuItem(
            icon: Icons.dashboard,
            title: 'Dashboard',
            index: 0,
          ),

          _menuItem(
            icon: Icons.drive_eta,
            title: 'Drivers',
            index: 1,
          ),

          _menuItem(
            icon: Icons.verified_user,
            title: 'Verification',
            index: 2,
          ),

          _menuItem(
            icon: Icons.people,
            title: 'Passengers',
            index: 3,
          ),

          _menuItem(
            icon: Icons.local_taxi,
            title: 'Rides',
            index: 4,
          ),

          const Spacer(),

          _menuItem(
            icon: Icons.settings,
            title: 'Settings',
            index: 5,
          ),

          const SizedBox(height: 15),

          // ----------------------------------------------------------
          // LOGOUT
          // ----------------------------------------------------------

          InkWell(
            onTap: _logout,
            borderRadius: BorderRadius.circular(10),
            child: Container(
              margin: const EdgeInsets.symmetric(
                horizontal: 10,
                vertical: 4,
              ),
              padding: const EdgeInsets.symmetric(
                horizontal: 15,
                vertical: 14,
              ),
              child: const Row(
                children: [
                  Icon(
                    Icons.logout,
                    color: Colors.redAccent,
                  ),
                  SizedBox(width: 15),
                  Text(
                    'Logout',
                    style: TextStyle(
                      color: Colors.redAccent,
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 15),

          // ----------------------------------------------------------
          // ADMIN PROFILE
          // ----------------------------------------------------------

          _buildSidebarProfile(),

          const SizedBox(height: 5),
        ],
      ),
    );
  }

  // ================================================================
  // SIDEBAR PROFILE
  // ================================================================

  Widget _buildSidebarProfile() {
    return Container(
      margin: const EdgeInsets.all(15),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(10),
      ),
      child: const Row(
        children: [
          CircleAvatar(
            radius: 20,
            child: Icon(Icons.person),
          ),

          SizedBox(width: 10),

          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Administrator',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),

              SizedBox(height: 3),

              Text(
                'Admin',
                style: TextStyle(
                  color: Colors.white54,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ================================================================
  // MOBILE DRAWER
  // ================================================================

  Widget _buildMobileDrawer() {
    return Drawer(
      backgroundColor: const Color(0xFF111827),
      child: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 25),

            const Text(
              'RYDEX',
              style: TextStyle(
                color: Color(0xFFFFC107),
                fontSize: 28,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
              ),
            ),

            const SizedBox(height: 5),

            const Text(
              'ADMINISTRATION',
              style: TextStyle(
                color: Colors.white54,
                fontSize: 11,
                letterSpacing: 2,
              ),
            ),

            const SizedBox(height: 35),

            _drawerMenuItem(
              icon: Icons.dashboard,
              title: 'Dashboard',
              index: 0,
            ),

            _drawerMenuItem(
              icon: Icons.drive_eta,
              title: 'Drivers',
              index: 1,
            ),

            _drawerMenuItem(
              icon: Icons.verified_user,
              title: 'Verification',
              index: 2,
            ),

            _drawerMenuItem(
              icon: Icons.people,
              title: 'Passengers',
              index: 3,
            ),

            _drawerMenuItem(
              icon: Icons.local_taxi,
              title: 'Rides',
              index: 4,
            ),

            _drawerMenuItem(
              icon: Icons.settings,
              title: 'Settings',
              index: 5,
            ),

            const Spacer(),

            // --------------------------------------------------------
            // MOBILE PROFILE
            // --------------------------------------------------------

            _buildSidebarProfile(),

            // --------------------------------------------------------
            // LOGOUT
            // --------------------------------------------------------

            InkWell(
              onTap: () {
                Navigator.pop(context);
                _logout();
              },
              child: Container(
                margin: const EdgeInsets.symmetric(
                  horizontal: 15,
                  vertical: 10,
                ),
                padding: const EdgeInsets.all(15),
                child: const Row(
                  children: [
                    Icon(
                      Icons.logout,
                      color: Colors.redAccent,
                    ),
                    SizedBox(width: 15),
                    Text(
                      'Logout',
                      style: TextStyle(
                        color: Colors.redAccent,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ================================================================
  // DRAWER MENU ITEM
  // ================================================================

  Widget _drawerMenuItem({
    required IconData icon,
    required String title,
    required int index,
  }) {
    final bool isSelected = selectedIndex == index;

    return InkWell(
      onTap: () {
        setState(() {
          selectedIndex = index;
        });

        Navigator.pop(context);

        if (index == 0) {
          _loadDashboard();
        }
      },
      child: Container(
        margin: const EdgeInsets.symmetric(
          horizontal: 12,
          vertical: 4,
        ),
        padding: const EdgeInsets.symmetric(
          horizontal: 15,
          vertical: 14,
        ),
        decoration: BoxDecoration(
          color: isSelected
              ? const Color(0xFFFFC107)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              size: 21,
              color: isSelected
                  ? const Color(0xFF111827)
                  : Colors.white70,
            ),

            const SizedBox(width: 14),

            Text(
              title,
              style: TextStyle(
                color: isSelected
                    ? const Color(0xFF111827)
                    : Colors.white70,
                fontSize: 14,
                fontWeight: isSelected
                    ? FontWeight.w800
                    : FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ================================================================
  // TOP BAR
  // ================================================================

  Widget _buildTopBar(bool isMobile) {
    return Container(
      height: 74,
      padding: EdgeInsets.symmetric(
        horizontal: isMobile ? 15 : 28,
      ),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(
          bottom: BorderSide(
            color: Color(0xFFE5E7EB),
          ),
        ),
      ),
      child: Row(
        children: [
          // ----------------------------------------------------------
          // MOBILE MENU BUTTON
          // ----------------------------------------------------------

          if (isMobile)
            Builder(
              builder: (context) {
                return Container(
                  margin: const EdgeInsets.only(right: 12),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF9FAFB),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: const Color(0xFFE5E7EB),
                    ),
                  ),
                  child: IconButton(
                    tooltip: 'Menu',
                    onPressed: () {
                      Scaffold.of(context).openDrawer();
                    },
                    icon: const Icon(
                      Icons.menu_rounded,
                    ),
                  ),
                );
              },
            ),

          // ----------------------------------------------------------
          // PAGE TITLE
          // ----------------------------------------------------------

          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  pageTitles[selectedIndex],
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: const Color(0xFF111827),
                    fontSize: isMobile ? 18 : 22,
                    fontWeight: FontWeight.w800,
                  ),
                ),

                const SizedBox(height: 2),

                if (!isMobile)
                  const Text(
                    'RYDEX OPERATIONS',
                    style: TextStyle(
                      color: Color(0xFF9CA3AF),
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.2,
                    ),
                  ),
              ],
            ),
          ),

          // ----------------------------------------------------------
          // REFRESH
          // ----------------------------------------------------------

          if (selectedIndex == 0)
            Container(
              margin: const EdgeInsets.only(right: 8),
              decoration: BoxDecoration(
                color: const Color(0xFFF9FAFB),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: const Color(0xFFE5E7EB),
                ),
              ),
              child: IconButton(
                tooltip: 'Refresh Dashboard',
                onPressed:
                    isDashboardLoading ||
                            isAnalyticsLoading ||
                            isRidesLoading
                        ? null
                        : _loadDashboard,
                icon: const Icon(
                  Icons.refresh_rounded,
                  size: 21,
                ),
              ),
            ),

          // ----------------------------------------------------------
          // NOTIFICATIONS
          // ----------------------------------------------------------

          Container(
            decoration: BoxDecoration(
              color: const Color(0xFFF9FAFB),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: const Color(0xFFE5E7EB),
              ),
            ),
            child: IconButton(
              tooltip: 'Notifications',
              onPressed: _openNotifications,
              icon: const Icon(
                Icons.notifications_none_rounded,
                size: 23,
                color: Color(0xFF374151),
              ),
            ),
          ),

          // ----------------------------------------------------------
          // DESKTOP PROFILE
          // ----------------------------------------------------------

          if (!isMobile) ...[
            const SizedBox(width: 14),
            _buildTopBarProfile(),
          ],
        ],
      ),
    );
  }

  // ================================================================
  // TOP BAR PROFILE
  // ================================================================

  Widget _buildTopBarProfile() {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 6,
      ),
      decoration: BoxDecoration(
        color: const Color(0xFFF9FAFB),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFFE5E7EB),
        ),
      ),
      child: const Row(
        children: [
          CircleAvatar(
            radius: 19,
            backgroundColor: Color(0xFFFFC107),
            child: Icon(
              Icons.person,
              color: Color(0xFF111827),
              size: 20,
            ),
          ),

          SizedBox(width: 9),

          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Administrator',
                style: TextStyle(
                  color: Color(0xFF111827),
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                ),
              ),

              SizedBox(height: 2),

              Text(
                'Admin',
                style: TextStyle(
                  color: Color(0xFF9CA3AF),
                  fontSize: 10,
                ),
              ),
            ],
          ),

          SizedBox(width: 5),

          Icon(
            Icons.keyboard_arrow_down_rounded,
            color: Color(0xFF6B7280),
            size: 18,
          ),
        ],
      ),
    );
  }

  // ================================================================
  // OPEN NOTIFICATIONS
  // ================================================================

  void _openNotifications() {
    debugPrint('🔔 NOTIFICATION BELL CLICKED');

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) {
          debugPrint('🔔 BUILDING NOTIFICATIONS SCREEN');

          return NotificationsScreen(
            token: widget.adminToken,
          );
        },
      ),
    );
  }

  // ================================================================
  // SIDEBAR MENU ITEM
  // ================================================================

  Widget _menuItem({
    required IconData icon,
    required String title,
    required int index,
  }) {
    final bool isSelected = selectedIndex == index;

    return InkWell(
      onTap: () {
        setState(() {
          selectedIndex = index;
        });

        if (index == 0) {
          _loadDashboard();
        }
      },
      borderRadius: BorderRadius.circular(10),
      child: Container(
        margin: const EdgeInsets.symmetric(
          horizontal: 12,
          vertical: 4,
        ),
        padding: const EdgeInsets.symmetric(
          horizontal: 15,
          vertical: 13,
        ),
        decoration: BoxDecoration(
          color: isSelected
              ? const Color(0xFFFFC107)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              size: 21,
              color: isSelected
                  ? const Color(0xFF111827)
                  : Colors.white70,
            ),

            const SizedBox(width: 14),

            Text(
              title,
              style: TextStyle(
                color: isSelected
                    ? const Color(0xFF111827)
                    : Colors.white70,
                fontSize: 14,
                fontWeight: isSelected
                    ? FontWeight.w800
                    : FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ================================================================
  // PAGE ROUTER
  // ================================================================

  Widget _buildPage() {
    switch (selectedIndex) {
      case 0:
        return _dashboard();

      case 1:
        return DriversScreen(
          token: widget.adminToken,
        );

      case 2:
        return DriverVerificationScreen(
          token: widget.adminToken,
        );

      case 3:
        return PassengersScreen(
          token: widget.adminToken,
        );

      case 4:
        return RidesScreen(
          token: widget.adminToken,
        );

      case 5:
        return SettingsScreen(
          token: widget.adminToken,
        );

      default:
        return _dashboard();
    }
  }

  // ================================================================
  // DASHBOARD
  // ================================================================

  Widget _dashboard() {
    if (isDashboardLoading) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    // --------------------------------------------------------------
    // ERROR
    // --------------------------------------------------------------

    if (dashboardError != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(30),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.error_outline,
                color: Colors.red,
                size: 60,
              ),

              const SizedBox(height: 15),

              Text(
                dashboardError!,
                textAlign: TextAlign.center,
              ),

              const SizedBox(height: 15),

              ElevatedButton.icon(
                onPressed: _loadDashboard,
                icon: const Icon(Icons.refresh),
                label: const Text('Try Again'),
              ),
            ],
          ),
        ),
      );
    }

    // --------------------------------------------------------------
    // DASHBOARD CONTENT
    // --------------------------------------------------------------

    return SingleChildScrollView(
      padding: const EdgeInsets.all(30),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Welcome back, Administrator 👋',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 8),

          const Text(
            'Here is what is happening with RYDEX today.',
            style: TextStyle(
              color: Colors.grey,
              fontSize: 16,
            ),
          ),

          const SizedBox(height: 30),

          // ----------------------------------------------------------
          // STATISTICS
          // ----------------------------------------------------------

          Wrap(
            spacing: 20,
            runSpacing: 20,
            children: [
              _statCard(
                title: 'Total Passengers',
                value: _statValue('total_users'),
                icon: Icons.people,
              ),

              _statCard(
                title: 'Total Drivers',
                value: _statValue('total_drivers'),
                icon: Icons.drive_eta,
              ),

              _statCard(
                title: 'Verified Drivers',
                value: _statValue('verified_drivers'),
                icon: Icons.verified_user,
              ),

              _statCard(
                title: 'Pending Verification',
                value: _statValue(
                  'pending_driver_verifications',
                ),
                icon: Icons.pending_actions,
              ),

              _statCard(
                title: 'Online Drivers',
                value: _statValue('online_drivers'),
                icon: Icons.online_prediction,
              ),

              _statCard(
                title: 'Active Rides',
                value: _statValue('active_rides'),
                icon: Icons.local_taxi,
              ),

              _statCard(
                title: 'Completed Rides',
                value: _statValue('completed_rides'),
                icon: Icons.check_circle,
              ),

              _statCard(
                title: 'Cancelled Rides',
                value: _statValue('cancelled_rides'),
                icon: Icons.cancel,
              ),

              _statCard(
                title: "Today's Revenue",
                value:
                    'KES ${_statValue('todays_revenue')}',
                icon: Icons.account_balance_wallet,
              ),

              _statCard(
                title: 'Driver Earnings',
                value:
                    'KES ${_statValue('driver_earnings')}',
                icon: Icons.payments,
              ),

              _statCard(
                title: 'Platform Commission',
                value:
                    'KES ${_statValue('platform_commission')}',
                icon: Icons.account_balance,
              ),

              _statCard(
                title: 'New Registrations',
                value: _statValue('new_registrations'),
                icon: Icons.person_add,
              ),
            ],
          ),

          const SizedBox(height: 40),

          // ----------------------------------------------------------
          // ANALYTICS
          // ----------------------------------------------------------

          _buildAnalyticsSection(),

          const SizedBox(height: 40),

          // ----------------------------------------------------------
          // SYSTEM ALERTS
          // ----------------------------------------------------------

          const Text(
            'System Alerts',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 15),

          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                _alertRow(
                  icon: Icons.pending_actions,
                  title: 'Pending Driver Verifications',
                  value: _statValue(
                    'pending_driver_verifications',
                  ),
                ),

                const Divider(),

                _alertRow(
                  icon: Icons.online_prediction,
                  title: 'Drivers Currently Online',
                  value: _statValue('online_drivers'),
                ),

                const Divider(),

                _alertRow(
                  icon: Icons.local_taxi,
                  title: 'Active Rides',
                  value: _statValue('active_rides'),
                ),

                const Divider(),

                _alertRow(
                  icon: Icons.check_circle,
                  title: 'Ride Completion Rate',
                  value:
                      '${_statValue('completion_rate')}%',
                ),
              ],
            ),
          ),

          const SizedBox(height: 40),

          // ----------------------------------------------------------
          // RECENT RIDES
          // ----------------------------------------------------------

          Row(
            children: [
              const Text(
                'Recent Rides',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const Spacer(),

              TextButton(
                onPressed: () {
                  setState(() {
                    selectedIndex = 4;
                  });
                },
                child: const Text('View All'),
              ),
            ],
          ),

          const SizedBox(height: 15),

          _recentRidesWidget(),
        ],
      ),
    );
  }

  // ================================================================
  // ANALYTICS SECTION
  // ================================================================

  Widget _buildAnalyticsSection() {
    if (isAnalyticsLoading) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(30),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
        ),
        child: const Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (analyticsError != null) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(25),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            const Icon(
              Icons.analytics_outlined,
              color: Colors.red,
              size: 45,
            ),

            const SizedBox(height: 10),

            const Text(
              'Unable to load dashboard analytics.',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 8),

            Text(
              analyticsError!,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.grey,
              ),
            ),

            const SizedBox(height: 10),

            TextButton.icon(
              onPressed: _loadDashboardAnalytics,
              icon: const Icon(Icons.refresh),
              label: const Text('Retry Analytics'),
            ),
          ],
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Analytics Overview',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),

        const SizedBox(height: 15),

        Wrap(
          spacing: 20,
          runSpacing: 20,
          children: [
            _analyticsCard(
              title: 'Total Rides',
              value: _analyticsValue('total_rides'),
              icon: Icons.local_taxi,
            ),

            _analyticsCard(
              title: 'Completed Rides',
              value: _analyticsValue('completed_rides'),
              icon: Icons.check_circle,
            ),

            _analyticsCard(
              title: 'Cancelled Rides',
              value: _analyticsValue('cancelled_rides'),
              icon: Icons.cancel,
            ),

            _analyticsCard(
              title: 'Completion Rate',
              value:
                  '${_analyticsValue('completion_rate')}%',
              icon: Icons.trending_up,
            ),

            _analyticsCard(
              title: 'Average Ride Fare',
              value:
                  'KES ${_analyticsValue('average_ride_fare')}',
              icon: Icons.payments,
            ),

            _analyticsCard(
              title: 'Average Ride Distance',
              value:
                  '${_analyticsValue('average_ride_distance')} km',
              icon: Icons.route,
            ),

            _analyticsCard(
              title: 'Average Ride Duration',
              value:
                  '${_analyticsValue('average_ride_duration')} min',
              icon: Icons.timer,
            ),

            _analyticsCard(
              title: 'Total Revenue',
              value:
                  'KES ${_analyticsValue('total_revenue')}',
              icon: Icons.account_balance_wallet,
            ),
          ],
        ),
      ],
    );
  }

  // ================================================================
  // ANALYTICS CARD
  // ================================================================

  Widget _analyticsCard({
    required String title,
    required String value,
    required IconData icon,
  }) {
    return Container(
      width: 220,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF111827),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: const Color(0xFFFFC107)
              .withValues(alpha: 0.20),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 12,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: const Color(0xFFFFC107)
                  .withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              icon,
              color: const Color(0xFFFFC107),
              size: 24,
            ),
          ),

          const SizedBox(width: 14),

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),

                const SizedBox(height: 6),

                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ================================================================
  // RECENT RIDES WIDGET
  // ================================================================

  Widget _recentRidesWidget() {
    if (isRidesLoading) {
      return Container(
        width: double.infinity,
        height: 200,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
        ),
        child: const Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (ridesError != null) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(25),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            const Icon(
              Icons.error_outline,
              color: Colors.red,
              size: 40,
            ),

            const SizedBox(height: 10),

            Text(
              ridesError!,
              textAlign: TextAlign.center,
            ),

            const SizedBox(height: 10),

            TextButton.icon(
              onPressed: _loadRecentRides,
              icon: const Icon(Icons.refresh),
              label: const Text('Retry'),
            ),
          ],
        ),
      );
    }

    if (recentRides.isEmpty) {
      return Container(
        width: double.infinity,
        height: 200,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
        ),
        child: const Center(
          child: Text(
            'No rides available yet',
            style: TextStyle(
              color: Colors.grey,
              fontSize: 16,
            ),
          ),
        ),
      );
    }

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: recentRides
            .map((ride) => _rideRow(ride))
            .toList(),
      ),
    );
  }

  // ================================================================
  // RIDE ROW
  // ================================================================

  Widget _rideRow(dynamic ride) {
    final int rideId = ride['id'] ?? 0;

    final int passengerId = ride['passenger_id'] ?? 0;

    final dynamic driverId = ride['driver_id'];

    final String status =
        ride['status']?.toString() ?? 'unknown';

    return Container(
      margin: const EdgeInsets.symmetric(
        horizontal: 18,
        vertical: 6,
      ),
      padding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 14,
      ),
      decoration: BoxDecoration(
        color: const Color(0xFFF9FAFB),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFFE5E7EB),
        ),
      ),
      child: Row(
        children: [
          // ----------------------------------------------------------
          // RIDE ICON
          // ----------------------------------------------------------

          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: const Color(0xFFFFC107)
                  .withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.local_taxi_rounded,
              color: Color(0xFFFFB800),
              size: 23,
            ),
          ),

          const SizedBox(width: 15),

          // ----------------------------------------------------------
          // RIDE INFORMATION
          // ----------------------------------------------------------

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  'Ride #$rideId',
                  style: const TextStyle(
                    color: Color(0xFF111827),
                    fontWeight: FontWeight.w800,
                    fontSize: 14,
                  ),
                ),

                const SizedBox(height: 5),

                Text(
                  'Passenger #$passengerId'
                  '${driverId != null ? ' • Driver #$driverId' : ' • No driver assigned'}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFF6B7280),
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(width: 15),

          // ----------------------------------------------------------
          // STATUS
          // ----------------------------------------------------------

          _statusBadge(status),
        ],
      ),
    );
  }

  // ================================================================
  // STATUS BADGE
  // ================================================================

  Widget _statusBadge(String status) {
    final Color color = _statusColor(status);

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 7,
      ),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: color.withValues(alpha: 0.25),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 7,
            height: 7,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
            ),
          ),

          const SizedBox(width: 7),

          Text(
            status
                .replaceAll('_', ' ')
                .toUpperCase(),
            style: TextStyle(
              color: color,
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.4,
            ),
          ),
        ],
      ),
    );
  }

  // ================================================================
  // STATUS COLOR
  // ================================================================

  Color _statusColor(String status) {
    switch (status.toLowerCase()) {
      case 'completed':
        return const Color(0xFF16A34A);

      case 'cancelled':
        return const Color(0xFFDC2626);

      case 'in_progress':
        return const Color(0xFF2563EB);

      case 'requested':
        return const Color(0xFFFFB800);

      case 'accepted':
        return const Color(0xFF7C3AED);

      default:
        return const Color(0xFF6B7280);
    }
  }

  // ================================================================
  // ALERT ROW
  // ================================================================

  Widget _alertRow({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(
        horizontal: 14,
        vertical: 12,
      ),
      decoration: BoxDecoration(
        color: const Color(0xFFF9FAFB),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFFE5E7EB),
        ),
      ),
      child: Row(
        children: [
          // ----------------------------------------------------------
          // ALERT ICON
          // ----------------------------------------------------------

          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: const Color(0xFFFFC107)
                  .withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              icon,
              color: const Color(0xFFFFB800),
              size: 21,
            ),
          ),

          const SizedBox(width: 12),

          // ----------------------------------------------------------
          // ALERT TITLE
          // ----------------------------------------------------------

          Expanded(
            child: Text(
              title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Color(0xFF374151),
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),

          const SizedBox(width: 10),

          // ----------------------------------------------------------
          // VALUE
          // ----------------------------------------------------------

          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 6,
            ),
            decoration: BoxDecoration(
              color: const Color(0xFF111827),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              value,
              style: const TextStyle(
                color: Color(0xFFFFC107),
                fontSize: 12,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ================================================================
  // STAT CARD
  // ================================================================

  Widget _statCard({
    required String title,
    required String value,
    required IconData icon,
  }) {
    return Container(
      width: 235,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: const Color(0xFFE5E7EB),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 12,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          // ----------------------------------------------------------
          // ICON
          // ----------------------------------------------------------

          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: const Color(0xFFFFC107)
                  .withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              icon,
              color: const Color(0xFFFFB800),
              size: 25,
            ),
          ),

          const SizedBox(width: 14),

          // ----------------------------------------------------------
          // TEXT
          // ----------------------------------------------------------

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFF6B7280),
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),

                const SizedBox(height: 5),

                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFF111827),
                    fontSize: 23,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ================================================================
  // LOGOUT
  // ================================================================

  void _logout() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => const AdminLoginScreen(),
      ),
    );
  }
}
