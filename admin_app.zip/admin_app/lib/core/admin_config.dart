import 'package:flutter/foundation.dart';

class AdminConfig {
  // Base URLs
  static const String webHost = "http://127.0.0.1:8000";
  static const String androidEmulatorHost = "http://10.0.2.2:8000";

  // Dynamic getter based on environment
  static String get baseUrl {
    if (kIsWeb) {
      return webHost;
    }
    return webHost; // Default to localhost/127.0.0.1 for desktop/web
  }
}
