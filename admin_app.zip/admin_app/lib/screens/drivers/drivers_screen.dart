import 'package:flutter/material.dart';
import '../../services/admin_api_service.dart';

// const String backendUrl = 'http://127.0.0.1:8000';

class DriversScreen extends StatefulWidget {
  final String token;

  const DriversScreen({super.key, required this.token});

  @override
  State<DriversScreen> createState() => _DriversScreenState();
}

class _DriversScreenState extends State<DriversScreen> {
  List<dynamic> drivers = [];
  List<dynamic> filteredDrivers = [];

  bool isLoading = true;
  String? errorMessage;

  final TextEditingController searchController = TextEditingController();

  @override
  void initState() {
    super.initState();

    loadDrivers();

    searchController.addListener(filterDrivers);
  }

  @override
  void dispose() {
    searchController.dispose();

    super.dispose();
  }

  // ============================================================
  // IMAGE URL HELPER
  // ============================================================

  String? getImageUrl(dynamic imagePath) {
    if (imagePath == null) {
      return null;
    }

    final path = imagePath.toString().trim();

    if (path.isEmpty) {
      return null;
    }

    if (path.startsWith('http://') || path.startsWith('https://')) {
      return path;
    }

    // return '$backendUrl$path';
    return '${AdminApiService.baseUrl}$path';
  }

  // ============================================================
  // LOAD DRIVERS
  // ============================================================

  Future<void> loadDrivers() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final api = AdminApiService();
      api.setToken(widget.token);

      final result = await api.getDrivers();

      if (!mounted) return;

      setState(() {
        drivers = result;

        filteredDrivers = result;

        isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isLoading = false;

        errorMessage = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  // ============================================================
  // SEARCH DRIVERS
  // ============================================================

  void filterDrivers() {
    final query = searchController.text.toLowerCase().trim();

    final results = drivers.where((driver) {
      final name = (driver['full_name'] ?? '').toString().toLowerCase();

      final phone = (driver['phone_number'] ?? '').toString().toLowerCase();

      final email = (driver['email'] ?? '').toString().toLowerCase();

      final license = (driver['license_number'] ?? '').toString().toLowerCase();

      final plate = (driver['vehicle_plate'] ?? '').toString().toLowerCase();

      final vehicleMake = (driver['vehicle_make'] ?? '')
          .toString()
          .toLowerCase();

      final vehicleModel = (driver['vehicle_model'] ?? '')
          .toString()
          .toLowerCase();

      if (query.isEmpty) {
        return true;
      }

      return name.contains(query) ||
          phone.contains(query) ||
          email.contains(query) ||
          license.contains(query) ||
          plate.contains(query) ||
          vehicleMake.contains(query) ||
          vehicleModel.contains(query);
    }).toList();

    if (!mounted) return;

    setState(() {
      filteredDrivers = results;
    });
  }

  // ============================================================
  // ACTIVATE / SUSPEND DRIVER
  // ============================================================

  Future<void> updateDriverStatus(Map<String, dynamic> driver) async {
    final driverId = driver['id'];

    final currentStatus = driver['is_active'] ?? false;

    final newStatus = !currentStatus;

    final action = newStatus ? 'activate' : 'suspend';

    final confirmed = await showDialog<bool>(
      context: context,

      builder: (context) {
        return AlertDialog(
          title: Text(newStatus ? 'Activate Driver' : 'Suspend Driver'),

          content: Text(
            'Are you sure you want to '
            '$action this driver?',
          ),

          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context, false);
              },

              child: const Text('Cancel'),
            ),

            ElevatedButton(
              onPressed: () {
                Navigator.pop(context, true);
              },

              child: Text(newStatus ? 'Activate' : 'Suspend'),
            ),
          ],
        );
      },
    );

    if (confirmed != true) {
      return;
    }

    try {
      final api = AdminApiService();

      api.setToken(widget.token);

      await api.updateDriverStatus(
  driverId: driverId,
  isActive: newStatus,
);

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            newStatus
                ? 'Driver activated successfully'
                : 'Driver suspended successfully',
          ),
        ),
      );

      await loadDrivers();
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }

  // ============================================================
  // VERIFY / REJECT DRIVER
  // ============================================================

  Future<void> updateDriverVerification(Map<String, dynamic> driver) async {
    final driverId = driver['id'];
    final currentStatus = driver['is_verified'] ?? false;
    final newStatus = !currentStatus;

    final action = newStatus ? 'verify' : 'reject verification';

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(
            newStatus ? 'Verify Driver' : 'Reject Driver Verification',
          ),
          content: Text('Are you sure you want to $action this driver?'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context, false);
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: Text(newStatus ? 'Verify' : 'Reject'),
            ),
          ],
        );
      },
    );

    if (confirmed != true) {
      return;
    }

    try {
      final api = AdminApiService();

      api.setToken(widget.token);

      await api.verifyDriver(driverId);

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            newStatus
                ? 'Driver verified successfully'
                : 'Driver verification rejected',
          ),
        ),
      );

      await loadDrivers();
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }

  Future<void> loadDriverDetails(int driverId) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return const Center(child: CircularProgressIndicator());
      },
    );

    try {
      final api = AdminApiService();

      api.setToken(widget.token);

      final driver = await api.getDriverDetails(driverId);

      if (!mounted) return;

      Navigator.pop(context);

      showDriverDetails(driver);
    } catch (e) {
      if (!mounted) return;

      Navigator.pop(context);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),

      body: Padding(
        padding: const EdgeInsets.all(30),

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,

          children: [
            // ==================================================
            // HEADER
            // ==================================================
            Row(
              children: [
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,

                  children: [
                    Text(
                      'Driver Management',

                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    SizedBox(height: 5),

                    Text(
                      'Manage RYDEX drivers and their accounts.',

                      style: TextStyle(color: Colors.grey),
                    ),
                  ],
                ),

                const Spacer(),

                IconButton(
                  tooltip: 'Refresh',

                  onPressed: isLoading ? null : loadDrivers,

                  icon: const Icon(Icons.refresh, size: 28),
                ),
              ],
            ),

            const SizedBox(height: 25),

            // ==================================================
            // SEARCH
            // ==================================================
            TextField(
              controller: searchController,

              decoration: InputDecoration(
                hintText: 'Search by name, phone, license or plate...',

                prefixIcon: const Icon(Icons.search),

                suffixIcon: searchController.text.isNotEmpty
                    ? IconButton(
                        onPressed: () {
                          searchController.clear();
                        },

                        icon: const Icon(Icons.clear),
                      )
                    : null,

                filled: true,

                fillColor: Colors.white,

                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),

                  borderSide: BorderSide.none,
                ),
              ),
            ),

            const SizedBox(height: 25),

            // ==================================================
            // CONTENT
            // ==================================================
            Expanded(child: buildContent()),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // CONTENT
  // ============================================================

  Widget buildContent() {
    if (isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (errorMessage != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,

          children: [
            const Icon(Icons.error_outline, size: 60, color: Colors.red),

            const SizedBox(height: 15),

            Text(errorMessage!, textAlign: TextAlign.center),

            const SizedBox(height: 20),

            ElevatedButton.icon(
              onPressed: loadDrivers,

              icon: const Icon(Icons.refresh),

              label: const Text('Retry'),
            ),
          ],
        ),
      );
    }

    if (drivers.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,

          children: [
            Icon(Icons.directions_car_outlined, size: 80, color: Colors.grey),

            SizedBox(height: 20),

            Text(
              'No Drivers',

              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),

            SizedBox(height: 8),

            Text(
              'No driver accounts have been registered yet.',

              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      );
    }

    if (filteredDrivers.isEmpty) {
      return const Center(
        child: Text(
          'No drivers match your search.',

          style: TextStyle(fontSize: 18, color: Colors.grey),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: loadDrivers,

      child: ListView.builder(
        itemCount: filteredDrivers.length,

        itemBuilder: (context, index) {
          final driver = filteredDrivers[index];

          final id = driver['id'];

          final name = driver['full_name'] ?? 'Unknown Driver';

          final phone = driver['phone_number'] ?? 'Not provided';

          final license = driver['license_number'] ?? 'Not provided';

          final make = driver['vehicle_make'] ?? '';

          final model = driver['vehicle_model'] ?? '';

          final plate = driver['vehicle_plate'] ?? 'Not provided';

          final isVerified = driver['is_verified'] ?? false;

          final isOnline = driver['is_online'] ?? false;

          final isActive = driver['is_active'] ?? false;

          final profilePhoto = getImageUrl(driver['profile_photo']);

          final averageRating = driver['average_rating'];

          final ratingCount = driver['rating_count'] ?? 0;

          final vehicle = '$make $model'.trim();

          return Card(
            margin: const EdgeInsets.only(bottom: 15),

            child: ListTile(
              contentPadding: const EdgeInsets.all(20),

              // ==================================================
              // DRIVER PROFILE PHOTO
              // ==================================================
              leading: CircleAvatar(
                radius: 32,

                backgroundColor: Colors.grey.shade200,

                backgroundImage: profilePhoto != null
                    ? NetworkImage(profilePhoto)
                    : null,

                child: profilePhoto == null
                    ? Text(
                        name.toString().substring(0, 1).toUpperCase(),

                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      )
                    : null,
              ),

              // ==================================================
              // DRIVER NAME
              // ==================================================
              title: Text(
                name.toString(),

                style: const TextStyle(
                  fontWeight: FontWeight.bold,

                  fontSize: 18,
                ),
              ),

              // ==================================================
              // DRIVER INFORMATION
              // ==================================================
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 10),

                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,

                  children: [
                    Text('Driver ID: $id'),

                    Text('Phone: $phone'),

                    Text('License: $license'),

                    Text(
                      'Vehicle: '
                      '${vehicle.isEmpty ? 'Not provided' : vehicle}',
                    ),

                    Text('Plate: $plate'),

                    Text(
                      'Rating: '
                      '${averageRating == null ? 'No ratings' : '$averageRating / 5'}'
                      ' ($ratingCount)',
                    ),

                    const SizedBox(height: 10),

                    Wrap(
                      spacing: 8,

                      runSpacing: 6,

                      children: [
                        buildStatusChip(
                          isVerified ? 'Verified' : 'Unverified',
                          isVerified,
                        ),

                        buildOnlineChip(isOnline),

                        buildActiveChip(isActive),
                      ],
                    ),
                  ],
                ),
              ),

              // ==================================================
              // MENU
              // ==================================================
              trailing: PopupMenuButton<String>(
                onSelected: (value) {
                  if (value == 'verification') {
                    updateDriverVerification(driver);
                  }

                  if (value == 'status') {
                    updateDriverStatus(driver);

                  }

                  if (value == 'details') {
                    loadDriverDetails(driver['id']);
                  }
                },

                itemBuilder: (context) {
                  return [
                    const PopupMenuItem(
                      value: 'details',

                      child: Text('View Details'),
                    ),

                    PopupMenuItem(
                      value: 'verification',
                      child: Text(
                        isVerified ? 'Reject Verification' : 'Verify Driver',
                      ),
                    ),

                    PopupMenuItem(
                      value: 'status',

                      child: Text(
                        isActive ? 'Suspend Driver' : 'Activate Driver',
                      ),
                    ),
                  ];
                },
              ),
            ),
          );
        },
      ),
    );
  }

  // ============================================================
  // STATUS CHIP
  // ============================================================

  Widget buildStatusChip(String text, bool active) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),

      decoration: BoxDecoration(
        color: active
            ? Colors.green.withValues(alpha: 0.1)
            : Colors.red.withValues(alpha: 0.1),

        borderRadius: BorderRadius.circular(20),
      ),

      child: Text(
        text,

        style: TextStyle(
          color: active ? Colors.green : Colors.red,

          fontWeight: FontWeight.bold,

          fontSize: 12,
        ),
      ),
    );
  }

  Widget buildOnlineChip(bool isOnline) {
    return buildStatusChip(isOnline ? 'Online' : 'Offline', isOnline);
  }

  Widget buildActiveChip(bool isActive) {
    return buildStatusChip(isActive ? 'Active' : 'Suspended', isActive);
  }

  // ============================================================
  // DRIVER DETAILS
  // ============================================================

  void showDriverDetails(Map<String, dynamic> driver) {
    showDialog(
      context: context,

      builder: (context) {
        final name = driver['full_name'] ?? 'Unknown';

        final vehicle =
            '${driver['vehicle_make'] ?? ''} '
                    '${driver['vehicle_model'] ?? ''}'
                .trim();

        final profilePhoto = getImageUrl(driver['profile_photo']);

        final vehiclePhoto = getImageUrl(driver['vehicle_photo']);

        return AlertDialog(
          title: Text(name.toString()),

          content: SizedBox(
            width: 600,

            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,

                children: [
                  // ==================================================
                  // PHOTOS
                  // ==================================================
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,

                    children: [
                      // DRIVER PHOTO
                      Expanded(
                        child: Column(
                          children: [
                            const Text(
                              'Driver Photo',

                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),

                            const SizedBox(height: 10),

                            ClipRRect(
                              borderRadius: BorderRadius.circular(12),

                              child: profilePhoto != null
                                  ? Image.network(
                                      profilePhoto,

                                      width: 200,

                                      height: 200,

                                      fit: BoxFit.cover,

                                      errorBuilder:
                                          (context, error, stackTrace) {
                                            return buildPhotoPlaceholder(
                                              Icons.person,
                                            );
                                          },
                                    )
                                  : buildPhotoPlaceholder(Icons.person),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(width: 20),

                      // VEHICLE PHOTO
                      Expanded(
                        child: Column(
                          children: [
                            const Text(
                              'Vehicle Photo',

                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),

                            const SizedBox(height: 10),

                            ClipRRect(
                              borderRadius: BorderRadius.circular(12),

                              child: vehiclePhoto != null
                                  ? Image.network(
                                      vehiclePhoto,

                                      width: 250,

                                      height: 200,

                                      fit: BoxFit.cover,

                                      errorBuilder:
                                          (context, error, stackTrace) {
                                            return buildPhotoPlaceholder(
                                              Icons.directions_car,
                                            );
                                          },
                                    )
                                  : buildPhotoPlaceholder(Icons.directions_car),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 30),

                  // ==================================================
                  // DRIVER INFORMATION
                  // ==================================================
                  detailRow('Driver ID', driver['id']),

                  detailRow('Phone', driver['phone_number'] ?? 'Not provided'),

                  detailRow('Email', driver['email'] ?? 'Not provided'),

                  detailRow('License', driver['license_number']),

                  detailRow(
                    'Vehicle',
                    vehicle.isEmpty ? 'Not provided' : vehicle,
                  ),

                  detailRow('Color', driver['vehicle_color'] ?? 'Not provided'),

                  detailRow('Plate', driver['vehicle_plate'] ?? 'Not provided'),

                  detailRow(
                    'Verification',
                    driver['is_verified'] == true ? 'Verified' : 'Unverified',
                  ),

                  detailRow(
                    'Online Status',
                    driver['is_online'] == true ? 'Online' : 'Offline',
                  ),

                  detailRow(
                    'Account Status',
                    driver['is_active'] == true ? 'Active' : 'Suspended',
                  ),

                  detailRow(
                    'Rating',
                    driver['average_rating'] == null
                        ? 'No ratings'
                        : '${driver['average_rating']} / 5 (${driver['rating_count'] ?? 0})',
                  ),
                ],
              ),
            ),
          ),

          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },

              child: const Text('Close'),
            ),
          ],
        );
      },
    );
  }

  // ============================================================
  // PHOTO PLACEHOLDER
  // ============================================================

  Widget buildPhotoPlaceholder(IconData icon) {
    return Container(
      width: 200,
      height: 200,

      color: Colors.grey.shade200,

      child: Icon(icon, size: 80, color: Colors.grey),
    );
  }

  // ============================================================
  // DETAIL ROW
  // ============================================================

  Widget detailRow(String label, dynamic value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),

      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,

        children: [
          SizedBox(
            width: 120,

            child: Text(
              '$label:',

              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ),

          Expanded(child: Text(value.toString())),
        ],
      ),
    );
  }
}
