
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../../services/admin_api_service.dart';

class RidesScreen extends StatefulWidget {
  final String token;

  const RidesScreen({
    super.key,
    required this.token,
  });

  @override
  State<RidesScreen> createState() => _RidesScreenState();
}

class _RidesScreenState extends State<RidesScreen> {
  final AdminApiService api = AdminApiService();
  final TextEditingController searchController =
      TextEditingController();

  List<dynamic> rides = [];
  List<dynamic> filteredRides = [];

  bool isLoading = true;
  String? errorMessage;

  String selectedStatus = 'All';

  final List<String> statusFilters = [
    'All',
    'Requested',
    'Accepted',
    'In Progress',
    'Completed',
    'Cancelled',
  ];

  @override
  void initState() {
    super.initState();

    api.setToken(widget.token);

    searchController.addListener(applyFilters);

    loadRides();
  }

  @override
  void dispose() {
    searchController.removeListener(applyFilters);
    searchController.dispose();
    super.dispose();
  }

  // ============================================================
  // LOAD RIDES
  // ============================================================

  Future<void> loadRides() async {
    if (mounted) {
      setState(() {
        isLoading = true;
        errorMessage = null;
      });
    }

    try {
      final result = await api.getRides();

      if (!mounted) return;

      setState(() {
        rides = result;
        isLoading = false;
      });

      applyFilters();
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isLoading = false;
        errorMessage = cleanError(e);
      });
    }
  }

  // ============================================================
  // SEARCH + STATUS FILTER
  // ============================================================

  void applyFilters() {
    final query = searchController.text.trim().toLowerCase();

    final results = rides.where((ride) {
      final id = ride['id']?.toString().toLowerCase() ?? '';

      final passenger =
          ride['passenger_name']?.toString().toLowerCase() ?? '';

      final driver =
          ride['driver_name']?.toString().toLowerCase() ?? '';

      final pickup =
          ride['pickup_location']?.toString().toLowerCase() ?? '';

      final destination =
          ride['destination']?.toString().toLowerCase() ?? '';

      final status =
          ride['status']?.toString().toLowerCase() ?? '';

      final matchesSearch =
          query.isEmpty ||
          id.contains(query) ||
          passenger.contains(query) ||
          driver.contains(query) ||
          pickup.contains(query) ||
          destination.contains(query) ||
          status.contains(query);

      final normalizedStatus = normalizeStatus(status);

      final matchesStatus =
          selectedStatus == 'All' ||
          normalizedStatus == selectedStatus.toLowerCase();

      return matchesSearch && matchesStatus;
    }).toList();

    if (!mounted) return;

    setState(() {
      filteredRides = results;
    });
  }

  String normalizeStatus(String status) {
    return status
        .replaceAll('_', ' ')
        .replaceAll('-', ' ')
        .trim()
        .toLowerCase();
  }

  String cleanError(Object error) {
    return error.toString().replaceFirst('Exception: ', '');
  }

  // ============================================================
  // RIDE DETAILS
  // ============================================================

  Future<void> viewRideDetails(int rideId) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) {
        return const Center(
          child: CircularProgressIndicator(),
        );
      },
    );

    try {
      final ride = await api.getRideDetails(rideId);

      if (!mounted) return;

      Navigator.of(context).pop();

      showRideDetails(ride);
    } catch (e) {
      if (!mounted) return;

      Navigator.of(context).pop();

      showSnackBar(cleanError(e));
    }
  }

  // ============================================================
  // LIVE RIDE MAP
  // ============================================================

  void showRideMap(Map<String, dynamic> ride) {
    final pickupLat = double.tryParse(
      ride['pickup_latitude']?.toString() ?? '',
    );

    final pickupLng = double.tryParse(
      ride['pickup_longitude']?.toString() ?? '',
    );

    final destinationLat = double.tryParse(
      ride['destination_latitude']?.toString() ?? '',
    );

    final destinationLng = double.tryParse(
      ride['destination_longitude']?.toString() ?? '',
    );

    final driverLat = double.tryParse(
      ride['driver_latitude']?.toString() ?? '',
    );

    final driverLng = double.tryParse(
      ride['driver_longitude']?.toString() ?? '',
    );

    if (pickupLat == null ||
        pickupLng == null ||
        destinationLat == null ||
        destinationLng == null) {
      showSnackBar(
        'Pickup or destination coordinates are unavailable.',
      );
      return;
    }

    final pickup = LatLng(
      pickupLat,
      pickupLng,
    );

    final destination = LatLng(
      destinationLat,
      destinationLng,
    );

    final driverAvailable =
        driverLat != null && driverLng != null;

    final driver = driverAvailable
        ? LatLng(
            driverLat,
            driverLng,
          )
        : null;

    final points = <LatLng>[
      pickup,
      destination,
      ?driver,
    ];

    final bounds = LatLngBounds.fromPoints(points);

    showDialog(
      context: context,
      builder: (dialogContext) {
        return Dialog(
          insetPadding: const EdgeInsets.all(25),
          child: SizedBox(
            width: 1000,
            height: 700,
            child: Column(
              children: [
                // =================================================
                // MAP HEADER
                // =================================================

                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 15,
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.map_outlined,
                        size: 25,
                      ),

                      const SizedBox(width: 10),

                      Text(
                        'Live Ride Map #${ride['id'] ?? 'N/A'}',
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      const Spacer(),

                      if (driverAvailable)
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.green.withValues(
                              alpha: 0.1,
                            ),
                            borderRadius:
                                BorderRadius.circular(20),
                          ),
                          child: const Row(
                            children: [
                              Icon(
                                Icons.circle,
                                size: 9,
                                color: Colors.green,
                              ),
                              SizedBox(width: 6),
                              Text(
                                'Driver Live',
                                style: TextStyle(
                                  color: Colors.green,
                                  fontWeight:
                                      FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        )
                      else
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.grey.withValues(
                              alpha: 0.1,
                            ),
                            borderRadius:
                                BorderRadius.circular(20),
                          ),
                          child: const Text(
                            'Driver Location Unavailable',
                            style: TextStyle(
                              color: Colors.grey,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),

                      const SizedBox(width: 10),

                      IconButton(
                        onPressed: () {
                          Navigator.pop(dialogContext);
                        },
                        icon: const Icon(Icons.close),
                      ),
                    ],
                  ),
                ),

                // =================================================
                // MAP
                // =================================================

                Expanded(
                  child: FlutterMap(
                    options: MapOptions(
                      initialCenter: LatLng(
                        (pickupLat + destinationLat) / 2,
                        (pickupLng + destinationLng) / 2,
                      ),
                      initialZoom: 13,
                      initialCameraFit: CameraFit.bounds(
                        bounds: bounds,
                        padding: const EdgeInsets.all(70),
                      ),
                    ),
                    children: [
                      // ===========================================
                      // OPENSTREETMAP
                      // ===========================================

                      TileLayer(
                        urlTemplate:
                            'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                        userAgentPackageName:
                            'com.rydex.admin',
                      ),

                      // ===========================================
                      // ROUTE LINE
                      // ===========================================

                      PolylineLayer(
                        polylines: [
                          Polyline(
                            points: [
                              pickup,
                              ?driver,
                              destination,
                            ],
                            strokeWidth: 4,
                          ),
                        ],
                      ),

                      // ===========================================
                      // MARKERS
                      // ===========================================

                      MarkerLayer(
                        markers: [
                          // PICKUP
                          Marker(
                            point: pickup,
                            width: 50,
                            height: 50,
                            child: const Icon(
                              Icons.location_on,
                              size: 45,
                              color: Colors.green,
                            ),
                          ),

                          // DESTINATION
                          Marker(
                            point: destination,
                            width: 50,
                            height: 50,
                            child: const Icon(
                              Icons.location_on,
                              size: 45,
                              color: Colors.red,
                            ),
                          ),

                          // DRIVER
                          if (driver != null)
                            Marker(
                              point: driver,
                              width: 60,
                              height: 60,
                              child: Container(
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.blue,
                                  border: Border.all(
                                    color: Colors.white,
                                    width: 3,
                                  ),
                                  boxShadow: const [
                                    BoxShadow(
                                      blurRadius: 8,
                                      spreadRadius: 2,
                                    ),
                                  ],
                                ),
                                child: const Icon(
                                  Icons.local_taxi,
                                  color: Colors.white,
                                  size: 28,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),

                // =================================================
                // MAP LEGEND
                // =================================================

                Container(
                  padding: const EdgeInsets.all(15),
                  child: Row(
                    children: [
                      buildMapLegend(
                        Colors.green,
                        'Pickup',
                      ),

                      const SizedBox(width: 25),

                      buildMapLegend(
                        Colors.red,
                        'Destination',
                      ),

                      const SizedBox(width: 25),

                      buildMapLegend(
                        Colors.blue,
                        'Driver',
                      ),

                      const Spacer(),

                      if (ride['driver_location_updated_at'] !=
                          null)
                        Text(
                          'Last update: '
                          '${ride['driver_location_updated_at']}',
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.grey,
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // MAP LEGEND
  // ============================================================

  Widget buildMapLegend(
    Color color,
    String label,
  ) {
    return Row(
      children: [
        Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
          ),
        ),

        const SizedBox(width: 6),

        Text(
          label,
          style: const TextStyle(
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // CANCEL RIDE
  // ============================================================

  Future<void> cancelRide(
    Map<String, dynamic> ride,
  ) async {
    final rideId = parseRideId(ride['id']);

    if (rideId == null) {
      showSnackBar('Invalid ride ID.');
      return;
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Cancel Ride'),
          content: Text(
            'Are you sure you want to cancel Ride #$rideId?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext, false);
              },
              child: const Text('Keep Ride'),
            ),

            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(dialogContext, true);
              },
              child: const Text('Cancel Ride'),
            ),
          ],
        );
      },
    );

    if (confirmed != true) return;

    try {
      await api.cancelRide(rideId);

      if (!mounted) return;

      showSnackBar(
        'Ride #$rideId cancelled successfully.',
      );

      await loadRides();
    } catch (e) {
      if (!mounted) return;

      showSnackBar(cleanError(e));
    }
  }

  // ============================================================
  // COMPLETE RIDE
  // ============================================================

  Future<void> completeRide(
    Map<String, dynamic> ride,
  ) async {
    final rideId = parseRideId(ride['id']);

    if (rideId == null) {
      showSnackBar('Invalid ride ID.');
      return;
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Complete Ride'),
          content: Text(
            'Are you sure you want to force-complete Ride #$rideId?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext, false);
              },
              child: const Text('Cancel'),
            ),

            ElevatedButton(
              onPressed: () {
                Navigator.pop(dialogContext, true);
              },
              child: const Text('Complete Ride'),
            ),
          ],
        );
      },
    );

    if (confirmed != true) return;

    try {
      await api.completeRide(rideId);

      if (!mounted) return;

      showSnackBar(
        'Ride #$rideId completed successfully.',
      );

      await loadRides();
    } catch (e) {
      if (!mounted) return;

      showSnackBar(cleanError(e));
    }
  }

  // ============================================================
  // ID PARSER
  // ============================================================

  int? parseRideId(dynamic value) {
    if (value is int) {
      return value;
    }

    return int.tryParse(
      value?.toString() ?? '',
    );
  }

  // ============================================================
  // SNACKBAR
  // ============================================================

  void showSnackBar(String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
        ),
      );
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      body: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            buildHeader(),

            const SizedBox(height: 25),

            buildSearch(),

            const SizedBox(height: 15),

            buildStatusFilters(),

            const SizedBox(height: 20),

            Expanded(
              child: buildContent(),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // HEADER
  // ============================================================

  Widget buildHeader() {
    return Row(
      children: [
        const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Ride Management',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),

            SizedBox(height: 5),

            Text(
              'Monitor and manage all RYDEX rides.',
              style: TextStyle(
                color: Colors.grey,
              ),
            ),
          ],
        ),

        const Spacer(),

        IconButton(
          tooltip: 'Refresh rides',
          onPressed: isLoading ? null : loadRides,
          icon: const Icon(
            Icons.refresh,
            size: 28,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // SEARCH
  // ============================================================

  Widget buildSearch() {
    return TextField(
      controller: searchController,
      decoration: InputDecoration(
        hintText:
            'Search ride ID, passenger, driver, pickup or destination...',

        prefixIcon: const Icon(Icons.search),

        suffixIcon: searchController.text.isNotEmpty
            ? IconButton(
                onPressed: () {
                  searchController.clear();
                },
                icon: const Icon(Icons.clear),
              )
            : null,

        filled: true,
        fillColor: Colors.white,

        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  // ============================================================
  // STATUS FILTERS
  // ============================================================

  Widget buildStatusFilters() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: statusFilters.map((status) {
          final selected = selectedStatus == status;

          return Padding(
            padding: const EdgeInsets.only(right: 10),
            child: ChoiceChip(
              label: Text(status),
              selected: selected,
              onSelected: (_) {
                setState(() {
                  selectedStatus = status;
                });

                applyFilters();
              },
            ),
          );
        }).toList(),
      ),
    );
  }

  // ============================================================
  // CONTENT
  // ============================================================

  Widget buildContent() {
    if (isLoading) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    if (errorMessage != null) {
      return buildError();
    }

    if (rides.isEmpty) {
      return buildEmpty(
        title: 'No Rides',
        message: 'No rides have been created yet.',
      );
    }

    if (filteredRides.isEmpty) {
      return buildEmpty(
        title: 'No Matching Rides',
        message:
            'No rides match your current filters.',
      );
    }

    return RefreshIndicator(
      onRefresh: loadRides,
      child: ListView.builder(
        itemCount: filteredRides.length,
        itemBuilder: (context, index) {
          final ride = filteredRides[index];

          return buildRideCard(ride);
        },
      ),
    );
  }

  // ============================================================
  // ERROR
  // ============================================================

  Widget buildError() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.error_outline,
            size: 60,
            color: Colors.red,
          ),

          const SizedBox(height: 15),

          Text(
            errorMessage!,
            textAlign: TextAlign.center,
          ),

          const SizedBox(height: 20),

          ElevatedButton.icon(
            onPressed: loadRides,
            icon: const Icon(Icons.refresh),
            label: const Text('Retry'),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // EMPTY
  // ============================================================

  Widget buildEmpty({
    required String title,
    required String message,
  }) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.local_taxi_outlined,
            size: 80,
            color: Colors.grey,
          ),

          const SizedBox(height: 20),

          Text(
            title,
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 8),

          Text(
            message,
            style: const TextStyle(
              color: Colors.grey,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // RIDE CARD
  // ============================================================

  Widget buildRideCard(
    Map<String, dynamic> ride,
  ) {
    final id = ride['id'] ?? 'N/A';

    final passenger =
        ride['passenger_name'] ?? 'Unknown Passenger';

    final driver =
        ride['driver_name'] ?? 'No driver assigned';

    final pickup =
        ride['pickup_location'] ?? 'Unknown pickup';

    final destination =
        ride['destination'] ?? 'Unknown destination';

    final status =
        ride['status']?.toString() ?? 'Unknown';

    final fare =
        ride['final_fare'] ??
        ride['estimated_fare'] ??
        ride['fare'] ??
        0;

    final rideId = parseRideId(id);

    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      elevation: 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.all(18),

        leading: CircleAvatar(
          radius: 28,
          backgroundColor: Colors.green.withValues(
            alpha: 0.1,
          ),
          child: const Icon(
            Icons.local_taxi,
            color: Colors.green,
          ),
        ),

        title: Row(
          children: [
            Expanded(
              child: Text(
                'Ride #$id',
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 17,
                ),
              ),
            ),

            buildRideStatusChip(status),
          ],
        ),

        subtitle: Padding(
          padding: const EdgeInsets.only(top: 12),
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              buildInfoLine(
                Icons.person_outline,
                'Passenger',
                passenger.toString(),
              ),

              buildInfoLine(
                Icons.drive_eta_outlined,
                'Driver',
                driver.toString(),
              ),

              buildInfoLine(
                Icons.my_location,
                'Pickup',
                pickup.toString(),
              ),

              buildInfoLine(
                Icons.location_on_outlined,
                'Destination',
                destination.toString(),
              ),

              buildInfoLine(
                Icons.payments_outlined,
                'Fare',
                'KES $fare',
              ),
            ],
          ),
        ),

        trailing: PopupMenuButton<String>(
          onSelected: (value) {
            if (rideId == null) {
              showSnackBar('Invalid ride ID.');
              return;
            }

            if (value == 'details') {
              viewRideDetails(rideId);
            } else if (value == 'map') {
              openRideMap(rideId);
            } else if (value == 'cancel') {
              cancelRide(ride);
            } else if (value == 'complete') {
              completeRide(ride);
            }
          },

          itemBuilder: (context) {
            final normalized =
                normalizeStatus(status);

            final items =
                <PopupMenuEntry<String>>[
              const PopupMenuItem(
                value: 'details',
                child: Row(
                  children: [
                    Icon(
                      Icons.visibility_outlined,
                    ),
                    SizedBox(width: 10),
                    Text('View Details'),
                  ],
                ),
              ),

              const PopupMenuItem(
                value: 'map',
                child: Row(
                  children: [
                    Icon(
                      Icons.map_outlined,
                    ),
                    SizedBox(width: 10),
                    Text('Live Map'),
                  ],
                ),
              ),
            ];

            if (normalized != 'completed' &&
                normalized != 'cancelled') {
              items.add(
                const PopupMenuItem(
                  value: 'cancel',
                  child: Row(
                    children: [
                      Icon(
                        Icons.cancel_outlined,
                      ),
                      SizedBox(width: 10),
                      Text('Cancel Ride'),
                    ],
                  ),
                ),
              );
            }

            if (normalized != 'completed' &&
                normalized != 'cancelled') {
              items.add(
                const PopupMenuItem(
                  value: 'complete',
                  child: Row(
                    children: [
                      Icon(
                        Icons.check_circle_outline,
                      ),
                      SizedBox(width: 10),
                      Text('Force Complete'),
                    ],
                  ),
                ),
              );
            }

            return items;
          },
        ),
      ),
    );
  }

  // ============================================================
  // OPEN MAP FROM RIDE ID
  // ============================================================

  Future<void> openRideMap(int rideId) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) {
        return const Center(
          child: CircularProgressIndicator(),
        );
      },
    );

    try {
      final ride = await api.getRideDetails(rideId);

      if (!mounted) return;

      Navigator.of(context).pop();

      showRideMap(ride);
    } catch (e) {
      if (!mounted) return;

      Navigator.of(context).pop();

      showSnackBar(cleanError(e));
    }
  }

  // ============================================================
  // INFO LINE
  // ============================================================

  Widget buildInfoLine(
    IconData icon,
    String label,
    String value,
  ) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 5),
      child: Row(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Icon(
            icon,
            size: 16,
            color: Colors.grey,
          ),

          const SizedBox(width: 7),

          Text(
            '$label: ',
            style: const TextStyle(
              fontWeight: FontWeight.w600,
            ),
          ),

          Expanded(
            child: Text(value),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // STATUS CHIP
  // ============================================================

  Widget buildRideStatusChip(String status) {
    final normalized =
        normalizeStatus(status);

    Color color;

    switch (normalized) {
      case 'completed':
        color = Colors.green;
        break;

      case 'cancelled':
        color = Colors.red;
        break;

      case 'in progress':
        color = Colors.orange;
        break;

      case 'accepted':
        color = Colors.blue;
        break;

      case 'requested':
        color = Colors.amber.shade800;
        break;

      default:
        color = Colors.grey;
    }

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 5,
      ),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        status.toUpperCase(),
        style: TextStyle(
          color: color,
          fontSize: 11,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  // ============================================================
  // RIDE DETAILS
  // ============================================================

  void showRideDetails(
    Map<String, dynamic> ride,
  ) {
    showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: Row(
            children: [
              const Icon(Icons.local_taxi),

              const SizedBox(width: 10),

              Text(
                'Ride #${ride['id'] ?? 'N/A'}',
              ),
            ],
          ),

          content: SizedBox(
            width: 600,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  buildDetailSection(
                    'Ride Information',
                    [
                      detailRow(
                        'Ride ID',
                        ride['id'],
                      ),
                      detailRow(
                        'Status',
                        ride['status'],
                      ),
                      detailRow(
                        'Created',
                        ride['created_at'] ??
                            ride['requested_at'],
                      ),
                    ],
                  ),

                  const SizedBox(height: 15),

                  buildDetailSection(
                    'Passenger',
                    [
                      detailRow(
                        'Name',
                        ride['passenger_name'],
                      ),
                      detailRow(
                        'Phone',
                        ride['passenger_phone'],
                      ),
                    ],
                  ),

                  const SizedBox(height: 15),

                  buildDetailSection(
                    'Driver',
                    [
                      detailRow(
                        'Name',
                        ride['driver_name'] ??
                            'Not assigned',
                      ),
                      detailRow(
                        'Phone',
                        ride['driver_phone'] ??
                            'Not available',
                      ),
                    ],
                  ),

                  const SizedBox(height: 15),

                  buildDetailSection(
                    'Trip',
                    [
                      detailRow(
                        'Pickup',
                        ride['pickup_location'],
                      ),
                      detailRow(
                        'Destination',
                        ride['destination'],
                      ),
                    ],
                  ),

                  const SizedBox(height: 15),

                  buildDetailSection(
                    'Payment',
                    [
                      detailRow(
                        'Estimated Fare',
                        ride['estimated_fare'] == null
                            ? 'Not available'
                            : 'KES ${ride['estimated_fare']}',
                      ),
                      detailRow(
                        'Final Fare',
                        ride['final_fare'] == null
                            ? 'Not available'
                            : 'KES ${ride['final_fare']}',
                      ),
                    ],
                  ),

                  const SizedBox(height: 15),

                  buildDetailSection(
                    'Timeline',
                    [
                      detailRow(
                        'Requested',
                        ride['requested_at'],
                      ),
                      detailRow(
                        'Accepted',
                        ride['accepted_at'],
                      ),
                      detailRow(
                        'Started',
                        ride['started_at'],
                      ),
                      detailRow(
                        'Completed',
                        ride['completed_at'],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext);
              },
              child: const Text('Close'),
            ),

            ElevatedButton.icon(
              onPressed: () {
                Navigator.pop(dialogContext);
                showRideMap(ride);
              },
              icon: const Icon(Icons.map_outlined),
              label: const Text('Open Live Map'),
            ),
          ],
        );
      },
    );
  }

  // ============================================================
  // DETAIL SECTION
  // ============================================================

  Widget buildDetailSection(
    String title,
    List<Widget> children,
  ) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: const Color(0xFFF5F7FA),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),

          const SizedBox(height: 12),

          ...children,
        ],
      ),
    );
  }

  // ============================================================
  // DETAIL ROW
  // ============================================================

  Widget detailRow(
    String label,
    dynamic value,
  ) {
    final displayValue =
        value == null ||
                value.toString().trim().isEmpty
            ? 'Not available'
            : value.toString();

    return Padding(
      padding: const EdgeInsets.only(
        bottom: 8,
      ),
      child: Row(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 135,
            child: Text(
              label,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
              ),
            ),
          ),

          Expanded(
            child: Text(displayValue),
          ),
        ],
      ),
    );
  }
}
