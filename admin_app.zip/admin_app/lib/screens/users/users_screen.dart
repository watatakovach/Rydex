
import 'dart:async';

import 'package:flutter/material.dart';

import '../../models/admin_user.dart';
import '../../services/admin_user_service.dart';
import 'user_detail_screen.dart';

class UsersScreen extends StatefulWidget {
  final String token;

  const UsersScreen({
    super.key,
    required this.token,
  });

  @override
  State<UsersScreen> createState() =>
      _UsersScreenState();
}

class _UsersScreenState extends State<UsersScreen> {
  final AdminUserService _userService =
      AdminUserService();

  final TextEditingController _searchController =
      TextEditingController();

  Timer? _searchTimer;

  List<AdminUser> _users = [];

  bool _isLoading = true;

  String? _error;

  String _selectedFilter = 'All Users';

  final List<String> _filters = [
    'All Users',
    'Active',
    'Suspended',
    'New Users',
    'Passengers',
    'Drivers',
  ];

  @override
  void initState() {
    super.initState();
    _loadUsers();
  }

  @override
  void dispose() {
    _searchTimer?.cancel();
    _searchController.dispose();
    super.dispose();
  }

  // ============================================================
  // LOAD USERS
  // ============================================================

  Future<void> _loadUsers() async {
    if (!mounted) return;

    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      String? role;
      String? statusFilter;
      bool? newUsers;

      switch (_selectedFilter) {
        case 'Passengers':
          role = 'passenger';
          break;

        case 'Drivers':
          role = 'driver';
          break;

        case 'Active':
          statusFilter = 'active';
          break;

        case 'Suspended':
          statusFilter = 'suspended';
          break;

        case 'New Users':
          newUsers = true;
          break;
      }

      final users = await _userService.getUsers(
        token: widget.token,
        search: _searchController.text.trim(),
        role: role,
        statusFilter: statusFilter,
        newUsers: newUsers,
      );

      if (!mounted) return;

      setState(() {
        _users = users;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _error = e.toString();
        _isLoading = false;
      });
    }
  }

  // ============================================================
  // SEARCH
  // ============================================================

  void _onSearchChanged(String value) {
    _searchTimer?.cancel();

    _searchTimer = Timer(
      const Duration(milliseconds: 500),
      () {
        _loadUsers();
      },
    );
  }

  // ============================================================
  // FILTER
  // ============================================================

  void _selectFilter(String filter) {
    setState(() {
      _selectedFilter = filter;
    });

    _loadUsers();
  }

  // ============================================================
  // UPDATE USER STATUS
  // ============================================================

  Future<void> _updateUserStatus(
    AdminUser user,
    bool isActive,
  ) async {
    final action =
        isActive ? 'reactivate' : 'suspend';

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(
            isActive
                ? 'Reactivate User'
                : 'Suspend User',
          ),
          content: Text(
            'Are you sure you want to '
            '$action ${user.fullName}?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context, false);
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: Text(
                isActive
                    ? 'Reactivate'
                    : 'Suspend',
              ),
            ),
          ],
        );
      },
    );

    if (confirmed != true) {
      return;
    }

    try {
      await _userService.updateUserStatus(
        token: widget.token,
        userId: user.id,
        isActive: isActive,
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context)
          .showSnackBar(
        SnackBar(
          content: Text(
            isActive
                ? '${user.fullName} has been reactivated.'
                : '${user.fullName} has been suspended.',
          ),
        ),
      );

      _loadUsers();
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context)
          .showSnackBar(
        SnackBar(
          content: Text(
            'Failed to update user: $e',
          ),
        ),
      );
    }
  }

  // ============================================================
  // OPEN USER DETAILS
  // ============================================================

  void _openUserDetails(AdminUser user) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => UserDetailScreen(
          token: widget.token,
          userId: user.id,
        ),
      ),
    );
  }

  // ============================================================
  // USER CARD
  // ============================================================

  Widget _buildUserCard(AdminUser user) {
    final bool isActive = user.isActive;

    return Card(
      margin: const EdgeInsets.only(
        bottom: 12,
      ),
      elevation: 1,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            // Avatar
            CircleAvatar(
              radius: 25,
              child: Text(
                user.fullName.isNotEmpty
                    ? user.fullName[0]
                        .toUpperCase()
                    : '?',
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            const SizedBox(width: 16),

            // User information
            Expanded(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  Text(
                    user.fullName,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 5),

                  Text(
                    user.email ?? 'No email',
                    style: TextStyle(
                      color: Colors.grey.shade600,
                    ),
                  ),

                  const SizedBox(height: 3),

                  Text(
                    user.phoneNumber,
                    style: TextStyle(
                      color: Colors.grey.shade600,
                    ),
                  ),

                  const SizedBox(height: 8),

                  Row(
                    children: [
                      _buildRoleBadge(
                        user.role,
                      ),

                      const SizedBox(width: 8),

                      _buildStatusBadge(
                        isActive,
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(width: 10),

            // Actions
            Column(
              children: [
                IconButton(
                  tooltip: 'View Profile',
                  icon: const Icon(
                    Icons.visibility_outlined,
                  ),
                  onPressed: () {
                    _openUserDetails(user);
                  },
                ),

                PopupMenuButton<String>(
                  onSelected: (value) {
                    if (value == 'toggle') {
                      _updateUserStatus(
                        user,
                        !isActive,
                      );
                    }
                  },
                  itemBuilder: (context) {
                    return [
                      PopupMenuItem<String>(
                        value: 'toggle',
                        child: Row(
                          children: [
                            Icon(
                              isActive
                                  ? Icons
                                      .block_outlined
                                  : Icons
                                      .check_circle_outline,
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            Text(
                              isActive
                                  ? 'Suspend'
                                  : 'Reactivate',
                            ),
                          ],
                        ),
                      ),
                    ];
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // ROLE BADGE
  // ============================================================

  Widget _buildRoleBadge(
    String role,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 8,
        vertical: 4,
      ),
      decoration: BoxDecoration(
        color: Colors.blue.withValues(
          alpha: 0.1,
        ),
        borderRadius:
            BorderRadius.circular(20),
      ),
      child: Text(
        role.toUpperCase(),
        style: const TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  // ============================================================
  // STATUS BADGE
  // ============================================================

  Widget _buildStatusBadge(
    bool isActive,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 8,
        vertical: 4,
      ),
      decoration: BoxDecoration(
        color: isActive
            ? Colors.green.withValues(
                alpha: 0.1,
              )
            : Colors.red.withValues(
                alpha: 0.1,
              ),
        borderRadius:
            BorderRadius.circular(20),
      ),
      child: Text(
        isActive
            ? 'ACTIVE'
            : 'SUSPENDED',
        style: TextStyle(
          color: isActive
              ? Colors.green
              : Colors.red,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'User Management',
        ),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            icon: const Icon(
              Icons.refresh,
            ),
            onPressed: _loadUsers,
          ),
        ],
      ),

      body: Column(
        children: [
          // ======================================================
          // SEARCH BAR
          // ======================================================

          Padding(
            padding: const EdgeInsets.all(
              16,
            ),
            child: TextField(
              controller:
                  _searchController,
              onChanged:
                  _onSearchChanged,
              decoration:
                  InputDecoration(
                hintText:
                    'Search by name, phone or email...',
                prefixIcon:
                    const Icon(
                  Icons.search,
                ),
                suffixIcon:
                    _searchController
                            .text
                            .isNotEmpty
                        ? IconButton(
                            icon:
                                const Icon(
                              Icons.clear,
                            ),
                            onPressed: () {
                              _searchController
                                  .clear();
                              _loadUsers();
                              setState(
                                () {},
                              );
                            },
                          )
                        : null,
                border:
                    OutlineInputBorder(
                  borderRadius:
                      BorderRadius.circular(
                    12,
                  ),
                ),
              ),
            ),
          ),

          // ======================================================
          // FILTERS
          // ======================================================

          SizedBox(
            height: 50,
            child: ListView.builder(
              scrollDirection:
                  Axis.horizontal,
              padding:
                  const EdgeInsets.symmetric(
                horizontal: 16,
              ),
              itemCount:
                  _filters.length,
              itemBuilder:
                  (context, index) {
                final filter =
                    _filters[index];

                final selected =
                    filter ==
                        _selectedFilter;

                return Padding(
                  padding:
                      const EdgeInsets.only(
                    right: 8,
                  ),
                  child:
                      ChoiceChip(
                    label:
                        Text(filter),
                    selected:
                        selected,
                    onSelected:
                        (_) {
                      _selectFilter(
                        filter,
                      );
                    },
                  ),
                );
              },
            ),
          ),

          const SizedBox(
            height: 10,
          ),

          // ======================================================
          // USER LIST
          // ======================================================

          Expanded(
            child: _buildUserList(),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // USER LIST STATES
  // ============================================================

  Widget _buildUserList() {
    if (_isLoading) {
      return const Center(
        child:
            CircularProgressIndicator(),
      );
    }

    if (_error != null) {
      return Center(
        child: Padding(
          padding:
              const EdgeInsets.all(24),
          child: Column(
            mainAxisSize:
                MainAxisSize.min,
            children: [
              const Icon(
                Icons.error_outline,
                size: 50,
                color: Colors.red,
              ),

              const SizedBox(
                height: 12,
              ),

              Text(
                _error!,
                textAlign:
                    TextAlign.center,
              ),

              const SizedBox(
                height: 16,
              ),

              ElevatedButton.icon(
                onPressed:
                    _loadUsers,
                icon:
                    const Icon(
                  Icons.refresh,
                ),
                label:
                    const Text(
                  'Retry',
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (_users.isEmpty) {
      return const Center(
        child: Column(
          mainAxisSize:
              MainAxisSize.min,
          children: [
            Icon(
              Icons.people_outline,
              size: 60,
              color: Colors.grey,
            ),
            SizedBox(
              height: 12,
            ),
            Text(
              'No users found',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey,
              ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadUsers,
      child: ListView.builder(
        padding:
            const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 8,
        ),
        itemCount:
            _users.length,
        itemBuilder:
            (context, index) {
          return _buildUserCard(
            _users[index],
          );
        },
      ),
    );
  }
}

