import 'package:flutter/material.dart';

import '../../models/user_ride.dart';
import '../../services/admin_user_service.dart';

class UserRideHistoryScreen extends StatefulWidget {
  final String token;
  final int userId;

  const UserRideHistoryScreen({
    super.key,
    required this.token,
    required this.userId,
  });

  @override
  State<UserRideHistoryScreen> createState() =>
      _UserRideHistoryScreenState();
}

class _UserRideHistoryScreenState
    extends State<UserRideHistoryScreen> {
  final service = AdminUserService();

  List<UserRide> rides = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    loadRides();
  }

  Future<void> loadRides() async {
    rides = await service.getUserRides(
      token: widget.token,
      userId: widget.userId,
    );

    if (!mounted) return;

    setState(() {
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Ride History"),
      ),
      body: loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : ListView.builder(
              itemCount: rides.length,
              itemBuilder: (context, index) {
                final ride = rides[index];

                return Card(
                  margin: const EdgeInsets.all(10),
                  child: ListTile(
                    leading:
                        const Icon(Icons.local_taxi),
                    title: Text(
                      ride.destination,
                    ),
                    subtitle: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [
                        Text(
                            "Pickup: ${ride.pickupLocation}"),
                        Text(
                            "Status: ${ride.status}"),
                        Text(
                            "Fare: KES ${ride.finalFare ?? ride.estimatedFare ?? 0}"),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}