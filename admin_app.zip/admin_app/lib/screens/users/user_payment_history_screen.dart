import 'package:flutter/material.dart';

import '../../models/user_payment.dart';
import '../../services/admin_user_service.dart';

class UserPaymentHistoryScreen extends StatefulWidget {
  final String token;
  final int userId;

  const UserPaymentHistoryScreen({
    super.key,
    required this.token,
    required this.userId,
  });

  @override
  State<UserPaymentHistoryScreen> createState() =>
      _UserPaymentHistoryScreenState();
}

class _UserPaymentHistoryScreenState
    extends State<UserPaymentHistoryScreen> {

  final AdminUserService service = AdminUserService();

  bool loading = true;

  List<UserPayment> payments = [];

  @override
  void initState() {
    super.initState();
    loadPayments();
  }

  Future<void> loadPayments() async {
    payments = await service.getUserPayments(
      token: widget.token,
      userId: widget.userId,
    );

    if (!mounted) return;

    setState(() {
      loading = false;
    });
  }

  Color statusColor(String status) {
    switch (status.toLowerCase()) {
      case "paid":
      case "successful":
        return Colors.green;

      case "pending":
        return Colors.orange;

      case "failed":
        return Colors.red;

      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: const Text("Payment History"),
      ),

      body: loading
          ? const Center(
              child: CircularProgressIndicator(),
            )

          : ListView.builder(
              itemCount: payments.length,
              itemBuilder: (context, index) {

                final payment = payments[index];

                return Card(
                  margin: const EdgeInsets.all(10),

                  child: ListTile(

                    leading: const Icon(
                      Icons.payments,
                      color: Colors.green,
                    ),

                    title: Text(
                      "KES ${payment.amount.toStringAsFixed(2)}",
                    ),

                    subtitle: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,

                      children: [

                        Text(
                          payment.paymentMethod,
                        ),

                        Text(
                          payment.createdAt.toString(),
                        ),

                      ],
                    ),

                    trailing: Chip(
                      label: Text(payment.status),
                      backgroundColor:
                          statusColor(payment.status),
                    ),
                  ),
                );
              },
            ),
    );
  }
}