import 'package:flutter/material.dart';

import '../../models/user_complaint.dart';
import '../../services/admin_user_service.dart';

class UserComplaintsScreen extends StatefulWidget {
  final String token;
  final int userId;

  const UserComplaintsScreen({
    super.key,
    required this.token,
    required this.userId,
  });

  @override
  State<UserComplaintsScreen> createState() =>
      _UserComplaintsScreenState();
}

class _UserComplaintsScreenState
    extends State<UserComplaintsScreen> {
  final service = AdminUserService();

  List<UserComplaint> complaints = [];

  bool loading = true;

  @override
  void initState() {
    super.initState();
    loadComplaints();
  }

  Future<void> loadComplaints() async {
    complaints = await service.getUserComplaints(
      token: widget.token,
      userId: widget.userId,
    );

    if (!mounted) return;

    setState(() {
      loading = false;
    });
  }

  Color statusColor(String status) {
    switch (status.toLowerCase()) {
      case "resolved":
        return Colors.green;

      case "pending":
        return Colors.orange;

      case "rejected":
        return Colors.red;

      default:
        return Colors.blueGrey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Complaints"),
      ),
      body: loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : complaints.isEmpty
              ? const Center(
                  child: Text(
                    "No complaints found",
                  ),
                )
              : ListView.builder(
                  itemCount: complaints.length,
                  itemBuilder: (context, index) {
                    final complaint = complaints[index];

                    return Card(
                      margin: const EdgeInsets.all(10),
                      child: Padding(
                        padding:
                            const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment:
                              CrossAxisAlignment.start,
                          children: [
                            Text(
                              complaint.title,
                              style:
                                  const TextStyle(
                                fontSize: 18,
                                fontWeight:
                                    FontWeight.bold,
                              ),
                            ),

                            const SizedBox(height: 8),

                            Text(
                              complaint.description,
                            ),

                            const SizedBox(height: 10),

                            Row(
                              children: [
                                Chip(
                                  backgroundColor:
                                      statusColor(
                                        complaint.status,
                                      ),
                                  label: Text(
                                    complaint.status,
                                    style:
                                        const TextStyle(
                                      color:
                                          Colors.white,
                                    ),
                                  ),
                                ),

                                const Spacer(),

                                Text(
                                  complaint.createdAt
                                      .toString()
                                      .split(" ")
                                      .first,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}