import 'package:flutter/material.dart';

import '../../models/admin_user.dart';
import '../../services/admin_user_service.dart';
import 'user_payment_history_screen.dart';
import 'user_complaints_screen.dart';

class UserDetailScreen extends StatefulWidget {
  final String token;
  final int userId;

  const UserDetailScreen({
    super.key,
    required this.token,
    required this.userId,
  });

  @override
  State<UserDetailScreen> createState() => _UserDetailScreenState();
}

class _UserDetailScreenState extends State<UserDetailScreen> {
  final AdminUserService _service = AdminUserService();

  AdminUser? user;

  bool isLoading = true;
  bool updating = false;
  String? error;

  @override
  void initState() {
    super.initState();
    loadUser();
  }

  Future<void> loadUser() async {
    try {
      final result = await _service.getUser(
        token: widget.token,
        userId: widget.userId,
      );

      if (!mounted) return;

      setState(() {
        user = result;
        isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        error = e.toString();
        isLoading = false;
      });
    }
  }

  Future<void> updateStatus(bool active) async {
    setState(() {
      updating = true;
    });

    try {
      await _service.updateUserStatus(
        token: widget.token,
        userId: widget.userId,
        isActive: active,
      );

      await loadUser();

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            active
                ? "User reactivated successfully"
                : "User suspended successfully",
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.toString()),
        ),
      );
    }

    if (mounted) {
      setState(() {
        updating = false;
      });
    }
  }

  Widget infoTile(
    IconData icon,
    String title,
    String value,
  ) {
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title),
        subtitle: Text(value),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (error != null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text("User Details"),
        ),
        body: Center(
          child: Text(error!),
        ),
      );
    }

    final u = user!;

    return Scaffold(
      appBar: AppBar(
        title: Text(u.fullName),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            CircleAvatar(
              radius: 45,
              child: Text(
                u.fullName.isNotEmpty
                    ? u.fullName[0].toUpperCase()
                    : "?",
                style: const TextStyle(
                  fontSize: 32,
                ),
              ),
            ),

            const SizedBox(height: 20),

            infoTile(
              Icons.person,
              "Full Name",
              u.fullName,
            ),

            infoTile(
              Icons.phone,
              "Phone Number",
              u.phoneNumber,
            ),

            infoTile(
              Icons.email,
              "Email",
              u.email ?? "-",
            ),

            infoTile(
              Icons.badge,
              "Role",
              u.role,
            ),

            infoTile(
              Icons.verified_user,
              "Account Status",
              u.isActive ? "Active" : "Suspended",
            ),

            const SizedBox(height: 30),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: Icon(
                  u.isActive
                      ? Icons.block
                      : Icons.check_circle,
                ),
                label: Text(
                  u.isActive
                      ? "Suspend User"
                      : "Reactivate User",
                ),
                onPressed: updating
                    ? null
                    : () => updateStatus(!u.isActive),
              ),
            ),

            const SizedBox(height: 25),

            const Divider(),

            ListTile(
              leading: const Icon(Icons.history),
              title: const Text("Ride History"),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("Coming soon"),
                  ),
                );
              },
            ),

            ListTile(
              leading: const Icon(Icons.payments),
              title: const Text("Payment History"),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => UserPaymentHistoryScreen(
                      token: widget.token,
                       userId: widget.userId,)
                  
                  ),
                );
              },
            ),

            ListTile(
  leading: const Icon(Icons.report),
  title: const Text("Complaints"),
  trailing: const Icon(Icons.chevron_right),
  onTap: () {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => UserComplaintsScreen(
          token: widget.token,
          userId: widget.userId,
        ),
      ),
    );
  },
),
          ],
        ),
      ),
    );
  }
}