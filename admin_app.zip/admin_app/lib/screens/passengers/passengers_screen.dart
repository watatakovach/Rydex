import 'package:flutter/material.dart';
import '../../services/admin_api_service.dart';

class PassengersScreen extends StatefulWidget {
  final String token;

  const PassengersScreen({
    super.key,
    required this.token,
  });

  @override
  State<PassengersScreen> createState() => _PassengersScreenState();
}

class _PassengersScreenState extends State<PassengersScreen> {
  // ============================================================
  // DATA
  // ============================================================

  List<dynamic> passengers = [];
  List<dynamic> filteredPassengers = [];

  bool isLoading = true;
  String? errorMessage;

  final TextEditingController searchController =
      TextEditingController();

  late AdminApiService api;

  // ============================================================
  // COLORS
  // ============================================================

  static const Color rydexBlue = Color(0xFF2563EB);
  static const Color background = Color(0xFFF6F8FC);
  static const Color cardColor = Colors.white;
  static const Color textDark = Color(0xFF111827);
  static const Color textMuted = Color(0xFF6B7280);
  static const Color borderColor = Color(0xFFE5E7EB);

  // ============================================================
  // INIT
  // ============================================================

  @override
  void initState() {
    super.initState();

    api = AdminApiService();
    api.setToken(widget.token);

    searchController.addListener(filterPassengers);

    loadPassengers();
  }

  @override
  void dispose() {
    searchController.removeListener(filterPassengers);
    searchController.dispose();
    super.dispose();
  }

  // ============================================================
  // LOAD PASSENGERS
  // ============================================================

  Future<void> loadPassengers() async {
    if (mounted) {
      setState(() {
        isLoading = true;
        errorMessage = null;
      });
    }

    try {
      final result = await api.getPassengers();

      if (!mounted) return;

      setState(() {
        passengers = result;
        filteredPassengers = result;
        isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isLoading = false;
        errorMessage = e.toString().replaceFirst(
              'Exception: ',
              '',
            );
      });
    }
  }

  // ============================================================
  // SEARCH
  // ============================================================

  void filterPassengers() {
    final query = searchController.text.toLowerCase().trim();

    final results = passengers.where((passenger) {
      final name = (passenger['full_name'] ?? '')
          .toString()
          .toLowerCase();

      final phone = (passenger['phone_number'] ?? '')
          .toString()
          .toLowerCase();

      final email = (passenger['email'] ?? '')
          .toString()
          .toLowerCase();

      return query.isEmpty ||
          name.contains(query) ||
          phone.contains(query) ||
          email.contains(query);
    }).toList();

    if (!mounted) return;

    setState(() {
      filteredPassengers = results;
    });
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final horizontalPadding =
                constraints.maxWidth >= 1400 ? 36.0 : 28.0;

            return Padding(
              padding: EdgeInsets.fromLTRB(
                horizontalPadding,
                28,
                horizontalPadding,
                28,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  buildHeader(),
                  const SizedBox(height: 26),
                  buildSummaryCards(),
                  const SizedBox(height: 24),
                  buildToolbar(),
                  const SizedBox(height: 20),
                  Expanded(
                    child: buildContent(),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  // ============================================================
  // HEADER
  // ============================================================

  Widget buildHeader() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 46,
          height: 46,
          decoration: BoxDecoration(
            color: rydexBlue.withValues(alpha: 0.10),
            borderRadius: BorderRadius.circular(13),
          ),
          child: const Icon(
            Icons.people_alt_outlined,
            color: rydexBlue,
            size: 24,
          ),
        ),
        const SizedBox(width: 15),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Passenger Management',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w800,
                  color: textDark,
                  letterSpacing: -0.5,
                ),
              ),
              SizedBox(height: 5),
              Text(
                'Manage RYDEX passengers, accounts and activity.',
                style: TextStyle(
                  fontSize: 14,
                  color: textMuted,
                ),
              ),
            ],
          ),
        ),
        buildRefreshButton(),
      ],
    );
  }

  // ============================================================
  // REFRESH BUTTON
  // ============================================================

  Widget buildRefreshButton() {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: isLoading ? null : loadPassengers,
        child: Container(
          padding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 12,
          ),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: borderColor,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (isLoading)
                const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: rydexBlue,
                  ),
                )
              else
                const Icon(
                  Icons.refresh_rounded,
                  size: 19,
                  color: textDark,
                ),
              const SizedBox(width: 8),
              const Text(
                'Refresh',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: textDark,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // SUMMARY CARDS
  // ============================================================

  Widget buildSummaryCards() {
    final total = passengers.length;

    final active = passengers.where((passenger) {
      return passenger['is_active'] == true;
    }).length;

    final suspended = passengers.where((passenger) {
      return passenger['is_active'] == false;
    }).length;

    return LayoutBuilder(
      builder: (context, constraints) {
        final cardWidth = constraints.maxWidth >= 1000
            ? (constraints.maxWidth - 36) / 3
            : constraints.maxWidth;

        return Wrap(
          spacing: 18,
          runSpacing: 18,
          children: [
            SizedBox(
              width: cardWidth,
              child: buildSummaryCard(
                title: 'Total Passengers',
                value: total.toString(),
                icon: Icons.people_alt_outlined,
                iconColor: rydexBlue,
                description: 'Registered accounts',
              ),
            ),
            SizedBox(
              width: cardWidth,
              child: buildSummaryCard(
                title: 'Active Accounts',
                value: active.toString(),
                icon: Icons.check_circle_outline,
                iconColor: const Color(0xFF16A34A),
                description: 'Currently active',
              ),
            ),
            SizedBox(
              width: cardWidth,
              child: buildSummaryCard(
                title: 'Suspended',
                value: suspended.toString(),
                icon: Icons.block_outlined,
                iconColor: const Color(0xFFDC2626),
                description: 'Restricted accounts',
              ),
            ),
          ],
        );
      },
    );
  }

  Widget buildSummaryCard({
    required String title,
    required String value,
    required IconData icon,
    required Color iconColor,
    required String description,
  }) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: borderColor,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.025),
            blurRadius: 18,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: iconColor.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(13),
            ),
            child: Icon(
              icon,
              color: iconColor,
              size: 23,
            ),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 13,
                    color: textMuted,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: textDark,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  description,
                  style: const TextStyle(
                    fontSize: 11,
                    color: textMuted,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // TOOLBAR
  // ============================================================

  Widget buildToolbar() {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: 48,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: borderColor,
              ),
            ),
            child: TextField(
              controller: searchController,
              style: const TextStyle(
                fontSize: 14,
                color: textDark,
              ),
              decoration: InputDecoration(
                hintText:
                    'Search passengers by name, phone or email...',
                hintStyle: const TextStyle(
                  color: Color(0xFF9CA3AF),
                  fontSize: 13,
                ),
                prefixIcon: const Icon(
                  Icons.search_rounded,
                  color: textMuted,
                  size: 21,
                ),
                suffixIcon: searchController.text.isNotEmpty
                    ? IconButton(
                        tooltip: 'Clear search',
                        onPressed: searchController.clear,
                        icon: const Icon(
                          Icons.close_rounded,
                          size: 18,
                          color: textMuted,
                        ),
                      )
                    : null,
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 13,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: 14),
        buildResultCount(),
      ],
    );
  }

  Widget buildResultCount() {
    return Container(
      height: 48,
      padding: const EdgeInsets.symmetric(
        horizontal: 16,
      ),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: borderColor,
        ),
      ),
      child: Text(
        '${filteredPassengers.length} passenger${filteredPassengers.length == 1 ? '' : 's'}',
        style: const TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w600,
          color: textMuted,
        ),
      ),
    );
  }

  // ============================================================
  // CONTENT
  // ============================================================

  Widget buildContent() {
    if (isLoading) {
      return buildLoadingState();
    }

    if (errorMessage != null) {
      return buildError();
    }

    if (passengers.isEmpty) {
      return buildEmptyState();
    }

    if (filteredPassengers.isEmpty) {
      return buildNoSearchResults();
    }

    return RefreshIndicator(
      color: rydexBlue,
      onRefresh: loadPassengers,
      child: ListView.builder(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.only(
          bottom: 20,
        ),
        itemCount: filteredPassengers.length,
        itemBuilder: (context, index) {
          return buildPassengerCard(
            filteredPassengers[index],
          );
        },
      ),
    );
  }

  // ============================================================
  // LOADING
  // ============================================================

  Widget buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              color: rydexBlue.withValues(alpha: 0.08),
              shape: BoxShape.circle,
            ),
            child: const Padding(
              padding: EdgeInsets.all(17),
              child: CircularProgressIndicator(
                strokeWidth: 2.5,
                color: rydexBlue,
              ),
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            'Loading passengers...',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w600,
              color: textDark,
            ),
          ),
          const SizedBox(height: 5),
          const Text(
            'Please wait while we fetch passenger data.',
            style: TextStyle(
              fontSize: 13,
              color: textMuted,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // ERROR
  // ============================================================

  Widget buildError() {
    return Center(
      child: Container(
        constraints: const BoxConstraints(
          maxWidth: 500,
        ),
        padding: const EdgeInsets.all(30),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: borderColor,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                color: Colors.red.withValues(alpha: 0.08),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.cloud_off_outlined,
                color: Colors.red,
                size: 30,
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'Unable to load passengers',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: textDark,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              errorMessage!,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 13,
                color: textMuted,
              ),
            ),
            const SizedBox(height: 22),
            ElevatedButton.icon(
              onPressed: loadPassengers,
              style: ElevatedButton.styleFrom(
                backgroundColor: rydexBlue,
                foregroundColor: Colors.white,
                elevation: 0,
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 13,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              icon: const Icon(
                Icons.refresh_rounded,
                size: 18,
              ),
              label: const Text(
                'Try Again',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // EMPTY STATE
  // ============================================================

  Widget buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 82,
            height: 82,
            decoration: BoxDecoration(
              color: rydexBlue.withValues(alpha: 0.07),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.people_outline_rounded,
              size: 40,
              color: rydexBlue,
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'No Passengers Yet',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: textDark,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'No passenger accounts have been registered yet.',
            style: TextStyle(
              color: textMuted,
              fontSize: 13,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SEARCH EMPTY STATE
  // ============================================================

  Widget buildNoSearchResults() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              color: Colors.grey.withValues(alpha: 0.08),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.search_off_rounded,
              size: 32,
              color: textMuted,
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            'No matching passengers',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: textDark,
            ),
          ),
          const SizedBox(height: 7),
          Text(
            'No passenger matches "${searchController.text}".',
            style: const TextStyle(
              fontSize: 13,
              color: textMuted,
            ),
          ),
          const SizedBox(height: 18),
          TextButton.icon(
            onPressed: searchController.clear,
            icon: const Icon(
              Icons.clear_rounded,
              size: 17,
            ),
            label: const Text('Clear search'),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // PASSENGER CARD
  // ============================================================

  Widget buildPassengerCard(
    Map<String, dynamic> passenger,
  ) {
    final id = passenger['id'] ?? 'N/A';

    final name =
        passenger['full_name'] ?? 'Unknown Passenger';

    final phone =
        passenger['phone_number'] ?? 'Not provided';

    final email =
        passenger['email'] ?? 'Not provided';

    final isActive =
        passenger['is_active'] ?? true;

    final nameText = name.toString();

    final initial = nameText.isNotEmpty
        ? nameText.substring(0, 1).toUpperCase()
        : '?';

    return Container(
      margin: const EdgeInsets.only(
        bottom: 12,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: borderColor,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.018),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => showPassengerDetails(passenger),
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 20,
              vertical: 17,
            ),
            child: Row(
              children: [
                buildAvatar(
                  initial,
                  isActive,
                ),
                const SizedBox(width: 16),
                Expanded(
                  flex: 2,
                  child: buildPassengerIdentity(
                    nameText,
                    id,
                    isActive,
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: buildContactInfo(
                    phone,
                    email,
                  ),
                ),
                const SizedBox(width: 15),
                buildStatusChip(
                  isActive ? 'Active' : 'Suspended',
                  isActive,
                ),
                const SizedBox(width: 12),
                buildPassengerMenu(passenger),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // AVATAR
  // ============================================================

  Widget buildAvatar(
    String initial,
    bool active,
  ) {
    return Stack(
      children: [
        Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(
            color: rydexBlue.withValues(alpha: 0.09),
            shape: BoxShape.circle,
          ),
          alignment: Alignment.center,
          child: Text(
            initial,
            style: const TextStyle(
              fontSize: 19,
              fontWeight: FontWeight.w800,
              color: rydexBlue,
            ),
          ),
        ),
        Positioned(
          right: 1,
          bottom: 1,
          child: Container(
            width: 13,
            height: 13,
            decoration: BoxDecoration(
              color: active
                  ? const Color(0xFF22C55E)
                  : const Color(0xFFEF4444),
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.white,
                width: 2,
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ============================================================
  // IDENTITY
  // ============================================================

  Widget buildPassengerIdentity(
    String name,
    dynamic id,
    bool active,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          name,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w700,
            color: textDark,
          ),
        ),
        const SizedBox(height: 5),
        Row(
          children: [
            const Icon(
              Icons.badge_outlined,
              size: 14,
              color: textMuted,
            ),
            const SizedBox(width: 5),
            Text(
              'Passenger #$id',
              style: const TextStyle(
                fontSize: 12,
                color: textMuted,
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ============================================================
  // CONTACT INFO
  // ============================================================

  Widget buildContactInfo(
    dynamic phone,
    dynamic email,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(
              Icons.phone_outlined,
              size: 14,
              color: textMuted,
            ),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                phone.toString(),
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 12,
                  color: textDark,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 7),
        Row(
          children: [
            const Icon(
              Icons.email_outlined,
              size: 14,
              color: textMuted,
            ),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                email.toString(),
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 12,
                  color: textMuted,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ============================================================
  // STATUS CHIP
  // ============================================================

  Widget buildStatusChip(
    String text,
    bool active,
  ) {
    final color = active
        ? const Color(0xFF16A34A)
        : const Color(0xFFDC2626);

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 11,
        vertical: 7,
      ),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: color.withValues(alpha: 0.15),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 6),
          Text(
            text,
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.w700,
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // PASSENGER MENU
  // ============================================================

  Widget buildPassengerMenu(
    Map<String, dynamic> passenger,
  ) {
    final isActive =
        passenger['is_active'] ?? true;

    return PopupMenuButton<String>(
      tooltip: 'Passenger actions',
      position: PopupMenuPosition.under,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      elevation: 8,
      onSelected: (value) {
        if (value == 'details') {
          showPassengerDetails(passenger);
        }

        if (value == 'rides') {
          showRideHistory(passenger);
        }

        if (value == 'cancellations') {
          showCancellationHistory(passenger);
        }

        if (value == 'status') {
          confirmStatusChange(passenger);
        }
      },
      itemBuilder: (context) {
        return [
          const PopupMenuItem(
            value: 'details',
            child: Row(
              children: [
                Icon(
                  Icons.person_outline,
                  size: 19,
                ),
                SizedBox(width: 10),
                Text('View Details'),
              ],
            ),
          ),
          const PopupMenuItem(
            value: 'rides',
            child: Row(
              children: [
                Icon(
                  Icons.local_taxi_outlined,
                  size: 19,
                ),
                SizedBox(width: 10),
                Text('Ride History'),
              ],
            ),
          ),
          const PopupMenuItem(
            value: 'cancellations',
            child: Row(
              children: [
                Icon(
                  Icons.cancel_outlined,
                  size: 19,
                ),
                SizedBox(width: 10),
                Text('Cancellation History'),
              ],
            ),
          ),
          const PopupMenuDivider(),
          PopupMenuItem(
            value: 'status',
            child: Row(
              children: [
                Icon(
                  isActive
                      ? Icons.block_outlined
                      : Icons.check_circle_outline,
                  size: 19,
                  color: isActive
                      ? Colors.red
                      : Colors.green,
                ),
                const SizedBox(width: 10),
                Text(
                  isActive
                      ? 'Suspend Account'
                      : 'Activate Account',
                ),
              ],
            ),
          ),
        ];
      },
      child: Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: const Color(0xFFF9FAFB),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: borderColor,
          ),
        ),
        child: const Icon(
          Icons.more_horiz_rounded,
          size: 20,
          color: textMuted,
        ),
      ),
    );
  }

  // ============================================================
  // PASSENGER DETAILS
  // ============================================================

  Future<void> showPassengerDetails(
    Map<String, dynamic> passenger,
  ) async {
    final id = passenger['id'];

    if (id == null) return;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return Dialog(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: SizedBox(
            width: 600,
            child: FutureBuilder<Map<String, dynamic>>(
              future: api.getPassengerDetails(
                int.parse(id.toString()),
              ),
              builder: (context, snapshot) {
                if (snapshot.connectionState ==
                    ConnectionState.waiting) {
                  return buildDialogLoading();
                }

                if (snapshot.hasError) {
                  return buildDialogError(
                    dialogContext,
                    snapshot.error.toString(),
                  );
                }

                final data =
                    snapshot.data ?? passenger;

                final isActive =
                    data['is_active'] == true;

                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    buildDialogHeader(
                      title: data['full_name'] ??
                          'Passenger Details',
                      subtitle:
                          'Passenger account information',
                      icon: Icons.person_outline,
                      onClose: () =>
                          Navigator.pop(dialogContext),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(
                        28,
                        10,
                        28,
                        28,
                      ),
                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          buildProfileBanner(
                            data,
                            isActive,
                          ),
                          const SizedBox(height: 25),
                          buildDetailSection(
                            'ACCOUNT INFORMATION',
                            [
                              detailRow(
                                'Passenger ID',
                                data['id'],
                              ),
                              detailRow(
                                'Full Name',
                                data['full_name'],
                              ),
                              detailRow(
                                'Phone',
                                data['phone_number'],
                              ),
                              detailRow(
                                'Email',
                                data['email'],
                              ),
                              detailRow(
                                'Role',
                                data['role'],
                              ),
                              detailRow(
                                'Status',
                                isActive
                                    ? 'Active'
                                    : 'Suspended',
                              ),
                              detailRow(
                                'Registered',
                                formatDate(
                                  data['created_at'],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 20),
                          Row(
                            mainAxisAlignment:
                                MainAxisAlignment.end,
                            children: [
                              OutlinedButton(
                                onPressed: () =>
                                    Navigator.pop(
                                  dialogContext,
                                ),
                                style: OutlinedButton.styleFrom(
                                  padding:
                                      const EdgeInsets.symmetric(
                                    horizontal: 20,
                                    vertical: 13,
                                  ),
                                  shape:
                                      RoundedRectangleBorder(
                                    borderRadius:
                                        BorderRadius.circular(
                                      10,
                                    ),
                                  ),
                                ),
                                child:
                                    const Text('Close'),
                              ),
                              const SizedBox(width: 10),
                              ElevatedButton.icon(
                                onPressed: () {
                                  Navigator.pop(
                                    dialogContext,
                                  );

                                  confirmStatusChange(
                                    data,
                                  );
                                },
                                style:
                                    ElevatedButton.styleFrom(
                                  backgroundColor: isActive
                                      ? Colors.red
                                      : const Color(
                                          0xFF16A34A,
                                        ),
                                  foregroundColor:
                                      Colors.white,
                                  elevation: 0,
                                  padding:
                                      const EdgeInsets.symmetric(
                                    horizontal: 18,
                                    vertical: 13,
                                  ),
                                  shape:
                                      RoundedRectangleBorder(
                                    borderRadius:
                                        BorderRadius.circular(
                                      10,
                                    ),
                                  ),
                                ),
                                icon: Icon(
                                  isActive
                                      ? Icons.block_outlined
                                      : Icons
                                          .check_circle_outline,
                                  size: 18,
                                ),
                                label: Text(
                                  isActive
                                      ? 'Suspend'
                                      : 'Activate',
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // PROFILE BANNER
  // ============================================================

  Widget buildProfileBanner(
    Map<String, dynamic> data,
    bool active,
  ) {
    final name =
        data['full_name']?.toString() ??
            'Passenger';

    final initial = name.isNotEmpty
        ? name.substring(0, 1).toUpperCase()
        : '?';

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: borderColor,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: rydexBlue.withValues(alpha: 0.10),
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: Text(
              initial,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: rydexBlue,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: textDark,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  data['email']?.toString() ??
                      'No email provided',
                  style: const TextStyle(
                    fontSize: 12,
                    color: textMuted,
                  ),
                ),
              ],
            ),
          ),
          buildStatusChip(
            active ? 'Active' : 'Suspended',
            active,
          ),
        ],
      ),
    );
  }

  // ============================================================
  // DIALOG HEADER
  // ============================================================

  Widget buildDialogHeader({
    required String title,
    required String subtitle,
    required IconData icon,
    required VoidCallback onClose,
  }) {
    return Container(
      padding: const EdgeInsets.fromLTRB(
        25,
        22,
        18,
        20,
      ),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: borderColor,
          ),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: rydexBlue.withValues(alpha: 0.09),
              borderRadius: BorderRadius.circular(11),
            ),
            child: Icon(
              icon,
              color: rydexBlue,
              size: 21,
            ),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                    color: textDark,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  subtitle,
                  style: const TextStyle(
                    fontSize: 12,
                    color: textMuted,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: onClose,
            icon: const Icon(
              Icons.close_rounded,
              color: textMuted,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // DIALOG LOADING
  // ============================================================

  Widget buildDialogLoading() {
    return const SizedBox(
      height: 300,
      child: Center(
        child: Column(
          mainAxisAlignment:
              MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(
              color: rydexBlue,
              strokeWidth: 2.5,
            ),
            SizedBox(height: 18),
            Text(
              'Loading passenger details...',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: textDark,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // DIALOG ERROR
  // ============================================================

  Widget buildDialogError(
    BuildContext dialogContext,
    String error,
  ) {
    return Padding(
      padding: const EdgeInsets.all(30),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(
            Icons.error_outline_rounded,
            size: 46,
            color: Colors.red,
          ),
          const SizedBox(height: 15),
          const Text(
            'Unable to load details',
            style: TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            error.replaceFirst(
              'Exception: ',
              '',
            ),
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: textMuted,
              fontSize: 13,
            ),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: () =>
                Navigator.pop(dialogContext),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // STATUS CONFIRMATION
  // ============================================================

  Future<void> confirmStatusChange(
    Map<String, dynamic> passenger,
  ) async {
    final id = passenger['id'];

    if (id == null) return;

    final currentlyActive =
        passenger['is_active'] == true;

    final action =
        currentlyActive ? 'Suspend' : 'Activate';

    final name =
        passenger['full_name'] ??
            'this passenger';

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
          title: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: currentlyActive
                      ? Colors.red.withValues(alpha: 0.08)
                      : Colors.green.withValues(alpha: 0.08),
                  borderRadius:
                      BorderRadius.circular(10),
                ),
                child: Icon(
                  currentlyActive
                      ? Icons.block_outlined
                      : Icons.check_circle_outline,
                  color: currentlyActive
                      ? Colors.red
                      : Colors.green,
                  size: 21,
                ),
              ),
              const SizedBox(width: 12),
              Text('$action Passenger'),
            ],
          ),
          content: Text(
            currentlyActive
                ? 'Are you sure you want to suspend $name? The passenger will no longer be able to use their RYDEX account.'
                : 'Are you sure you want to activate $name? The passenger will regain access to their RYDEX account.',
            style: const TextStyle(
              height: 1.5,
              color: textMuted,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () =>
                  Navigator.pop(
                dialogContext,
                false,
              ),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () =>
                  Navigator.pop(
                dialogContext,
                true,
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: currentlyActive
                    ? Colors.red
                    : Colors.green,
                foregroundColor: Colors.white,
                elevation: 0,
              ),
              child: Text(action),
            ),
          ],
        );
      },
    );

    if (confirmed != true || !mounted) return;

    await changePassengerStatus(
      int.parse(id.toString()),
      !currentlyActive,
    );
  }

  // ============================================================
  // CHANGE STATUS
  // ============================================================

  Future<void> changePassengerStatus(
    int userId,
    bool isActive,
  ) async {
    try {
      await api.updatePassengerStatus(
        userId: userId,
        isActive: isActive,
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          backgroundColor:
              isActive ? Colors.green : Colors.red,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          content: Row(
            children: [
              Icon(
                isActive
                    ? Icons.check_circle_outline
                    : Icons.block_outlined,
                color: Colors.white,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  isActive
                      ? 'Passenger account activated successfully.'
                      : 'Passenger account suspended successfully.',
                ),
              ),
            ],
          ),
        ),
      );

      await loadPassengers();
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.red,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          content: Text(
            e.toString().replaceFirst(
                  'Exception: ',
                  '',
                ),
          ),
        ),
      );
    }
  }

  // ============================================================
  // RIDE HISTORY
  // ============================================================

  Future<void> showRideHistory(
    Map<String, dynamic> passenger,
  ) async {
    final id = passenger['id'];

    if (id == null) return;

    showDialog(
      context: context,
      builder: (dialogContext) {
        return Dialog(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: SizedBox(
            width: 760,
            height: 590,
            child: Column(
              children: [
                buildDialogHeader(
                  title:
                      '${passenger['full_name'] ?? 'Passenger'} — Ride History',
                  subtitle:
                      'All rides associated with this passenger',
                  icon: Icons.local_taxi_outlined,
                  onClose: () =>
                      Navigator.pop(dialogContext),
                ),
                Expanded(
                  child: FutureBuilder<List<dynamic>>(
                    future: api.getPassengerRides(
                      int.parse(id.toString()),
                    ),
                    builder:
                        (context, snapshot) {
                      if (snapshot.connectionState ==
                          ConnectionState.waiting) {
                        return const Center(
                          child:
                              CircularProgressIndicator(
                            color: rydexBlue,
                          ),
                        );
                      }

                      if (snapshot.hasError) {
                        return buildHistoryError(
                          snapshot.error.toString(),
                        );
                      }

                      final rides =
                          snapshot.data ?? [];

                      if (rides.isEmpty) {
                        return buildNoHistory(
                          icon: Icons
                              .local_taxi_outlined,
                          title:
                              'No rides yet',
                          message:
                              'This passenger has not completed any rides.',
                        );
                      }

                      return ListView.separated(
                        padding:
                            const EdgeInsets.all(24),
                        itemCount: rides.length,
                        separatorBuilder:
                            (context, index) =>
                                const SizedBox(
                          height: 10,
                        ),
                        itemBuilder:
                            (context, index) {
                          final ride =
                              rides[index];

                          return buildRideHistoryItem(
                            ride,
                          );
                        },
                      );
                    },
                  ),
                ),
                buildDialogFooter(
                  dialogContext,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // RIDE HISTORY ITEM
  // ============================================================

  Widget buildRideHistoryItem(
    Map<String, dynamic> ride,
  ) {
    final status =
        ride['status']?.toString() ??
            'Unknown';

    final fare =
        ride['final_fare'] ??
            ride['estimated_fare'] ??
            'N/A';

    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: const Color(0xFFF9FAFB),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(
          color: borderColor,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 43,
            height: 43,
            decoration: BoxDecoration(
              color: rydexBlue.withValues(alpha: 0.09),
              borderRadius: BorderRadius.circular(11),
            ),
            child: const Icon(
              Icons.local_taxi_outlined,
              color: rydexBlue,
              size: 21,
            ),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  'Ride #${ride['id'] ?? 'N/A'}',
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    color: textDark,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  'Fare: $fare',
                  style: const TextStyle(
                    fontSize: 12,
                    color: textMuted,
                  ),
                ),
              ],
            ),
          ),
          buildHistoryStatus(status),
        ],
      ),
    );
  }

  // ============================================================
  // CANCELLATION HISTORY
  // ============================================================

  Future<void> showCancellationHistory(
    Map<String, dynamic> passenger,
  ) async {
    final id = passenger['id'];

    if (id == null) return;

    showDialog(
      context: context,
      builder: (dialogContext) {
        return Dialog(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: SizedBox(
            width: 760,
            height: 590,
            child: Column(
              children: [
                buildDialogHeader(
                  title:
                      '${passenger['full_name'] ?? 'Passenger'} — Cancellations',
                  subtitle:
                      'Cancelled rides associated with this passenger',
                  icon: Icons.cancel_outlined,
                  onClose: () =>
                      Navigator.pop(dialogContext),
                ),
                Expanded(
                  child:
                      FutureBuilder<List<dynamic>>(
                    future:
                        api.getPassengerCancellations(
                      int.parse(id.toString()),
                    ),
                    builder:
                        (context, snapshot) {
                      if (snapshot.connectionState ==
                          ConnectionState.waiting) {
                        return const Center(
                          child:
                              CircularProgressIndicator(
                            color: rydexBlue,
                          ),
                        );
                      }

                      if (snapshot.hasError) {
                        return buildHistoryError(
                          snapshot.error.toString(),
                        );
                      }

                      final cancellations =
                          snapshot.data ?? [];

                      if (cancellations.isEmpty) {
                        return buildNoHistory(
                          icon: Icons
                              .check_circle_outline,
                          title:
                              'No cancellations',
                          message:
                              'This passenger has no recorded cancellations.',
                          success: true,
                        );
                      }

                      return ListView.separated(
                        padding:
                            const EdgeInsets.all(24),
                        itemCount:
                            cancellations.length,
                        separatorBuilder:
                            (context, index) =>
                                const SizedBox(
                          height: 10,
                        ),
                        itemBuilder:
                            (context, index) {
                          final ride =
                              cancellations[index];

                          return buildCancellationItem(
                            ride,
                          );
                        },
                      );
                    },
                  ),
                ),
                buildDialogFooter(
                  dialogContext,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // CANCELLATION ITEM
  // ============================================================

  Widget buildCancellationItem(
    Map<String, dynamic> ride,
  ) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF7F7),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(
          color: Colors.red.withValues(alpha: 0.12),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 43,
            height: 43,
            decoration: BoxDecoration(
              color: Colors.red.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(11),
            ),
            child: const Icon(
              Icons.cancel_outlined,
              color: Colors.red,
              size: 21,
            ),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  'Ride #${ride['id'] ?? 'N/A'}',
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    color: textDark,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  'Requested: ${formatDate(ride['requested_at'])}',
                  style: const TextStyle(
                    fontSize: 12,
                    color: textMuted,
                  ),
                ),
              ],
            ),
          ),
          buildHistoryStatus(
            ride['status']?.toString() ??
                'Cancelled',
            cancelled: true,
          ),
        ],
      ),
    );
  }

  // ============================================================
  // HISTORY STATUS
  // ============================================================

  Widget buildHistoryStatus(
    String status, {
    bool cancelled = false,
  }) {
    final normalized =
        status.toLowerCase();

    Color color;

    if (cancelled ||
        normalized.contains('cancel')) {
      color = Colors.red;
    } else if (normalized.contains('complete')) {
      color = Colors.green;
    } else if (normalized.contains('pending')) {
      color = Colors.orange;
    } else if (normalized.contains('progress')) {
      color = rydexBlue;
    } else {
      color = textMuted;
    }

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 6,
      ),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        status,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          color: color,
        ),
      ),
    );
  }

  // ============================================================
  // HISTORY ERROR
  // ============================================================

  Widget buildHistoryError(
    String error,
  ) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment:
              MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.error_outline_rounded,
              size: 45,
              color: Colors.red,
            ),
            const SizedBox(height: 14),
            const Text(
              'Unable to load history',
              style: TextStyle(
                fontWeight: FontWeight.w700,
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 7),
            Text(
              error.replaceFirst(
                'Exception: ',
                '',
              ),
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: textMuted,
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // NO HISTORY
  // ============================================================

  Widget buildNoHistory({
    required IconData icon,
    required String title,
    required String message,
    bool success = false,
  }) {
    final color =
        success ? Colors.green : textMuted;

    return Center(
      child: Column(
        mainAxisAlignment:
            MainAxisAlignment.center,
        children: [
          Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.08),
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              size: 32,
              color: color,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            title,
            style: const TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w700,
              color: textDark,
            ),
          ),
          const SizedBox(height: 7),
          Text(
            message,
            style: const TextStyle(
              fontSize: 12,
              color: textMuted,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // DIALOG FOOTER
  // ============================================================

  Widget buildDialogFooter(
    BuildContext dialogContext,
  ) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: const BoxDecoration(
        border: Border(
          top: BorderSide(
            color: borderColor,
          ),
        ),
      ),
      alignment: Alignment.centerRight,
      child: OutlinedButton(
        onPressed: () =>
            Navigator.pop(dialogContext),
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(
            horizontal: 20,
            vertical: 12,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        child: const Text('Close'),
      ),
    );
  }

  // ============================================================
  // DETAIL SECTION
  // ============================================================

  Widget buildDetailSection(
    String title,
    List<Widget> children,
  ) {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w800,
            color: textMuted,
            letterSpacing: 1.1,
          ),
        ),
        const SizedBox(height: 13),
        ...children,
      ],
    );
  }

  // ============================================================
  // DETAIL ROW
  // ============================================================

  Widget detailRow(
    String label,
    dynamic value,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(
        vertical: 11,
      ),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Color(0xFFF0F1F3),
          ),
        ),
      ),
      child: Row(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 125,
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 12,
                color: textMuted,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value?.toString() ??
                  'Not provided',
              style: const TextStyle(
                fontSize: 13,
                color: textDark,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // DATE FORMATTER
  // ============================================================

  String formatDate(dynamic value) {
    if (value == null) {
      return 'Not provided';
    }

    try {
      final date = DateTime.parse(
        value.toString(),
      );

      return '${date.day.toString().padLeft(2, '0')}/'
          '${date.month.toString().padLeft(2, '0')}/'
          '${date.year} '
          '${date.hour.toString().padLeft(2, '0')}:'
          '${date.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return value.toString();
    }
  }
}