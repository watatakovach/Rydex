import 'package:flutter/material.dart';

import '../../services/admin_rating_service.dart';

class RatingsScreen extends StatefulWidget {
  const RatingsScreen({super.key});

  @override
  State<RatingsScreen> createState() => _RatingsScreenState();
}

class _RatingsScreenState extends State<RatingsScreen> {
  final TextEditingController _driverController = TextEditingController();

  bool _loading = false;

  double average = 0;

  int totalRatings = 0;

  List ratings = [];

  Future<void> loadRatings() async {
    if (_driverController.text.isEmpty) return;

    setState(() {
      _loading = true;
    });

    try {
      final id = int.parse(_driverController.text);

      final summary = await AdminRatingService.getDriverRatingSummary(id);

      final list = await AdminRatingService.getDriverRatings(id);

      setState(() {
        average = (summary["average_rating"] ?? 0).toDouble();
        totalRatings = summary["total_ratings"] ?? 0;
        ratings = list;
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(e.toString())));

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(e.toString())));
    }

    setState(() {
      _loading = false;
    });
  }

  Widget statCard(String title, String value, IconData icon, Color color) {
    return Expanded(
      child: Card(
        elevation: 3,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            children: [
              Icon(icon, size: 35, color: color),
              const SizedBox(height: 10),
              Text(
                value,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 24,
                ),
              ),
              Text(title),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildStars(int rating) {
    return Row(
      children: List.generate(
        5,
        (index) => Icon(
          index < rating ? Icons.star : Icons.star_border,
          color: Colors.orange,
          size: 20,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Driver Ratings")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: _driverController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: "Driver ID",
                suffixIcon: IconButton(
                  icon: const Icon(Icons.search),
                  onPressed: loadRatings,
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            const SizedBox(height: 20),
            if (_loading)
              const Center(child: CircularProgressIndicator())
            else ...[
              Row(
                children: [
                  statCard(
                    "Average",
                    average.toStringAsFixed(1),
                    Icons.star,
                    Colors.amber,
                  ),
                  const SizedBox(width: 15),
                  statCard(
                    "Ratings",
                    totalRatings.toString(),
                    Icons.people,
                    Colors.blue,
                  ),
                ],
              ),
              const SizedBox(height: 25),
              Expanded(
                child: ratings.isEmpty
                    ? const Center(child: Text("No ratings found"))
                    : ListView.builder(
                        itemCount: ratings.length,
                        itemBuilder: (_, index) {
                          final rating = ratings[index];

                          return Card(
                            margin: const EdgeInsets.only(bottom: 12),
                            child: Padding(
                              padding: const EdgeInsets.all(15),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Ride #${rating["ride_id"]}",
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  buildStars(rating["rating"]),
                                  const SizedBox(height: 10),
                                  Text(rating["comment"] ?? "No comment"),
                                  const SizedBox(height: 10),
                                  Text(
                                    rating["created_at"],
                                    style: TextStyle(
                                      color: Colors.grey.shade600,
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
