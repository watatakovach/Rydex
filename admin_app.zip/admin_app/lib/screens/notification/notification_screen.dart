
import 'package:flutter/material.dart';

import '../../services/admin_api_service.dart';

class NotificationsScreen extends StatefulWidget {
  final String token;

  const NotificationsScreen({
    super.key,
    required this.token,
  });

  @override
  State<NotificationsScreen> createState() =>
      _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  late final AdminApiService api;

  bool loading = true;
  String? errorMessage;

  List<dynamic> notifications = [];

  int total = 0;
  int unread = 0;
  int read = 0;

  @override
  void initState() {
    super.initState();

    api = AdminApiService();
    api.setToken(widget.token);

    loadNotifications();
  }

  // ============================================================
  // LOAD NOTIFICATIONS
  // ============================================================

  Future<void> loadNotifications() async {
    if (!mounted) return;

    setState(() {
      loading = true;
      errorMessage = null;
    });

    try {
      debugPrint('🔔 Calling GET /admin/notifications');

      final result = await api.getNotifications();

      debugPrint('🔔 Notification API result: $result');

      if (!mounted) return;

      setState(() {
        notifications =
            result['notifications'] as List<dynamic>? ?? [];

        total = _toInt(result['total']);
        unread = _toInt(result['unread']);
        read = _toInt(result['read']);

        loading = false;
      });
    } catch (e) {
      debugPrint('❌ Notification API ERROR: $e');

      if (!mounted) return;

      setState(() {
        loading = false;
        errorMessage =
            e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  // ============================================================
  // SEND NOTIFICATION TO USER
  // ============================================================

  Future<void> showSendNotificationDialog() async {
    final userIdController = TextEditingController();
    final titleController = TextEditingController();
    final messageController = TextEditingController();
    final entityTypeController = TextEditingController();
    final entityIdController = TextEditingController();

    String selectedType = 'general';
    bool sending = false;

    try {
      await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) {
          return StatefulBuilder(
            builder: (dialogContext, setDialogState) {
              return AlertDialog(
                title: const Row(
                  children: [
                    Icon(Icons.notifications_active),
                    SizedBox(width: 10),
                    Text('Send Notification'),
                  ],
                ),
                content: SizedBox(
                  width: 500,
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextField(
                          controller: userIdController,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            labelText: 'User ID',
                            hintText: 'Enter recipient user ID',
                            prefixIcon: Icon(Icons.person),
                            border: OutlineInputBorder(),
                          ),
                        ),

                        const SizedBox(height: 16),

                        DropdownButtonFormField<String>(
                          initialValue: selectedType,
                          decoration: const InputDecoration(
                            labelText: 'Notification Type',
                            prefixIcon:
                                Icon(Icons.category_outlined),
                            border: OutlineInputBorder(),
                          ),
                          items: const [
                            DropdownMenuItem(
                              value: 'general',
                              child: Text('General'),
                            ),
                            DropdownMenuItem(
                              value: 'system',
                              child: Text('System'),
                            ),
                            DropdownMenuItem(
                              value: 'ride',
                              child: Text('Ride'),
                            ),
                            DropdownMenuItem(
                              value: 'payment',
                              child: Text('Payment'),
                            ),
                            DropdownMenuItem(
                              value: 'driver',
                              child: Text('Driver'),
                            ),
                            DropdownMenuItem(
                              value: 'verification',
                              child: Text('Verification'),
                            ),
                          ],
                          onChanged: sending
                              ? null
                              : (value) {
                                  if (value == null) return;

                                  setDialogState(() {
                                    selectedType = value;
                                  });
                                },
                        ),

                        const SizedBox(height: 16),

                        TextField(
                          controller: titleController,
                          textCapitalization:
                              TextCapitalization.sentences,
                          decoration: const InputDecoration(
                            labelText: 'Title',
                            hintText: 'Notification title',
                            prefixIcon: Icon(Icons.title),
                            border: OutlineInputBorder(),
                          ),
                        ),

                        const SizedBox(height: 16),

                        TextField(
                          controller: messageController,
                          maxLines: 4,
                          textCapitalization:
                              TextCapitalization.sentences,
                          decoration: const InputDecoration(
                            labelText: 'Message',
                            hintText:
                                'Write your notification...',
                            alignLabelWithHint: true,
                            prefixIcon:
                                Icon(Icons.message_outlined),
                            border: OutlineInputBorder(),
                          ),
                        ),

                        const SizedBox(height: 16),

                        TextField(
                          controller: entityTypeController,
                          decoration: const InputDecoration(
                            labelText: 'Entity Type (optional)',
                            hintText: 'e.g. ride',
                            prefixIcon: Icon(Icons.link),
                            border: OutlineInputBorder(),
                          ),
                        ),

                        const SizedBox(height: 16),

                        TextField(
                          controller: entityIdController,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            labelText: 'Entity ID (optional)',
                            hintText: 'e.g. 25',
                            prefixIcon: Icon(Icons.tag),
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                actions: [
                  TextButton(
                    onPressed: sending
                        ? null
                        : () {
                            Navigator.of(dialogContext).pop();
                          },
                    child: const Text('Cancel'),
                  ),

                  ElevatedButton.icon(
                    onPressed: sending
                        ? null
                        : () async {
                            final userId = int.tryParse(
                              userIdController.text.trim(),
                            );

                            final title =
                                titleController.text.trim();

                            final message =
                                messageController.text.trim();

                            if (userId == null || userId <= 0) {
                              showMessage(
                                'Enter a valid User ID.',
                              );
                              return;
                            }

                            if (title.isEmpty) {
                              showMessage(
                                'Enter a notification title.',
                              );
                              return;
                            }

                            if (message.isEmpty) {
                              showMessage(
                                'Enter a notification message.',
                              );
                              return;
                            }

                            int? entityId;

                            final entityIdText =
                                entityIdController.text.trim();

                            if (entityIdText.isNotEmpty) {
                              entityId = int.tryParse(entityIdText);

                              if (entityId == null) {
                                showMessage(
                                  'Entity ID must be a number.',
                                );
                                return;
                              }
                            }

                            setDialogState(() {
                              sending = true;
                            });

                            try {
                              await api.createNotification(
                                userId: userId,
                                type: selectedType,
                                title: title,
                                message: message,
                                entityType:
                                    entityTypeController.text
                                            .trim()
                                            .isEmpty
                                        ? null
                                        : entityTypeController
                                            .text
                                            .trim(),
                                entityId: entityId,
                              );

                              if (!mounted) return;

                              Navigator.of(dialogContext).pop();

                              showMessage(
                                'Notification sent successfully.',
                              );

                              await loadNotifications();
                            } catch (e) {
                              if (!mounted) return;

                              setDialogState(() {
                                sending = false;
                              });

                              showMessage(
                                'Failed to send notification: '
                                '${e.toString().replaceFirst(
                                      'Exception: ',
                                      '',
                                    )}',
                              );
                            }
                          },
                    icon: sending
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child:
                                CircularProgressIndicator(
                              strokeWidth: 2,
                            ),
                          )
                        : const Icon(Icons.send),
                    label: Text(
                      sending ? 'Sending...' : 'Send',
                    ),
                  ),
                ],
              );
            },
          );
        },
      );
    } finally {
      userIdController.dispose();
      titleController.dispose();
      messageController.dispose();
      entityTypeController.dispose();
      entityIdController.dispose();
    }
  }

  // ============================================================
  // BROADCAST NOTIFICATION
  // ============================================================

  Future<void> showBroadcastNotificationDialog() async {
    final titleController = TextEditingController();
    final messageController = TextEditingController();
    final entityTypeController = TextEditingController();
    final entityIdController = TextEditingController();

    String selectedType = 'general';
    bool sending = false;

    try {
      await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) {
          return StatefulBuilder(
            builder: (dialogContext, setDialogState) {
              return AlertDialog(
                title: const Row(
                  children: [
                    Icon(Icons.campaign),
                    SizedBox(width: 10),
                    Text('Broadcast Notification'),
                  ],
                ),
                content: SizedBox(
                  width: 500,
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: Colors.orange
                                .withValues(alpha: 0.1),
                            borderRadius:
                                BorderRadius.circular(8),
                          ),
                          child: const Row(
                            children: [
                              Icon(
                                Icons.info_outline,
                                color: Colors.orange,
                              ),
                              SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  'This notification will be sent '
                                  'to all eligible users.',
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 18),

                        DropdownButtonFormField<String>(
                          initialValue: selectedType,
                          decoration: const InputDecoration(
                            labelText: 'Notification Type',
                            prefixIcon:
                                Icon(Icons.category_outlined),
                            border: OutlineInputBorder(),
                          ),
                          items: const [
                            DropdownMenuItem(
                              value: 'general',
                              child: Text('General'),
                            ),
                            DropdownMenuItem(
                              value: 'system',
                              child: Text('System'),
                            ),
                            DropdownMenuItem(
                              value: 'ride',
                              child: Text('Ride'),
                            ),
                            DropdownMenuItem(
                              value: 'payment',
                              child: Text('Payment'),
                            ),
                            DropdownMenuItem(
                              value: 'driver',
                              child: Text('Driver'),
                            ),
                            DropdownMenuItem(
                              value: 'verification',
                              child: Text('Verification'),
                            ),
                          ],
                          onChanged: sending
                              ? null
                              : (value) {
                                  if (value == null) return;

                                  setDialogState(() {
                                    selectedType = value;
                                  });
                                },
                        ),

                        const SizedBox(height: 16),

                        TextField(
                          controller: titleController,
                          textCapitalization:
                              TextCapitalization.sentences,
                          decoration: const InputDecoration(
                            labelText: 'Title',
                            hintText: 'Broadcast title',
                            prefixIcon: Icon(Icons.title),
                            border: OutlineInputBorder(),
                          ),
                        ),

                        const SizedBox(height: 16),

                        TextField(
                          controller: messageController,
                          maxLines: 4,
                          textCapitalization:
                              TextCapitalization.sentences,
                          decoration: const InputDecoration(
                            labelText: 'Message',
                            hintText:
                                'Write broadcast message...',
                            alignLabelWithHint: true,
                            prefixIcon:
                                Icon(Icons.message_outlined),
                            border: OutlineInputBorder(),
                          ),
                        ),

                        const SizedBox(height: 16),

                        TextField(
                          controller: entityTypeController,
                          decoration: const InputDecoration(
                            labelText: 'Entity Type (optional)',
                            hintText: 'e.g. system',
                            prefixIcon: Icon(Icons.link),
                            border: OutlineInputBorder(),
                          ),
                        ),

                        const SizedBox(height: 16),

                        TextField(
                          controller: entityIdController,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            labelText: 'Entity ID (optional)',
                            hintText: 'e.g. 25',
                            prefixIcon: Icon(Icons.tag),
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                actions: [
                  TextButton(
                    onPressed: sending
                        ? null
                        : () {
                            Navigator.of(dialogContext).pop();
                          },
                    child: const Text('Cancel'),
                  ),

                  ElevatedButton.icon(
                    onPressed: sending
                        ? null
                        : () async {
                            final title =
                                titleController.text.trim();

                            final message =
                                messageController.text.trim();

                            if (title.isEmpty) {
                              showMessage(
                                'Enter a notification title.',
                              );
                              return;
                            }

                            if (message.isEmpty) {
                              showMessage(
                                'Enter a notification message.',
                              );
                              return;
                            }

                            int? entityId;

                            final entityIdText =
                                entityIdController.text.trim();

                            if (entityIdText.isNotEmpty) {
                              entityId = int.tryParse(entityIdText);

                              if (entityId == null) {
                                showMessage(
                                  'Entity ID must be a number.',
                                );
                                return;
                              }
                            }

                            setDialogState(() {
                              sending = true;
                            });

                            try {
                              await api.broadcastNotification(
                                type: selectedType,
                                title: title,
                                message: message,
                                entityType:
                                    entityTypeController.text
                                            .trim()
                                            .isEmpty
                                        ? null
                                        : entityTypeController
                                            .text
                                            .trim(),
                                entityId: entityId,
                              );

                              if (!mounted) return;

                              Navigator.of(dialogContext).pop();

                              showMessage(
                                'Notification broadcast successfully.',
                              );

                              await loadNotifications();
                            } catch (e) {
                              if (!mounted) return;

                              setDialogState(() {
                                sending = false;
                              });

                              showMessage(
                                'Failed to broadcast notification: '
                                '${e.toString().replaceFirst(
                                      'Exception: ',
                                      '',
                                    )}',
                              );
                            }
                          },
                    icon: sending
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child:
                                CircularProgressIndicator(
                              strokeWidth: 2,
                            ),
                          )
                        : const Icon(Icons.campaign),
                    label: Text(
                      sending
                          ? 'Broadcasting...'
                          : 'Broadcast',
                    ),
                  ),
                ],
              );
            },
          );
        },
      );
    } finally {
      titleController.dispose();
      messageController.dispose();
      entityTypeController.dispose();
      entityIdController.dispose();
    }
  }

  // ============================================================
  // MARK ONE AS READ
  // ============================================================

  Future<void> markRead(
    Map<String, dynamic> notification,
  ) async {
    final id = notification['id'];

    if (id == null) return;

    try {
      await api.markNotificationRead(
        int.parse(id.toString()),
      );

      await loadNotifications();
    } catch (e) {
      showMessage(
        e.toString().replaceFirst('Exception: ', ''),
      );
    }
  }

  // ============================================================
  // MARK ALL AS READ
  // ============================================================

  Future<void> markAllRead() async {
    if (unread == 0) return;

    try {
      await api.markAllNotificationsRead();

      await loadNotifications();

      if (!mounted) return;

      showMessage(
        'All notifications marked as read.',
      );
    } catch (e) {
      showMessage(
        e.toString().replaceFirst('Exception: ', ''),
      );
    }
  }

  // ============================================================
  // DELETE
  // ============================================================

  Future<void> deleteNotification(
    Map<String, dynamic> notification,
  ) async {
    final id = notification['id'];

    if (id == null) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Delete Notification?'),
          content: const Text(
            'This notification will be permanently deleted.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(dialogContext).pop(false);
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(dialogContext).pop(true);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );

    if (confirmed != true) return;

    try {
      await api.deleteNotification(
        int.parse(id.toString()),
      );

      await loadNotifications();

      if (!mounted) return;

      showMessage('Notification deleted.');
    } catch (e) {
      showMessage(
        e.toString().replaceFirst('Exception: ', ''),
      );
    }
  }

  // ============================================================
  // MESSAGE
  // ============================================================

  void showMessage(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  // ============================================================
  // INTEGER CONVERSION
  // ============================================================

  int _toInt(dynamic value) {
    if (value is int) return value;

    return int.tryParse(
          value?.toString() ?? '',
        ) ??
        0;
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: loading ? null : loadNotifications,
            icon: const Icon(Icons.refresh),
          ),

          if (unread > 0)
            TextButton.icon(
              onPressed: markAllRead,
              icon: const Icon(Icons.done_all),
              label: const Text('Mark all read'),
            ),
        ],
      ),

      body: loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : errorMessage != null
              ? buildError()
              : buildContent(),

      floatingActionButton:
          FloatingActionButton.extended(
        onPressed: showSendNotificationDialog,
        icon: const Icon(Icons.add_alert),
        label: const Text('Send Notification'),
      ),
    );
  }

  // ============================================================
  // ERROR
  // ============================================================

  Widget buildError() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment:
              MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.error_outline,
              size: 60,
              color: Colors.red,
            ),

            const SizedBox(height: 16),

            Text(
              errorMessage!,
              textAlign: TextAlign.center,
            ),

            const SizedBox(height: 20),

            ElevatedButton.icon(
              onPressed: loadNotifications,
              icon: const Icon(Icons.refresh),
              label: const Text('Retry'),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // CONTENT
  // ============================================================

  Widget buildContent() {
    return RefreshIndicator(
      onRefresh: loadNotifications,
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          buildActionButtons(),

          const SizedBox(height: 24),

          buildStatistics(),

          const SizedBox(height: 24),

          if (notifications.isEmpty)
            buildEmpty()
          else
            ...notifications.map(
              (notification) =>
                  buildNotificationCard(
                Map<String, dynamic>.from(
                  notification as Map,
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ============================================================
  // ACTION BUTTONS
  // ============================================================

  Widget buildActionButtons() {
    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: [
        ElevatedButton.icon(
          onPressed: showSendNotificationDialog,
          icon: const Icon(Icons.person_add),
          label: const Text('Send to User'),
        ),

        OutlinedButton.icon(
          onPressed: showBroadcastNotificationDialog,
          icon: const Icon(Icons.campaign),
          label: const Text('Broadcast'),
        ),
      ],
    );
  }

  // ============================================================
  // STATISTICS
  // ============================================================

  Widget buildStatistics() {
    return Wrap(
      spacing: 16,
      runSpacing: 16,
      children: [
        buildStatCard(
          title: 'Total',
          value: total,
          icon: Icons.notifications,
        ),
        buildStatCard(
          title: 'Unread',
          value: unread,
          icon: Icons.mark_email_unread,
        ),
        buildStatCard(
          title: 'Read',
          value: read,
          icon: Icons.mark_email_read,
        ),
      ],
    );
  }

  Widget buildStatCard({
    required String title,
    required int value,
    required IconData icon,
  }) {
    return Card(
      child: SizedBox(
        width: 220,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              CircleAvatar(
                child: Icon(icon),
              ),

              const SizedBox(width: 15),

              Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.grey,
                    ),
                  ),

                  Text(
                    '$value',
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // NOTIFICATION CARD
  // ============================================================

  Widget buildNotificationCard(
    Map<String, dynamic> notification,
  ) {
    final bool isRead =
        notification['is_read'] == true;

    final title =
        notification['title'] ?? 'Notification';

    final message =
        notification['message'] ?? '';

    final type =
        notification['type'] ?? 'general';

    final userId =
        notification['user_id'] ?? 'N/A';

    final createdAt =
        notification['created_at'] ?? '';

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: isRead ? 1 : 3,
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),

        leading: CircleAvatar(
          backgroundColor: isRead
              ? Colors.grey.withValues(alpha: 0.1)
              : Colors.blue.withValues(alpha: 0.1),
          child: Icon(
            isRead
                ? Icons.notifications_none
                : Icons.notifications_active,
            color:
                isRead ? Colors.grey : Colors.blue,
          ),
        ),

        title: Row(
          children: [
            Expanded(
              child: Text(
                title.toString(),
                style: TextStyle(
                  fontWeight: isRead
                      ? FontWeight.normal
                      : FontWeight.bold,
                ),
              ),
            ),

            Chip(
              label: Text(
                type.toString().toUpperCase(),
                style:
                    const TextStyle(fontSize: 10),
              ),
            ),
          ],
        ),

        subtitle: Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Text(message.toString()),

              const SizedBox(height: 8),

              Text(
                'User: $userId',
                style: const TextStyle(
                  color: Colors.grey,
                ),
              ),

              Text(
                createdAt.toString(),
                style: const TextStyle(
                  color: Colors.grey,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),

        trailing:
            PopupMenuButton<String>(
          onSelected: (value) {
            if (value == 'read') {
              markRead(notification);
            } else if (value == 'delete') {
              deleteNotification(notification);
            }
          },
          itemBuilder: (context) => [
            if (!isRead)
              const PopupMenuItem(
                value: 'read',
                child: Row(
                  children: [
                    Icon(Icons.done),
                    SizedBox(width: 10),
                    Text('Mark as read'),
                  ],
                ),
              ),

            const PopupMenuItem(
              value: 'delete',
              child: Row(
                children: [
                  Icon(
                    Icons.delete_outline,
                    color: Colors.red,
                  ),
                  SizedBox(width: 10),
                  Text('Delete'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // EMPTY
  // ============================================================

  Widget buildEmpty() {
    return SizedBox(
      height: 400,
      child: Center(
        child: Column(
          mainAxisAlignment:
              MainAxisAlignment.center,
          children: [
            Icon(
              Icons.notifications_none,
              size: 80,
              color: Colors.grey.shade400,
            ),

            const SizedBox(height: 15),

            const Text(
              'No Notifications',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 8),

            const Text(
              'There are no notifications yet.',
              style: TextStyle(
                color: Colors.grey,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
