import 'package:flutter/material.dart';
import '../../services/admin_api_service.dart';

class DriverVerificationScreen extends StatefulWidget {
  final String token;

  const DriverVerificationScreen({
    super.key,
    required this.token,
  });

  @override
  State<DriverVerificationScreen> createState() =>
      _DriverVerificationScreenState();
}

class _DriverVerificationScreenState
    extends State<DriverVerificationScreen> {

  final AdminApiService apiService = AdminApiService();

  List<dynamic> drivers = [];

  bool isLoading = true;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    loadDrivers();
  }

  // ============================================================
  // LOAD PENDING DRIVERS
  // ============================================================

 Future<void> loadDrivers() async {
  setState(() {
    isLoading = true;
    errorMessage = null;
  });

  try {
    apiService.setToken(widget.token);

    final result = await apiService.getPendingDrivers();

    if (!mounted) return;

    setState(() {
      drivers = result;
      isLoading = false;
    });
  } catch (e) {
    if (!mounted) return;

    setState(() {
      isLoading = false;
      errorMessage = e
          .toString()
          .replaceFirst('Exception: ', '');
    });
  }
}

  // ============================================================
  // VERIFY OR REJECT DRIVER
  // ============================================================
Future<void> updateDriver(
  int driverId,
  bool isVerified,
) async {
  try {
    apiService.setToken(widget.token);

    await apiService.verifyDriver(
      driverId,
      isVerified: isVerified,
    );

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          isVerified
              ? 'Driver approved successfully'
              : 'Driver rejected successfully',
        ),
      ),
    );

    await loadDrivers();
  } catch (e) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          e.toString().replaceFirst(
            'Exception: ',
            '',
          ),
        ),
      ),
    );
  }
}
  // ============================================================
  // CONFIRM ACTION
  // ============================================================

  Future<void> confirmAction({
    required int driverId,
    required bool isVerified,
  }) async {
    final action =
        isVerified ? 'approve' : 'reject';

    final confirmed =
        await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(
            '${isVerified ? 'Approve' : 'Reject'} Driver',
          ),
          content: Text(
            'Are you sure you want to $action this driver?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(
                  context,
                  false,
                );
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(
                  context,
                  true,
                );
              },
              child: Text(
                isVerified
                    ? 'Approve'
                    : 'Reject',
              ),
            ),
          ],
        );
      },
    );

    if (confirmed == true) {
      await updateDriver(
        driverId,
        isVerified,
      );
    }
  }

  // ============================================================
  // BUILD SCREEN
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
          const Color(0xFFF5F7FA),

      body: Padding(
        padding:
            const EdgeInsets.all(30),

        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,

          children: [
            // ==================================================
            // HEADER
            // ==================================================

            Row(
              children: [
                const Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Driver Verification',
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight:
                            FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 5),
                    Text(
                      'Review and verify drivers waiting for approval.',
                      style: TextStyle(
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),

                const Spacer(),

                IconButton(
                  tooltip: 'Refresh',
                  onPressed:
                      isLoading
                          ? null
                          : loadDrivers,
                  icon: const Icon(
                    Icons.refresh,
                    size: 28,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 30),

            // ==================================================
            // CONTENT
            // ==================================================

            Expanded(
              child: _buildContent(),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // CONTENT
  // ============================================================

  Widget _buildContent() {
    // LOADING
    if (isLoading) {
      return const Center(
        child:
            CircularProgressIndicator(),
      );
    }

    // ERROR
    if (errorMessage != null) {
      return Center(
        child: Column(
          mainAxisAlignment:
              MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.error_outline,
              size: 60,
              color: Colors.red,
            ),

            const SizedBox(height: 15),

            Text(
              errorMessage!,
              textAlign:
                  TextAlign.center,
              style:
                  const TextStyle(
                color: Colors.red,
              ),
            ),

            const SizedBox(height: 20),

            ElevatedButton.icon(
              onPressed: loadDrivers,
              icon: const Icon(
                Icons.refresh,
              ),
              label:
                  const Text('Retry'),
            ),
          ],
        ),
      );
    }

    // NO DRIVERS
    if (drivers.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment:
              MainAxisAlignment.center,
          children: [
            Icon(
              Icons.verified_user_outlined,
              size: 80,
              color:
                  Colors.grey.shade400,
            ),

            const SizedBox(height: 20),

            const Text(
              'No Pending Drivers',
              style: TextStyle(
                fontSize: 22,
                fontWeight:
                    FontWeight.bold,
              ),
            ),

            const SizedBox(height: 8),

            const Text(
              'There are currently no drivers waiting for verification.',
              style: TextStyle(
                color: Colors.grey,
              ),
            ),
          ],
        ),
      );
    }

    // DRIVER LIST
    return RefreshIndicator(
      onRefresh: loadDrivers,

      child: ListView.builder(
        itemCount: drivers.length,

        itemBuilder:
            (context, index) {
          final driver =
              drivers[index];

          final int driverId =
              driver['id'];

          final int userId =
              driver['user_id'];

          final String licenseNumber =
              driver[
                      'license_number'] ??
                  'Not provided';

          final bool isVerified =
              driver[
                      'is_verified'] ??
                  false;

          final bool isOnline =
              driver[
                      'is_online'] ??
                  false;

          return Card(
            margin:
                const EdgeInsets.only(
              bottom: 15,
            ),

            elevation: 2,

            child: Padding(
              padding:
                  const EdgeInsets.all(
                20,
              ),

              child: Row(
                children: [
                  // DRIVER ICON
                  Container(
                    width: 60,
                    height: 60,

                    decoration:
                        BoxDecoration(
                      color: Colors.green
                          .withValues(alpha:
                        0.1,
                      ),

                      borderRadius:
                          BorderRadius
                              .circular(
                        12,
                      ),
                    ),

                    child: const Icon(
                      Icons.drive_eta,
                      color:
                          Colors.green,
                      size: 30,
                    ),
                  ),

                  const SizedBox(
                    width: 20,
                  ),

                  // DRIVER DETAILS
                  Expanded(
                    child: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment
                              .start,

                      children: [
                        Text(
                          'Driver #$driverId',

                          style:
                              const TextStyle(
                            fontSize: 18,
                            fontWeight:
                                FontWeight
                                    .bold,
                          ),
                        ),

                        const SizedBox(
                          height: 8,
                        ),

                        Text(
                          'User ID: $userId',
                        ),

                        const SizedBox(
                          height: 5,
                        ),

                        Text(
                          'License: $licenseNumber',
                        ),

                        const SizedBox(
                          height: 8,
                        ),

                        Row(
                          children: [
                            _statusBadge(
                              text:
                                  isVerified
                                      ? 'Verified'
                                      : 'Pending',
                              color:
                                  isVerified
                                      ? Colors
                                          .green
                                      : Colors
                                          .orange,
                            ),

                            const SizedBox(
                              width: 8,
                            ),

                            _statusBadge(
                              text:
                                  isOnline
                                      ? 'Online'
                                      : 'Offline',
                              color:
                                  isOnline
                                      ? Colors
                                          .green
                                      : Colors
                                          .grey,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(
                    width: 20,
                  ),

                  // ACTION BUTTONS
                  Row(
                    children: [
                      OutlinedButton.icon(
                        onPressed:
                            () {
                          confirmAction(
                            driverId:
                                driverId,
                            isVerified:
                                false,
                          );
                        },
                        icon:
                            const Icon(
                          Icons.close,
                          color:
                              Colors.red,
                        ),
                        label:
                            const Text(
                          'Reject',
                        ),
                      ),

                      const SizedBox(
                        width: 10,
                      ),

                      ElevatedButton.icon(
                        onPressed:
                            () {
                          confirmAction(
                            driverId:
                                driverId,
                            isVerified:
                                true,
                          );
                        },
                        icon:
                            const Icon(
                          Icons.check,
                        ),
                        label:
                            const Text(
                          'Approve',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ============================================================
  // STATUS BADGE
  // ============================================================

  Widget _statusBadge({
    required String text,
    required Color color,
  }) {
    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 5,
      ),

      decoration:
          BoxDecoration(
        color:
            color.withValues(alpha: 0.1),

        borderRadius:
            BorderRadius.circular(
          20,
        ),
      ),

      child: Text(
        text,

        style: TextStyle(
          color: color,
          fontSize: 12,
          fontWeight:
              FontWeight.bold,
        ),
      ),
    );
  }
}