import 'package:flutter/material.dart';
import '../theme/rydex_theme.dart';

class RydexSidebar extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onItemSelected;

  const RydexSidebar({
    super.key,
    required this.selectedIndex,
    required this.onItemSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 250,
      color: RydexTheme.dark,
      child: Column(
        children: [
          const SizedBox(height: 28),

          // LOGO
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 24),
            child: Row(
              children: [
                Icon(
                  Icons.local_taxi_rounded,
                  color: RydexTheme.yellow,
                  size: 32,
                ),
                SizedBox(width: 10),
                Text(
                  'RYDE',
                  style: TextStyle(
                    color: RydexTheme.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.5,
                  ),
                ),
                Text(
                  'X',
                  style: TextStyle(
                    color: RydexTheme.yellow,
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 35),

          _sectionTitle('MAIN'),

          _item(
            icon: Icons.dashboard_rounded,
            title: 'Dashboard',
            index: 0,
          ),

          _item(
            icon: Icons.local_taxi_rounded,
            title: 'Rides',
            index: 1,
          ),

          _sectionTitle('OPERATIONS'),

          _item(
            icon: Icons.people_alt_rounded,
            title: 'Drivers',
            index: 2,
          ),

          _item(
            icon: Icons.directions_car_rounded,
            title: 'Vehicles',
            index: 3,
          ),

          _item(
            icon: Icons.map_rounded,
            title: 'Live Map',
            index: 4,
          ),

          _sectionTitle('USERS'),

          _item(
            icon: Icons.person_rounded,
            title: 'Passengers',
            index: 5,
          ),

          _item(
            icon: Icons.verified_user_rounded,
            title: 'Verification',
            index: 6,
          ),

          _sectionTitle('FINANCE'),

          _item(
            icon: Icons.account_balance_wallet_rounded,
            title: 'Finance',
            index: 7,
          ),
          _sectionTitle('QUALITY'),

_item(
  icon: Icons.star_rate_rounded,
  title: 'Ratings',
  index: 9,
),

          _item(
            icon: Icons.analytics_rounded,
            title: 'Analytics',
            index: 8,
          ),

          const Spacer(),

          _item(
            icon: Icons.settings_rounded,
            title: 'Settings',
            index: 10,
          ),

          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 22, 24, 8),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Text(
          title,
          style: const TextStyle(
            color: RydexTheme.muted,
            fontSize: 10,
            fontWeight: FontWeight.w700,
            letterSpacing: 1.2,
          ),
        ),
      ),
    );
  }

  Widget _item({
    required IconData icon,
    required String title,
    required int index,
  }) {
    final selected = selectedIndex == index;

    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 3,
      ),
      child: Material(
        color: selected
            ? RydexTheme.yellow.withValues(alpha: 0.12)
            : Colors.transparent,
        borderRadius: BorderRadius.circular(10),
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          onTap: () => onItemSelected(index),
          child: Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 12,
            ),
            decoration: BoxDecoration(
              border: selected
                  ? const Border(
                      left: BorderSide(
                        color: RydexTheme.yellow,
                        width: 3,
                      ),
                    )
                  : null,
            ),
            child: Row(
              children: [
                Icon(
                  icon,
                  size: 20,
                  color: selected
                      ? RydexTheme.yellow
                      : RydexTheme.muted,
                ),
                const SizedBox(width: 12),
                Text(
                  title,
                  style: TextStyle(
                    color: selected
                        ? RydexTheme.white
                        : RydexTheme.muted,
                    fontWeight: selected
                        ? FontWeight.w700
                        : FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}