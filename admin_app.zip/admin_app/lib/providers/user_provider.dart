import 'package:flutter/material.dart';

import '../models/admin_user.dart';
import '../services/admin_api_service.dart';

class UserProvider extends ChangeNotifier {

  final AdminApiService _api = AdminApiService();


  // ==========================
  // AUTH
  // ==========================

  String? _token;

  String? get token => _token;


  void setToken(String token) {
    _token = token;
    notifyListeners();
  }


  void logout() {
    _token = null;
    notifyListeners();
  }


  bool get isLoggedIn {
    return _token != null;
  }



  // ==========================
  // USERS
  // ==========================

  List<AdminUser> _users = [];

  bool _loading = false;


  List<AdminUser> get users => _users;

  bool get loading => _loading;



  Future<void> loadUsers() async {

    _loading = true;
    notifyListeners();


    try {

      final data = await _api.getUsers();


      _users = data
          .map<AdminUser>(
            (e) => AdminUser.fromJson(e),
          )
          .toList();


    } finally {

      _loading = false;
      notifyListeners();

    }
  }



  Future<void> refresh() async {
    await loadUsers();
  }
}