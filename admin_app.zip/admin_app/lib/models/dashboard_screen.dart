import 'package:flutter/material.dart';

import '../services/admin_api_service.dart';
import 'dashboard_stats.dart';

class DashboardScreen extends StatefulWidget {
  final String token;

  const DashboardScreen({
    super.key,
    required this.token,
  });

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final AdminApiService api = AdminApiService();

  DashboardStats? stats;

  bool isLoading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    loadDashboard();
  }

  Future<void> loadDashboard() async {
    try {
      final data = await api.getDashboardStats();

      setState(() {
        stats = DashboardStats.fromJson(data);
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
        isLoading = false;
      });
    }
  }

  Widget dashboardCard({
    required String title,
    required String value,
    required IconData icon,
    Color color = Colors.green,
  }) {
    return Card(
      elevation: 3,
      child: SizedBox(
        width: 180,
        height: 120,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            mainAxisAlignment:
                MainAxisAlignment.spaceBetween,
            children: [
              Icon(
                icon,
                color: color,
                size: 32,
              ),
              Text(
                title,
                style: const TextStyle(
                  color: Colors.grey,
                  fontSize: 14,
                ),
              ),
              Text(
                value,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 24,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (error != null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text("Dashboard"),
        ),
        body: Center(
          child: Text(error!),
        ),
      );
    }

    final s = stats!;

    return Scaffold(
      appBar: AppBar(
        title: const Text("RYDEX Admin Dashboard"),
        centerTitle: true,
      ),
      body: RefreshIndicator(
        onRefresh: loadDashboard,
        child: SingleChildScrollView(
          physics:
              const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Wrap(
            spacing: 20,
            runSpacing: 20,
            children: [

              dashboardCard(
                title: "Passengers",
                value: s.totalUsers.toString(),
                icon: Icons.people,
                color: Colors.blue,
              ),

              dashboardCard(
                title: "Drivers",
                value: s.totalDrivers.toString(),
                icon: Icons.local_taxi,
                color: Colors.orange,
              ),

              dashboardCard(
                title: "Verified Drivers",
                value: s.verifiedDrivers.toString(),
                icon: Icons.verified,
                color: Colors.green,
              ),

              dashboardCard(
                title: "Online Drivers",
                value: s.onlineDrivers.toString(),
                icon: Icons.wifi,
                color: Colors.teal,
              ),

              dashboardCard(
                title: "Pending Verification",
                value: s.pendingDriverVerifications.toString(),
                icon: Icons.pending_actions,
                color: Colors.red,
              ),

              dashboardCard(
                title: "Total Rides",
                value: s.totalRides.toString(),
                icon: Icons.route,
              ),

              dashboardCard(
                title: "Completed Rides",
                value: s.completedRides.toString(),
                icon: Icons.check_circle,
                color: Colors.green,
              ),

              dashboardCard(
                title: "Cancelled Rides",
                value: s.cancelledRides.toString(),
                icon: Icons.cancel,
                color: Colors.red,
              ),

              dashboardCard(
                title: "Today's Revenue",
                value: "KES ${s.todaysRevenue}",
                icon: Icons.payments,
                color: Colors.green,
              ),

              dashboardCard(
                title: "Platform Commission",
                value: "KES ${s.platformCommission}",
                icon: Icons.account_balance,
                color: Colors.indigo,
              ),

              dashboardCard(
                title: "Driver Earnings",
                value: "KES ${s.driverEarnings}",
                icon: Icons.wallet,
                color: Colors.deepOrange,
              ),

              dashboardCard(
                title: "Completion Rate",
                value: "${s.completionRate}%",
                icon: Icons.trending_up,
                color: Colors.purple,
              ),

  dashboardCard(
  title: "Average Rating",
  value: "${s.averageRating.toStringAsFixed(1)} ⭐",
  icon: Icons.star_rate_rounded,
  color: Colors.amber,
),

dashboardCard(
  title: "Total Ratings",
  value: s.totalRatings.toString(),
  icon: Icons.reviews_rounded,
  color: Colors.deepPurple,
),
            ],
          ),
        ),
      ),
    );
  }
}