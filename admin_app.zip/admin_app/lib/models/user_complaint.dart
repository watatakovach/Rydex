class UserComplaint {
  final int id;
  final String title;
  final String description;
  final String status;
  final DateTime createdAt;

  UserComplaint({
    required this.id,
    required this.title,
    required this.description,
    required this.status,
    required this.createdAt,
  });

  factory UserComplaint.fromJson(Map<String, dynamic> json) {
    return UserComplaint(
      id: json["id"],
      title: json["title"] ?? "",
      description: json["description"] ?? "",
      status: json["status"] ?? "",
      createdAt: DateTime.parse(json["created_at"]),
    );
  }
}