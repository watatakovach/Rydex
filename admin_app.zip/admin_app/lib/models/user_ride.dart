class UserRide {
  final int id;
  final String pickupLocation;
  final String destination;
  final String status;
  final double? estimatedFare;
  final double? finalFare;
  final DateTime requestedAt;
  final DateTime? completedAt;

  UserRide({
    required this.id,
    required this.pickupLocation,
    required this.destination,
    required this.status,
    this.estimatedFare,
    this.finalFare,
    required this.requestedAt,
    this.completedAt,
  });

  factory UserRide.fromJson(Map<String, dynamic> json) {
    return UserRide(
      id: json["id"],
      pickupLocation: json["pickup_location"] ?? "",
      destination: json["destination"] ?? "",
      status: json["status"] ?? "",
      estimatedFare: json["estimated_fare"]?.toDouble(),
      finalFare: json["final_fare"]?.toDouble(),
      requestedAt: DateTime.parse(json["requested_at"]),
      completedAt: json["completed_at"] == null
          ? null
          : DateTime.parse(json["completed_at"]),
    );
  }
}