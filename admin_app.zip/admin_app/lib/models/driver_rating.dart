class DriverRating {
  final int id;
  final int rideId;
  final int passengerId;
  final int driverId;

  final String passengerName;

  final int rating;

  final String? comment;

  final DateTime createdAt;

  DriverRating({
    required this.id,
    required this.rideId,
    required this.passengerId,
    required this.driverId,
    required this.passengerName,
    required this.rating,
    this.comment,
    required this.createdAt,
  });

  factory DriverRating.fromJson(Map<String, dynamic> json) {
    return DriverRating(
      id: json["id"] ?? 0,
      rideId: json["ride_id"] ?? 0,
      passengerId: json["passenger_id"] ?? 0,
      driverId: json["driver_id"] ?? 0,
      passengerName: json["passenger_name"] ?? "Unknown",
      rating: json["rating"] ?? 0,
      comment: json["comment"],
      createdAt: DateTime.parse(
        json["created_at"],
      ),
    );
  }
}

class DriverRatingSummary {
  final double averageRating;

  final int totalRatings;

  final int fiveStars;

  final int fourStars;

  final int threeStars;

  final int twoStars;

  final int oneStar;

  final List<DriverRating> reviews;

  DriverRatingSummary({
    required this.averageRating,
    required this.totalRatings,
    required this.fiveStars,
    required this.fourStars,
    required this.threeStars,
    required this.twoStars,
    required this.oneStar,
    required this.reviews,
  });

  factory DriverRatingSummary.fromJson(
      Map<String, dynamic> json) {
    return DriverRatingSummary(
      averageRating:
          (json["average_rating"] ?? 0).toDouble(),

      totalRatings:
          json["total_ratings"] ?? 0,

      fiveStars:
          json["five_stars"] ?? 0,

      fourStars:
          json["four_stars"] ?? 0,

      threeStars:
          json["three_stars"] ?? 0,

      twoStars:
          json["two_stars"] ?? 0,

      oneStar:
          json["one_stars"] ?? 0,

      reviews: (json["reviews"] as List<dynamic>? ?? [])
          .map(
            (e) => DriverRating.fromJson(e),
          )
          .toList(),
    );
  }
}