class DashboardStats {
  final int totalUsers;
  final int totalDrivers;
  final int verifiedDrivers;
  final int pendingDriverVerifications;
  final int onlineDrivers;

  final int totalRides;
  final int activeRides;
  final int completedRides;
  final int cancelledRides;

  final double todaysRevenue;
  final double driverEarnings;
  final double platformCommission;

  final int newRegistrations;
  final double completionRate;

  final double averageRating;
  final int totalRatings;


  DashboardStats({
    required this.totalUsers,
    required this.totalDrivers,
    required this.verifiedDrivers,
    required this.pendingDriverVerifications,
    required this.onlineDrivers,

    required this.totalRides,
    required this.activeRides,
    required this.completedRides,
    required this.cancelledRides,

    required this.todaysRevenue,
    required this.driverEarnings,
    required this.platformCommission,

    required this.newRegistrations,
    required this.completionRate,

    required this.averageRating,
    required this.totalRatings,
  });


  factory DashboardStats.fromJson(
      Map<String, dynamic> json) {

    return DashboardStats(

      totalUsers:
          json['total_users'] ?? 0,

      totalDrivers:
          json['total_drivers'] ?? 0,

      verifiedDrivers:
          json['verified_drivers'] ?? 0,

      pendingDriverVerifications:
          json['pending_driver_verifications'] ?? 0,

      onlineDrivers:
          json['online_drivers'] ?? 0,


      totalRides:
          json['total_rides'] ?? 0,

      activeRides:
          json['active_rides'] ?? 0,

      completedRides:
          json['completed_rides'] ?? 0,

      cancelledRides:
          json['cancelled_rides'] ?? 0,


      todaysRevenue:
          (json['todays_revenue'] ?? 0)
              .toDouble(),

      driverEarnings:
          (json['driver_earnings'] ?? 0)
              .toDouble(),

      platformCommission:
          (json['platform_commission'] ?? 0)
              .toDouble(),


      newRegistrations:
          json['new_registrations'] ?? 0,

      completionRate:
          (json['completion_rate'] ?? 0)
              .toDouble(),

      averageRating:
          (json['average_rating'] ?? 0)
              .toDouble(),

      totalRatings:
          json['total_ratings'] ?? 0,
    );
  }
}