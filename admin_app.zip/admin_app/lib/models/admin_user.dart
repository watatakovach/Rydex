class AdminUser {
  final int id;
  final String fullName;
  final String phoneNumber;
  final String? email;
  final String role;
  final bool isActive;

  // NEW
  final DateTime? createdAt;

  AdminUser({
    required this.id,
    required this.fullName,
    required this.phoneNumber,
    this.email,
    required this.role,
    required this.isActive,
    this.createdAt,
  });

  factory AdminUser.fromJson(Map<String, dynamic> json) {
    return AdminUser(
      id: json["id"],
      fullName: json["full_name"] ?? "",
      phoneNumber: json["phone_number"] ?? "",
      email: json["email"],
      role: json["role"] ?? "",
      isActive: json["is_active"] ?? true,
      createdAt: json["created_at"] != null
          ? DateTime.parse(json["created_at"])
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "full_name": fullName,
      "phone_number": phoneNumber,
      "email": email,
      "role": role,
      "is_active": isActive,
      "created_at": createdAt?.toIso8601String(),
    };
  }
}