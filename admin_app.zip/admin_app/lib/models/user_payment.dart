class UserPayment {
  final int id;
  final double amount;
  final String paymentMethod;
  final String status;
  final DateTime createdAt;

  UserPayment({
    required this.id,
    required this.amount,
    required this.paymentMethod,
    required this.status,
    required this.createdAt,
  });

  factory UserPayment.fromJson(Map<String, dynamic> json) {
    return UserPayment(
      id: json["id"],
      amount: (json["amount"] as num).toDouble(),
      paymentMethod: json["payment_method"] ?? "",
      status: json["status"] ?? "",
      createdAt: DateTime.parse(json["created_at"]),
    );
  }
}