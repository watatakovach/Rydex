import 'package:flutter/material.dart';

class RydexTheme {
  static const Color black = Color(0xFF0B0B0B);
  static const Color dark = Color(0xFF121212);
  static const Color card = Color(0xFF1A1A1A);
  static const Color yellow = Color(0xFFFFC107);
  static const Color white = Color(0xFFF5F5F5);
  static const Color muted = Color(0xFF9E9E9E);

  static ThemeData darkTheme = ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: black,
    colorScheme: const ColorScheme.dark(
      primary: yellow,
      secondary: yellow,
      surface: dark,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: black,
      foregroundColor: white,
      elevation: 0,
    ),
    cardTheme: const CardThemeData(
      color: card,
      elevation: 0,
      margin: EdgeInsets.zero,
    ),
  );
}