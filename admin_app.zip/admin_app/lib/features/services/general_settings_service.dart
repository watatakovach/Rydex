import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/general_settings_model.dart';

class GeneralSettingsService {
  /// Change this if you already have a central ApiConfig.
  static const String baseUrl = "http://127.0.0.1:8000";

  static const String endpoint = "$baseUrl/settings/general";

  Future<GeneralSettings> getSettings({
    String? token,
  }) async {
    final response = await http.get(
      Uri.parse(endpoint),
      headers: {
        "Content-Type": "application/json",
        if (token != null) "Authorization": "Bearer $token",
      },
    );

    if (response.statusCode == 200) {
      return GeneralSettings.fromJson(
        jsonDecode(response.body),
      );
    }

    throw Exception(
      "Failed to load settings (${response.statusCode})\n${response.body}",
    );
  }

  Future<GeneralSettings> updateSettings({
    required GeneralSettings settings,
    String? token,
  }) async {
    final response = await http.put(
      Uri.parse(endpoint),
      headers: {
        "Content-Type": "application/json",
        if (token != null) "Authorization": "Bearer $token",
      },
      body: jsonEncode(
        settings.toJson(),
      ),
    );

    if (response.statusCode == 200) {
      return GeneralSettings.fromJson(
        jsonDecode(response.body),
      );
    }

    throw Exception(
      "Failed to update settings (${response.statusCode})\n${response.body}",
    );
  }
}