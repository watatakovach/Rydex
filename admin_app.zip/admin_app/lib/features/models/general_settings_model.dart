class GeneralSettings {
  final int id;
  final String companyName;
  final String companyEmail;
  final String companyPhone;
  final String companyAddress;
  final String website;
  final String logo;
  final String timezone;
  final String language;
  final String currency;
  final String currencySymbol;
  final String distanceUnit;
  final String dateFormat;
  final String timeFormat;
  final bool maintenanceMode;
  final bool registrationEnabled;
  final bool driverRegistrationEnabled;
  final bool passengerRegistrationEnabled;

  const GeneralSettings({
    required this.id,
    required this.companyName,
    required this.companyEmail,
    required this.companyPhone,
    required this.companyAddress,
    required this.website,
    required this.logo,
    required this.timezone,
    required this.language,
    required this.currency,
    required this.currencySymbol,
    required this.distanceUnit,
    required this.dateFormat,
    required this.timeFormat,
    required this.maintenanceMode,
    required this.registrationEnabled,
    required this.driverRegistrationEnabled,
    required this.passengerRegistrationEnabled,
  });

  factory GeneralSettings.fromJson(Map<String, dynamic> json) {
    return GeneralSettings(
      id: json["id"] ?? 0,
      companyName: json["company_name"] ?? "",
      companyEmail: json["company_email"] ?? "",
      companyPhone: json["company_phone"] ?? "",
      companyAddress: json["company_address"] ?? "",
      website: json["website"] ?? "",
      logo: json["logo"] ?? "",
      timezone: json["timezone"] ?? "Africa/Nairobi",
      language: json["language"] ?? "English",
      currency: json["currency"] ?? "KES",
      currencySymbol: json["currency_symbol"] ?? "KSh",
      distanceUnit: json["distance_unit"] ?? "Kilometers",
      dateFormat: json["date_format"] ?? "dd/MM/yyyy",
      timeFormat: json["time_format"] ?? "24 Hour",
      maintenanceMode: json["maintenance_mode"] ?? false,
      registrationEnabled: json["registration_enabled"] ?? true,
      driverRegistrationEnabled:
          json["driver_registration_enabled"] ?? true,
      passengerRegistrationEnabled:
          json["passenger_registration_enabled"] ?? true,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "company_name": companyName,
      "company_email": companyEmail,
      "company_phone": companyPhone,
      "company_address": companyAddress,
      "website": website,
      "logo": logo,
      "timezone": timezone,
      "language": language,
      "currency": currency,
      "currency_symbol": currencySymbol,
      "distance_unit": distanceUnit,
      "date_format": dateFormat,
      "time_format": timeFormat,
      "maintenance_mode": maintenanceMode,
      "registration_enabled": registrationEnabled,
      "driver_registration_enabled": driverRegistrationEnabled,
      "passenger_registration_enabled":
          passengerRegistrationEnabled,
    };
  }

  GeneralSettings copyWith({
    int? id,
    String? companyName,
    String? companyEmail,
    String? companyPhone,
    String? companyAddress,
    String? website,
    String? logo,
    String? timezone,
    String? language,
    String? currency,
    String? currencySymbol,
    String? distanceUnit,
    String? dateFormat,
    String? timeFormat,
    bool? maintenanceMode,
    bool? registrationEnabled,
    bool? driverRegistrationEnabled,
    bool? passengerRegistrationEnabled,
  }) {
    return GeneralSettings(
      id: id ?? this.id,
      companyName: companyName ?? this.companyName,
      companyEmail: companyEmail ?? this.companyEmail,
      companyPhone: companyPhone ?? this.companyPhone,
      companyAddress: companyAddress ?? this.companyAddress,
      website: website ?? this.website,
      logo: logo ?? this.logo,
      timezone: timezone ?? this.timezone,
      language: language ?? this.language,
      currency: currency ?? this.currency,
      currencySymbol: currencySymbol ?? this.currencySymbol,
      distanceUnit: distanceUnit ?? this.distanceUnit,
      dateFormat: dateFormat ?? this.dateFormat,
      timeFormat: timeFormat ?? this.timeFormat,
      maintenanceMode: maintenanceMode ?? this.maintenanceMode,
      registrationEnabled:
          registrationEnabled ?? this.registrationEnabled,
      driverRegistrationEnabled:
          driverRegistrationEnabled ??
          this.driverRegistrationEnabled,
      passengerRegistrationEnabled:
          passengerRegistrationEnabled ??
          this.passengerRegistrationEnabled,
    );
  }
}