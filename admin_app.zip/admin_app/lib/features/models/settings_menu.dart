import 'package:flutter/material.dart';

class SettingsMenu {

  final String title;

  final IconData icon;

  final Widget page;

  const SettingsMenu({
    required this.title,
    required this.icon,
    required this.page,
  });

}