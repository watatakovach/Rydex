import 'package:flutter/material.dart';

import '../models/settings_menu.dart';

class SettingsSidebar extends StatelessWidget {

  final List<SettingsMenu> items;

  final int selectedIndex;

  final ValueChanged<int> onSelected;

  const SettingsSidebar({
    super.key,
    required this.items,
    required this.selectedIndex,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {

    return Container(

      width: 280,

      decoration: BoxDecoration(

        color: Colors.white,

        border: Border(
          right: BorderSide(
            color: Colors.grey.shade300,
          ),
        ),

      ),

      child: ListView.builder(

        itemCount: items.length,

        itemBuilder: (context,index){

          final item = items[index];

          final selected = selectedIndex==index;

          return ListTile(

            selected: selected,

            selectedTileColor:
                Colors.blue.withOpacity(.08),

            leading: Icon(
              item.icon,
              color: selected
                  ? Colors.blue
                  : Colors.grey,
            ),

            title: Text(
              item.title,
              style: TextStyle(
                fontWeight: selected
                    ? FontWeight.bold
                    : FontWeight.normal,
              ),
            ),

            onTap: (){
              onSelected(index);
            },

          );

        },

      ),

    );

  }

}