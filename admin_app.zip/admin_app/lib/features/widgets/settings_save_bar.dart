import 'package:flutter/material.dart';

class SettingsSaveBar extends StatelessWidget {
  final VoidCallback onSave;
  final VoidCallback onReset;
  final bool loading;

  const SettingsSaveBar({
    super.key,
    required this.onSave,
    required this.onReset,
    this.loading = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(
          top: BorderSide(
            color: Colors.grey.shade300,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment:
            MainAxisAlignment.end,
        children: [
          OutlinedButton(
            onPressed:
                loading ? null : onReset,
            child: const Text("Reset"),
          ),
          const SizedBox(width: 12),
          ElevatedButton.icon(
            onPressed:
                loading ? null : onSave,
            icon: loading
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child:
                        CircularProgressIndicator(
                      strokeWidth: 2,
                    ),
                  )
                : const Icon(Icons.save),
            label: Text(
              loading
                  ? "Saving..."
                  : "Save Changes",
            ),
          ),
        ],
      ),
    );
  }
}