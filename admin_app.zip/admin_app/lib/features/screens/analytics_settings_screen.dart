import 'package:flutter/material.dart';

import '../widgets/settings_card.dart';
import '../widgets/settings_header.dart';
import '../widgets/settings_save_bar.dart';


class AnalyticsSettingsScreen extends StatefulWidget {

  const AnalyticsSettingsScreen({
    super.key,
  });


  @override
  State<AnalyticsSettingsScreen> createState() =>
      _AnalyticsSettingsScreenState();

}



class _AnalyticsSettingsScreenState
    extends State<AnalyticsSettingsScreen> {


  final TextEditingController dataRetentionController =
      TextEditingController(
        text: "365",
      );


  final TextEditingController reportEmailController =
      TextEditingController();



  bool enableAnalytics = true;

  bool collectRideAnalytics = true;

  bool collectDriverAnalytics = true;

  bool collectRevenueAnalytics = true;

  bool collectPassengerAnalytics = true;

  bool enableAutomaticReports = true;

  bool enableDataExport = true;

  bool trackUserBehaviour = false;



  String defaultReportFormat = "PDF";



  @override
  void dispose() {

    dataRetentionController.dispose();

    reportEmailController.dispose();

    super.dispose();

  }



  @override
  Widget build(BuildContext context) {


    return Scaffold(

      body: Column(

        children: [


          SettingsHeader(

            title:
                "Analytics Settings",

            subtitle:
                "Configure data collection, reports and insights.",

          ),



          Expanded(

            child: SingleChildScrollView(

              padding:
                  const EdgeInsets.all(24),


              child: Column(

                children: [


                  SettingsCard(

                    title:
                        "Analytics Control",

                    subtitle:
                        "Manage platform data tracking.",


                    child: Column(

                      children: [


                        SwitchListTile(

                          title:
                              const Text(
                                "Enable Analytics",
                              ),

                          value:
                              enableAnalytics,


                          onChanged:(v){

                            setState(() {

                              enableAnalytics=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Track User Behaviour",
                              ),

                          subtitle:
                              const Text(
                                "Analyze user interactions.",
                              ),


                          value:
                              trackUserBehaviour,


                          onChanged:(v){

                            setState(() {

                              trackUserBehaviour=v;

                            });

                          },

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Data Collection",

                    subtitle:
                        "Choose analytics categories.",


                    child: Column(

                      children: [


                        SwitchListTile(

                          title:
                              const Text(
                                "Ride Analytics",
                              ),

                          subtitle:
                              const Text(
                                "Requests, completions and cancellations.",
                              ),


                          value:
                              collectRideAnalytics,


                          onChanged:(v){

                            setState(() {

                              collectRideAnalytics=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Driver Analytics",
                              ),


                          value:
                              collectDriverAnalytics,


                          onChanged:(v){

                            setState(() {

                              collectDriverAnalytics=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Passenger Analytics",
                              ),


                          value:
                              collectPassengerAnalytics,


                          onChanged:(v){

                            setState(() {

                              collectPassengerAnalytics=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Revenue Analytics",
                              ),


                          value:
                              collectRevenueAnalytics,


                          onChanged:(v){

                            setState(() {

                              collectRevenueAnalytics=v;

                            });

                          },

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Reports",

                    subtitle:
                        "Configure automated reporting.",


                    child: Column(

                      children: [


                        SwitchListTile(

                          title:
                              const Text(
                                "Automatic Reports",
                              ),


                          value:
                              enableAutomaticReports,


                          onChanged:(v){

                            setState(() {

                              enableAutomaticReports=v;

                            });

                          },

                        ),



                        TextFormField(

                          controller:
                              reportEmailController,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Report Email",

                            border:
                                OutlineInputBorder(),

                            prefixIcon:
                                Icon(
                                  Icons.email,
                                ),

                          ),

                        ),



                        const SizedBox(height:20),



                        DropdownButtonFormField<String>(

                          value:
                              defaultReportFormat,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Report Format",

                            border:
                                OutlineInputBorder(),

                          ),


                          items: const [

                            DropdownMenuItem(

                              value:
                                  "PDF",

                              child:
                                  Text(
                                    "PDF",
                                  ),

                            ),

                            DropdownMenuItem(

                              value:
                                  "Excel",

                              child:
                                  Text(
                                    "Excel",
                                  ),

                            ),

                            DropdownMenuItem(

                              value:
                                  "CSV",

                              child:
                                  Text(
                                    "CSV",
                                  ),

                            ),

                          ],


                          onChanged:(v){

                            setState(() {

                              defaultReportFormat=v!;

                            });

                          },

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Data Storage",

                    subtitle:
                        "Manage analytics data retention.",


                    child: Column(

                      children: [


                        TextFormField(

                          controller:
                              dataRetentionController,


                          keyboardType:
                              TextInputType.number,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Data Retention Days",

                            border:
                                OutlineInputBorder(),

                          ),

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Enable Data Export",
                              ),


                          value:
                              enableDataExport,


                          onChanged:(v){

                            setState(() {

                              enableDataExport=v;

                            });

                          },

                        ),


                      ],

                    ),

                  ),


                ],

              ),

            ),

          ),



          SettingsSaveBar(

            onSave: (){

              ScaffoldMessenger.of(context)
              .showSnackBar(

                const SnackBar(

                  content:
                    Text(
                      "Analytics settings saved",
                    ),

                ),

              );

            },


            onReset: (){},


          ),


        ],

      ),

    );

  }

}