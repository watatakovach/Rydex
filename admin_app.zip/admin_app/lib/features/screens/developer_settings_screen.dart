import 'package:flutter/material.dart';

import '../widgets/settings_card.dart';
import '../widgets/settings_header.dart';
import '../widgets/settings_save_bar.dart';



class DeveloperSettingsScreen extends StatefulWidget {

  const DeveloperSettingsScreen({
    super.key,
  });


  @override
  State<DeveloperSettingsScreen> createState() =>
      _DeveloperSettingsScreenState();

}



class _DeveloperSettingsScreenState
    extends State<DeveloperSettingsScreen> {


  final TextEditingController apiUrlController =
      TextEditingController(
        text: "https://api.rydex.com",
      );


  final TextEditingController webhookController =
      TextEditingController();


  final TextEditingController firebaseProjectController =
      TextEditingController();



  bool debugMode = false;

  bool maintenanceMode = false;

  bool enableLogs = true;

  bool enableWebhooks = true;

  bool enableFeatureFlags = true;

  bool crashReporting = true;



  String environment = "Production";

  String logLevel = "INFO";



  @override
  void dispose(){

    apiUrlController.dispose();

    webhookController.dispose();

    firebaseProjectController.dispose();

    super.dispose();

  }



  @override
  Widget build(BuildContext context){


    return Scaffold(

      body: Column(

        children: [


          SettingsHeader(

            title:
                "Developer & API Settings",

            subtitle:
                "Manage technical configuration and integrations.",

          ),



          Expanded(

            child: SingleChildScrollView(

              padding:
                  const EdgeInsets.all(24),


              child: Column(

                children: [


                  SettingsCard(

                    title:
                        "Environment Configuration",

                    subtitle:
                        "Control application environment.",


                    child: Column(

                      children: [


                        DropdownButtonFormField<String>(

                          value:
                              environment,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Environment",

                            border:
                                OutlineInputBorder(),

                          ),


                          items: const [

                            DropdownMenuItem(

                              value:
                                  "Development",

                              child:
                                  Text(
                                    "Development",
                                  ),

                            ),


                            DropdownMenuItem(

                              value:
                                  "Staging",

                              child:
                                  Text(
                                    "Staging",
                                  ),

                            ),


                            DropdownMenuItem(

                              value:
                                  "Production",

                              child:
                                  Text(
                                    "Production",
                                  ),

                            ),

                          ],


                          onChanged:(v){

                            setState(() {

                              environment=v!;

                            });

                          },

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "API Configuration",

                    subtitle:
                        "Manage backend communication.",


                    child: Column(

                      children: [


                        TextFormField(

                          controller:
                              apiUrlController,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "API Base URL",

                            border:
                                OutlineInputBorder(),

                            prefixIcon:
                                Icon(
                                  Icons.link,
                                ),

                          ),

                        ),



                        const SizedBox(height:20),



                        TextFormField(

                          controller:
                              webhookController,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Webhook URL",

                            border:
                                OutlineInputBorder(),

                          ),

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Firebase Configuration",

                    subtitle:
                        "Push notifications and analytics.",


                    child: TextFormField(

                      controller:
                          firebaseProjectController,


                      decoration:
                          const InputDecoration(

                        labelText:
                            "Firebase Project ID",

                        border:
                            OutlineInputBorder(),

                        prefixIcon:
                            Icon(
                              Icons.cloud,
                            ),

                      ),

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Debug & Logging",

                    child: Column(

                      children: [


                        SwitchListTile(

                          title:
                              const Text(
                                "Debug Mode",
                              ),

                          subtitle:
                              const Text(
                                "Enable developer debugging.",
                              ),


                          value:
                              debugMode,


                          onChanged:(v){

                            setState(() {

                              debugMode=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "System Logs",
                              ),


                          value:
                              enableLogs,


                          onChanged:(v){

                            setState(() {

                              enableLogs=v;

                            });

                          },

                        ),



                        DropdownButtonFormField<String>(

                          value:
                              logLevel,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Log Level",

                            border:
                                OutlineInputBorder(),

                          ),


                          items: const [

                            DropdownMenuItem(

                              value:
                                  "DEBUG",

                              child:
                                  Text(
                                    "DEBUG",
                                  ),

                            ),

                            DropdownMenuItem(

                              value:
                                  "INFO",

                              child:
                                  Text(
                                    "INFO",
                                  ),

                            ),

                            DropdownMenuItem(

                              value:
                                  "ERROR",

                              child:
                                  Text(
                                    "ERROR",
                                  ),

                            ),

                          ],


                          onChanged:(v){

                            setState(() {

                              logLevel=v!;

                            });

                          },

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "System Controls",

                    child: Column(

                      children: [


                        SwitchListTile(

                          title:
                              const Text(
                                "Maintenance Mode",
                              ),

                          subtitle:
                              const Text(
                                "Temporarily disable platform access.",
                              ),


                          value:
                              maintenanceMode,


                          onChanged:(v){

                            setState(() {

                              maintenanceMode=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Feature Flags",
                              ),

                          subtitle:
                              const Text(
                                "Enable experimental features.",
                              ),


                          value:
                              enableFeatureFlags,


                          onChanged:(v){

                            setState(() {

                              enableFeatureFlags=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Crash Reporting",
                              ),


                          value:
                              crashReporting,


                          onChanged:(v){

                            setState(() {

                              crashReporting=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Webhooks",
                              ),


                          value:
                              enableWebhooks,


                          onChanged:(v){

                            setState(() {

                              enableWebhooks=v;

                            });

                          },

                        ),


                      ],

                    ),

                  ),


                ],

              ),

            ),

          ),



          SettingsSaveBar(

            onSave: (){

              ScaffoldMessenger.of(context)
              .showSnackBar(

                const SnackBar(

                  content:
                    Text(
                      "Developer settings saved",
                    ),

                ),

              );

            },


            onReset: (){},


          ),


        ],

      ),

    );

  }

}