import 'package:flutter/material.dart';

import '../widgets/settings_card.dart';
import '../widgets/settings_header.dart';
import '../widgets/settings_save_bar.dart';


class AppearanceSettingsScreen extends StatefulWidget {

  const AppearanceSettingsScreen({
    super.key,
  });


  @override
  State<AppearanceSettingsScreen> createState() =>
      _AppearanceSettingsScreenState();

}



class _AppearanceSettingsScreenState
    extends State<AppearanceSettingsScreen> {


  final TextEditingController appNameController =
      TextEditingController(
        text: "RYDEX",
      );


  final TextEditingController sloganController =
      TextEditingController(
        text: "Your Ride, Your Way",
      );


  final TextEditingController logoUrlController =
      TextEditingController();



  bool darkMode = false;

  bool compactSidebar = false;

  bool showAnimations = true;

  bool showBranding = true;



  String language = "English";

  String theme = "System Default";



  @override
  void dispose() {

    appNameController.dispose();

    sloganController.dispose();

    logoUrlController.dispose();

    super.dispose();

  }



  @override
  Widget build(BuildContext context) {


    return Scaffold(

      body: Column(

        children: [


          SettingsHeader(

            title:
                "Appearance & Branding",

            subtitle:
                "Customize RYDEX visual identity and interface.",

          ),



          Expanded(

            child: SingleChildScrollView(

              padding:
                  const EdgeInsets.all(24),


              child: Column(

                children: [


                  SettingsCard(

                    title:
                        "Brand Information",

                    subtitle:
                        "Configure platform identity.",


                    child: Column(

                      children: [


                        TextFormField(

                          controller:
                              appNameController,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Application Name",

                            border:
                                OutlineInputBorder(),

                            prefixIcon:
                                Icon(
                                  Icons.apps,
                                ),

                          ),

                        ),



                        const SizedBox(height:20),



                        TextFormField(

                          controller:
                              sloganController,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Slogan",

                            border:
                                OutlineInputBorder(),

                          ),

                        ),



                        const SizedBox(height:20),



                        TextFormField(

                          controller:
                              logoUrlController,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Logo URL",

                            border:
                                OutlineInputBorder(),

                            prefixIcon:
                                Icon(
                                  Icons.image,
                                ),

                          ),

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Theme",

                    subtitle:
                        "Control dashboard appearance.",


                    child: Column(

                      children: [


                        DropdownButtonFormField<String>(

                          value:
                              theme,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Theme Mode",

                            border:
                                OutlineInputBorder(),

                          ),


                          items: const [

                            DropdownMenuItem(

                              value:
                                  "System Default",

                              child:
                                  Text(
                                    "System Default",
                                  ),

                            ),


                            DropdownMenuItem(

                              value:
                                  "Light",

                              child:
                                  Text(
                                    "Light",
                                  ),

                            ),


                            DropdownMenuItem(

                              value:
                                  "Dark",

                              child:
                                  Text(
                                    "Dark",
                                  ),

                            ),

                          ],


                          onChanged:(v){

                            setState(() {

                              theme=v!;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Dark Mode",
                              ),


                          value:
                              darkMode,


                          onChanged:(v){

                            setState(() {

                              darkMode=v;

                            });

                          },

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Interface Options",

                    child: Column(

                      children: [


                        SwitchListTile(

                          title:
                              const Text(
                                "Compact Sidebar",
                              ),

                          subtitle:
                              const Text(
                                "Reduce sidebar width.",
                              ),


                          value:
                              compactSidebar,


                          onChanged:(v){

                            setState(() {

                              compactSidebar=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Animations",
                              ),


                          value:
                              showAnimations,


                          onChanged:(v){

                            setState(() {

                              showAnimations=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Show Branding",
                              ),


                          value:
                              showBranding,


                          onChanged:(v){

                            setState(() {

                              showBranding=v;

                            });

                          },

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Language",

                    child:

                    DropdownButtonFormField<String>(

                      value:
                          language,


                      decoration:
                          const InputDecoration(

                        labelText:
                            "Dashboard Language",

                        border:
                            OutlineInputBorder(),

                      ),


                      items: const [

                        DropdownMenuItem(

                          value:
                              "English",

                          child:
                              Text(
                                "English",
                              ),

                        ),


                        DropdownMenuItem(

                          value:
                              "Swahili",

                          child:
                              Text(
                                "Swahili",
                              ),

                        ),

                      ],


                      onChanged:(v){

                        setState(() {

                          language=v!;

                        });

                      },

                    ),

                  ),


                ],

              ),

            ),

          ),



          SettingsSaveBar(

            onSave: (){

              ScaffoldMessenger.of(context)
              .showSnackBar(

                const SnackBar(

                  content:
                    Text(
                      "Appearance settings saved",
                    ),

                ),

              );

            },


            onReset: (){},

          ),


        ],

      ),

    );

  }

}