import 'package:flutter/material.dart';

import '../widgets/settings_card.dart';
import '../widgets/settings_header.dart';
import '../widgets/settings_save_bar.dart';


class BackupSettingsScreen extends StatefulWidget {

  const BackupSettingsScreen({
    super.key,
  });


  @override
  State<BackupSettingsScreen> createState() =>
      _BackupSettingsScreenState();

}



class _BackupSettingsScreenState
    extends State<BackupSettingsScreen> {


  final TextEditingController backupFrequencyController =
      TextEditingController(
        text: "24",
      );


  final TextEditingController backupRetentionController =
      TextEditingController(
        text: "30",
      );



  bool automaticBackup = true;

  bool cloudBackup = false;

  bool encryptBackups = true;

  bool backupDatabase = true;

  bool backupUserData = true;

  bool backupRideData = true;

  bool backupPaymentData = true;

  bool backupLogs = true;



  String storageProvider = "Local Storage";



  @override
  void dispose() {

    backupFrequencyController.dispose();

    backupRetentionController.dispose();

    super.dispose();

  }



  @override
  Widget build(BuildContext context) {


    return Scaffold(

      body: Column(

        children: [


          SettingsHeader(

            title:
                "Backup & Restore",

            subtitle:
                "Manage data protection and recovery options.",

          ),



          Expanded(

            child: SingleChildScrollView(

              padding:
                  const EdgeInsets.all(24),


              child: Column(

                children: [


                  SettingsCard(

                    title:
                        "Backup Configuration",

                    subtitle:
                        "Control automated backup behaviour.",


                    child: Column(

                      children: [


                        SwitchListTile(

                          title:
                              const Text(
                                "Automatic Backups",
                              ),

                          subtitle:
                              const Text(
                                "Create backups automatically.",
                              ),


                          value:
                              automaticBackup,


                          onChanged:(v){

                            setState(() {

                              automaticBackup=v;

                            });

                          },

                        ),



                        TextFormField(

                          controller:
                              backupFrequencyController,


                          keyboardType:
                              TextInputType.number,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Backup Interval (hours)",

                            border:
                                OutlineInputBorder(),

                          ),

                        ),



                        const SizedBox(height:20),



                        TextFormField(

                          controller:
                              backupRetentionController,


                          keyboardType:
                              TextInputType.number,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Backup Retention (days)",

                            border:
                                OutlineInputBorder(),

                          ),

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Storage",

                    subtitle:
                        "Choose backup destination.",


                    child: Column(

                      children: [


                        DropdownButtonFormField<String>(

                          value:
                              storageProvider,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Storage Provider",

                            border:
                                OutlineInputBorder(),

                          ),


                          items: const [

                            DropdownMenuItem(

                              value:
                                  "Local Storage",

                              child:
                                  Text(
                                    "Local Storage",
                                  ),

                            ),


                            DropdownMenuItem(

                              value:
                                  "AWS S3",

                              child:
                                  Text(
                                    "AWS S3",
                                  ),

                            ),


                            DropdownMenuItem(

                              value:
                                  "Google Cloud",

                              child:
                                  Text(
                                    "Google Cloud",
                                  ),

                            ),


                          ],


                          onChanged:(v){

                            setState(() {

                              storageProvider=v!;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Cloud Backup",
                              ),


                          value:
                              cloudBackup,


                          onChanged:(v){

                            setState(() {

                              cloudBackup=v;

                            });

                          },

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Backup Data Selection",

                    subtitle:
                        "Choose what information is backed up.",


                    child: Column(

                      children: [


                        SwitchListTile(

                          title:
                              const Text(
                                "Database",
                              ),

                          value:
                              backupDatabase,


                          onChanged:(v){

                            setState(() {

                              backupDatabase=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "User Data",
                              ),

                          value:
                              backupUserData,


                          onChanged:(v){

                            setState(() {

                              backupUserData=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Ride Data",
                              ),

                          value:
                              backupRideData,


                          onChanged:(v){

                            setState(() {

                              backupRideData=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Payment Data",
                              ),

                          value:
                              backupPaymentData,


                          onChanged:(v){

                            setState(() {

                              backupPaymentData=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "System Logs",
                              ),

                          value:
                              backupLogs,


                          onChanged:(v){

                            setState(() {

                              backupLogs=v;

                            });

                          },

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Security",

                    child: SwitchListTile(

                      title:
                          const Text(
                            "Encrypt Backups",
                          ),

                      subtitle:
                          const Text(
                            "Protect backup files.",
                          ),


                      value:
                          encryptBackups,


                      onChanged:(v){

                        setState(() {

                          encryptBackups=v;

                        });

                      },

                    ),

                  ),


                ],

              ),

            ),

          ),



          SettingsSaveBar(

            onSave: (){

              ScaffoldMessenger.of(context)
              .showSnackBar(

                const SnackBar(

                  content:
                    Text(
                      "Backup settings saved",
                    ),

                ),

              );

            },


            onReset: (){},

          ),


        ],

      ),

    );

  }

}