import 'package:flutter/material.dart';

import '../widgets/settings_card.dart';
import '../widgets/settings_header.dart';
import '../widgets/settings_save_bar.dart';


class RideSettingsScreen extends StatefulWidget {

  const RideSettingsScreen({
    super.key,
  });


  @override
  State<RideSettingsScreen> createState() =>
      _RideSettingsScreenState();

}



class _RideSettingsScreenState
    extends State<RideSettingsScreen> {


  final TextEditingController rideTimeoutController =
      TextEditingController(
        text: "60",
      );


  final TextEditingController driverAcceptanceController =
      TextEditingController(
        text: "30",
      );


  final TextEditingController cancellationWindowController =
      TextEditingController(
        text: "5",
      );


  final TextEditingController maxRadiusController =
      TextEditingController(
        text: "10",
      );


  bool autoAssignDrivers = true;

  bool allowScheduledRides = true;

  bool allowRideSharing = false;

  bool enableSOS = true;

  bool allowPassengerCancellation = true;

  bool allowDriverCancellation = true;

  bool enableDriverReassignment = true;


  String matchingMethod = "Nearest Driver";

  String rideMode = "Normal";



  @override
  void dispose() {

    rideTimeoutController.dispose();

    driverAcceptanceController.dispose();

    cancellationWindowController.dispose();

    maxRadiusController.dispose();

    super.dispose();

  }



  @override
  Widget build(BuildContext context) {


    return Scaffold(

      body: Column(

        children: [


          SettingsHeader(

            title:
                "Ride Settings",

            subtitle:
                "Configure ride requests, matching and lifecycle rules.",

          ),



          Expanded(

            child: SingleChildScrollView(

              padding:
                  const EdgeInsets.all(24),


              child: Column(

                children: [


                  SettingsCard(

                    title:
                        "Ride Assignment",

                    subtitle:
                        "Control how drivers receive rides.",


                    child: Column(

                      children: [


                        SwitchListTile(

                          title:
                              const Text(
                                "Automatic Driver Assignment",
                              ),

                          subtitle:
                              const Text(
                                "Assign nearest available driver automatically.",
                              ),


                          value:
                              autoAssignDrivers,


                          onChanged:(v){

                            setState(() {

                              autoAssignDrivers=v;

                            });

                          },

                        ),



                        const SizedBox(height:15),



                        DropdownButtonFormField<String>(

                          value:
                              matchingMethod,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Driver Matching Method",

                            border:
                                OutlineInputBorder(),

                          ),


                          items: const [

                            DropdownMenuItem(

                              value:
                                  "Nearest Driver",

                              child:
                                  Text(
                                    "Nearest Driver",
                                  ),

                            ),


                            DropdownMenuItem(

                              value:
                                  "Highest Rated",

                              child:
                                  Text(
                                    "Highest Rated",
                                  ),

                            ),


                            DropdownMenuItem(

                              value:
                                  "Fastest Arrival",

                              child:
                                  Text(
                                    "Fastest Arrival",
                                  ),

                            ),

                          ],


                          onChanged:(v){

                            setState(() {

                              matchingMethod=v!;

                            });

                          },

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Ride Timing",

                    subtitle:
                        "Manage ride expiration and acceptance.",


                    child: Column(

                      children: [


                        TextFormField(

                          controller:
                              rideTimeoutController,


                          keyboardType:
                              TextInputType.number,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Ride Request Timeout (seconds)",

                            border:
                                OutlineInputBorder(),

                            prefixIcon:
                                Icon(
                                  Icons.timer,
                                ),

                          ),

                        ),


                        const SizedBox(height:20),



                        TextFormField(

                          controller:
                              driverAcceptanceController,


                          keyboardType:
                              TextInputType.number,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Driver Acceptance Timeout",

                            border:
                                OutlineInputBorder(),

                          ),

                        ),


                        const SizedBox(height:20),



                        TextFormField(

                          controller:
                              cancellationWindowController,


                          keyboardType:
                              TextInputType.number,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Cancellation Window (minutes)",

                            border:
                                OutlineInputBorder(),

                          ),

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Ride Features",

                    child: Column(

                      children: [


                        SwitchListTile(

                          title:
                              const Text(
                                "Scheduled Rides",
                              ),

                          value:
                              allowScheduledRides,


                          onChanged:(v){

                            setState(() {

                              allowScheduledRides=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Ride Sharing",
                              ),

                          value:
                              allowRideSharing,


                          onChanged:(v){

                            setState(() {

                              allowRideSharing=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "SOS Emergency Feature",
                              ),

                          subtitle:
                              const Text(
                                "Allow emergency assistance requests.",
                              ),


                          value:
                              enableSOS,


                          onChanged:(v){

                            setState(() {

                              enableSOS=v;

                            });

                          },

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Cancellation & Reassignment",

                    child: Column(

                      children: [


                        SwitchListTile(

                          title:
                              const Text(
                                "Passenger Cancellation",
                              ),

                          value:
                              allowPassengerCancellation,


                          onChanged:(v){

                            setState(() {

                              allowPassengerCancellation=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Driver Cancellation",
                              ),

                          value:
                              allowDriverCancellation,


                          onChanged:(v){

                            setState(() {

                              allowDriverCancellation=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Automatic Driver Reassignment",
                              ),

                          subtitle:
                              const Text(
                                "Find another driver when rejected.",
                              ),


                          value:
                              enableDriverReassignment,


                          onChanged:(v){

                            setState(() {

                              enableDriverReassignment=v;

                            });

                          },

                        ),


                      ],

                    ),

                  ),



                ],

              ),

            ),

          ),



          SettingsSaveBar(

            onSave: (){

              ScaffoldMessenger.of(context)
              .showSnackBar(

                const SnackBar(

                  content:
                    Text(
                      "Ride settings saved",
                    ),

                ),

              );

            },

            onReset: (){},

          ),


        ],

      ),

    );

  }

}