import 'package:flutter/material.dart';

import '../widgets/settings_card.dart';
import '../widgets/settings_header.dart';
import '../widgets/settings_save_bar.dart';

class NotificationSettingsScreen extends StatefulWidget {
  const NotificationSettingsScreen({
    super.key,
  });

  @override
  State<NotificationSettingsScreen> createState() =>
      _NotificationSettingsScreenState();
}

class _NotificationSettingsScreenState
    extends State<NotificationSettingsScreen> {

  bool pushNotifications = true;
  bool smsNotifications = true;
  bool emailNotifications = true;

  bool rideUpdates = true;
  bool paymentAlerts = true;
  bool driverAlerts = true;
  bool promotionalMessages = true;

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      body: Column(

        children: [

          SettingsHeader(
            title: "Notification Settings",
            subtitle:
                "Control how RYDEX sends alerts and updates.",
          ),

          Expanded(

            child: SingleChildScrollView(

              padding:
                  const EdgeInsets.all(24),

              child: Column(

                children: [

                  SettingsCard(

                    title:
                        "Notification Channels",

                    subtitle:
                        "Choose available communication methods.",

                    child: Column(
                      children: [

                        SwitchListTile(
                          title:
                              const Text(
                                "Push Notifications",
                              ),
                          value:
                              pushNotifications,
                          onChanged:(v){
                            setState(() {
                              pushNotifications=v;
                            });
                          },
                        ),

                        SwitchListTile(
                          title:
                              const Text(
                                "SMS Notifications",
                              ),
                          value:
                              smsNotifications,
                          onChanged:(v){
                            setState(() {
                              smsNotifications=v;
                            });
                          },
                        ),

                        SwitchListTile(
                          title:
                              const Text(
                                "Email Notifications",
                              ),
                          value:
                              emailNotifications,
                          onChanged:(v){
                            setState(() {
                              emailNotifications=v;
                            });
                          },
                        ),

                      ],
                    ),

                  ),

                  const SizedBox(height:24),


                  SettingsCard(

                    title:
                        "Notification Events",

                    subtitle:
                        "Select events that trigger messages.",

                    child: Column(
                      children: [

                        SwitchListTile(
                          title:
                              const Text(
                                "Ride Updates",
                              ),
                          subtitle:
                              const Text(
                                "Driver assigned, arrival, completion.",
                              ),
                          value:
                              rideUpdates,
                          onChanged:(v){
                            setState(() {
                              rideUpdates=v;
                            });
                          },
                        ),


                        SwitchListTile(
                          title:
                              const Text(
                                "Payment Alerts",
                              ),
                          value:
                              paymentAlerts,
                          onChanged:(v){
                            setState(() {
                              paymentAlerts=v;
                            });
                          },
                        ),


                        SwitchListTile(
                          title:
                              const Text(
                                "Driver Alerts",
                              ),
                          value:
                              driverAlerts,
                          onChanged:(v){
                            setState(() {
                              driverAlerts=v;
                            });
                          },
                        ),


                        SwitchListTile(
                          title:
                              const Text(
                                "Promotional Messages",
                              ),
                          value:
                              promotionalMessages,
                          onChanged:(v){
                            setState(() {
                              promotionalMessages=v;
                            });
                          },
                        ),

                      ],
                    ),

                  ),

                ],

              ),

            ),

          ),


          SettingsSaveBar(

            onSave: (){
              ScaffoldMessenger.of(context)
              .showSnackBar(
                const SnackBar(
                  content:
                    Text(
                      "Notification settings saved",
                    ),
                ),
              );
            },

            onReset: (){},

          ),

        ],

      ),

    );

  }
}