import 'package:flutter/material.dart';

import '../models/settings_menu.dart';
import '../widgets/settings_sidebar.dart';
import 'map_settings_screen.dart';
import 'general_settings_screen.dart';
import 'notification_settings_screen.dart';
import 'security_settings_screen.dart';
import 'driver_settings_screen.dart';
import 'ride_settings_screen.dart';
import 'appearance_settings_screen.dart';
import 'backup_settings_screen.dart';
import 'passenger_settings_screen.dart';
import 'analytics_settings_screen.dart';
import 'developer_settings_screen.dart';

class SettingsDashboard extends StatefulWidget {

  const SettingsDashboard({super.key});

  @override
  State<SettingsDashboard> createState() =>
      _SettingsDashboardState();

}

class _SettingsDashboardState
    extends State<SettingsDashboard> {

  int selectedIndex = 0;

  late final List<SettingsMenu> menus;

  @override
  void initState() {

    super.initState();

    menus = [

      SettingsMenu(
        title: "General",
        icon: Icons.business,
        page: const GeneralSettingsScreen(),
      ),

      SettingsMenu(
        title: "Payments",
        icon: Icons.payments,
        page: const Center(
          child: Text("Payments"),
        ),
      ),

      SettingsMenu(
        title: "Ride Settings",
        icon: Icons.local_taxi,
        page: const RideSettingsScreen(),
        
      ),

      SettingsMenu(
        title: "Driver Settings",
        icon: Icons.drive_eta,
        page: const DriverSettingsScreen(),
      ),

      SettingsMenu(
        title: "Passenger Settings",
        icon: Icons.people,
        page: const PassengerSettingsScreen(),
        
      ),

      SettingsMenu(
        title: "Notifications",
        icon: Icons.notifications,
        page: const NotificationSettingsScreen(),
      ),
      ),

      SettingsMenu(
        title: "Maps",
        icon: Icons.map,
       page: const MapSettingsScreen(),
        
      ),

      SettingsMenu(
        title: "Security",
        icon: Icons.security,
        page: const SecuritySettingsScreen(),
        
      ),

      SettingsMenu(
        title: "Analytics",
        icon: Icons.bar_chart,
        page: const AnalyticsSettingsScreen(),
        ),
      ),

      SettingsMenu(
        title: "Backup",
        icon: Icons.backup,
        page: const BackupSettingsScreen(),,
        ),
      ),

      SettingsMenu(
        title: "Appearance",
        icon: Icons.palette,
        page: const AppearanceSettingsScreen(
        ),
      ),

      SettingsMenu(
        title: "Developer",
        icon: Icons.code,
        page: const DeveloperSettingsScreen(),
        ),
      ),

    ];

  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      body: Row(

        children: [

          SettingsSidebar(

            items: menus,

            selectedIndex: selectedIndex,

            onSelected: (index){

              setState(() {

                selectedIndex=index;

              });

            },

          ),

          Expanded(

            child: menus[selectedIndex].page,

          ),

        ],

      ),

    );

  }

}