import 'package:flutter/material.dart';

import '../widgets/settings_card.dart';
import '../widgets/settings_header.dart';
import '../widgets/settings_save_bar.dart';


class SecuritySettingsScreen extends StatefulWidget {

  const SecuritySettingsScreen({
    super.key,
  });


  @override
  State<SecuritySettingsScreen> createState() =>
      _SecuritySettingsScreenState();

}



class _SecuritySettingsScreenState
    extends State<SecuritySettingsScreen> {


  final TextEditingController sessionTimeoutController =
      TextEditingController(
        text: "60",
      );


  final TextEditingController maxLoginAttemptsController =
      TextEditingController(
        text: "5",
      );


  final TextEditingController jwtExpiryController =
      TextEditingController(
        text: "60",
      );


  bool twoFactorAuthentication = true;

  bool adminActivityLogs = true;

  bool deviceManagement = true;

  bool loginAlerts = true;

  bool encryptSensitiveData = true;

  bool forceStrongPasswords = true;



  @override
  void dispose() {

    sessionTimeoutController.dispose();

    maxLoginAttemptsController.dispose();

    jwtExpiryController.dispose();

    super.dispose();

  }



  @override
  Widget build(BuildContext context) {

    return Scaffold(

      body: Column(

        children: [


          SettingsHeader(

            title:
                "Security Settings",

            subtitle:
                "Manage authentication, access control and protection.",

          ),



          Expanded(

            child: SingleChildScrollView(

              padding:
                  const EdgeInsets.all(24),


              child: Column(

                children: [


                  SettingsCard(

                    title:
                        "Authentication",

                    subtitle:
                        "Control user login security.",


                    child: Column(

                      children: [


                        SwitchListTile(

                          title:
                              const Text(
                                "Two-Factor Authentication",
                              ),

                          subtitle:
                              const Text(
                                "Require additional verification.",
                              ),


                          value:
                              twoFactorAuthentication,


                          onChanged:(value){

                            setState(() {

                              twoFactorAuthentication =
                                  value;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Strong Password Policy",
                              ),

                          subtitle:
                              const Text(
                                "Require secure passwords.",
                              ),


                          value:
                              forceStrongPasswords,


                          onChanged:(value){

                            setState(() {

                              forceStrongPasswords =
                                  value;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Login Alerts",
                              ),

                          subtitle:
                              const Text(
                                "Notify users about new logins.",
                              ),


                          value:
                              loginAlerts,


                          onChanged:(value){

                            setState(() {

                              loginAlerts =
                                  value;

                            });

                          },

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Session Management",

                    subtitle:
                        "Control user sessions and tokens.",


                    child: Column(

                      children: [


                        TextFormField(

                          controller:
                              sessionTimeoutController,


                          keyboardType:
                              TextInputType.number,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Session Timeout (minutes)",

                            border:
                                OutlineInputBorder(),

                            prefixIcon:
                                Icon(
                                  Icons.timer,
                                ),

                          ),

                        ),



                        const SizedBox(height:20),



                        TextFormField(

                          controller:
                              jwtExpiryController,


                          keyboardType:
                              TextInputType.number,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "JWT Expiry (minutes)",

                            border:
                                OutlineInputBorder(),

                            prefixIcon:
                                Icon(
                                  Icons.token,
                                ),

                          ),

                        ),



                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Login Protection",

                    subtitle:
                        "Prevent unauthorized access.",


                    child: Column(

                      children: [


                        TextFormField(

                          controller:
                              maxLoginAttemptsController,


                          keyboardType:
                              TextInputType.number,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Maximum Login Attempts",

                            border:
                                OutlineInputBorder(),

                            prefixIcon:
                                Icon(
                                  Icons.lock,
                                ),

                          ),

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Data Protection",

                    subtitle:
                        "Protect sensitive platform data.",


                    child: Column(

                      children: [


                        SwitchListTile(

                          title:
                              const Text(
                                "Encrypt Sensitive Data",
                              ),

                          subtitle:
                              const Text(
                                "Protect stored private information.",
                              ),


                          value:
                              encryptSensitiveData,


                          onChanged:(value){

                            setState(() {

                              encryptSensitiveData =
                                  value;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Admin Activity Logs",
                              ),

                          subtitle:
                              const Text(
                                "Track administrator actions.",
                              ),


                          value:
                              adminActivityLogs,


                          onChanged:(value){

                            setState(() {

                              adminActivityLogs =
                                  value;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Device Management",
                              ),

                          subtitle:
                              const Text(
                                "Manage logged-in devices.",
                              ),


                          value:
                              deviceManagement,


                          onChanged:(value){

                            setState(() {

                              deviceManagement =
                                  value;

                            });

                          },

                        ),


                      ],

                    ),

                  ),


                ],

              ),

            ),

          ),



          SettingsSaveBar(

            onSave: (){

              ScaffoldMessenger.of(context)
              .showSnackBar(

                const SnackBar(

                  content:
                    Text(
                      "Security settings saved",
                    ),

                ),

              );

            },


            onReset: (){},


          ),


        ],

      ),

    );

  }

}