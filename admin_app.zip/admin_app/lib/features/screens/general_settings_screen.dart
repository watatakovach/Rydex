import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:admin_app/features/screens/settings_header.dart';
import 'package:admin_app/features/models/general_settings_model.dart';
import 'package:admin_app/features/providers/general_settings_provider.dart';

class GeneralSettingsScreen extends StatefulWidget {
  const GeneralSettingsScreen({super.key});

  @override
  State<GeneralSettingsScreen> createState() =>
      _GeneralSettingsScreenState();
}

// class _GeneralSettingsScreenState extends State<GeneralSettingsScreen> {
class _GeneralSettingsScreenState
    extends State<GeneralSettingsScreen> {
  final _formKey = GlobalKey<FormState>();

  final _companyController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _addressController = TextEditingController();
  final _websiteController = TextEditingController();

  String timezone = "Africa/Nairobi";
  String language = "English";
  String currency = "KES";
  String currencySymbol = "KSh";
  String distanceUnit = "Kilometers";
  String dateFormat = "dd/MM/yyyy";
  String timeFormat = "24 Hour";

  bool maintenance = false;
  bool registration = true;
  bool driverRegistration = true;
  bool passengerRegistration = true;

  bool initialized = false;

  bool autoApproveDrivers = false;
  bool requireVehicleInspection = true;
  bool requireBackgroundCheck = true;
  bool requireDrivingLicense = true;

  bool requirePassengerOtp = true;
  bool requirePassengerEmailVerification = false;
  bool enablePassengerWallet = true;
  bool enableReferralProgram = true;
  bool allowGuestRideRequests = false;

  bool autoAssignDrivers = true;
  bool enableScheduledRides = true;
  bool enableRideSharing = false;
  bool enableSOS = true;

  bool surgePricing = true;
  bool nightPricing = true;
  bool holidayPricing = true;

  double surgeMultiplier = 1.5;
  double nightMultiplier = 1.2;
  double holidayMultiplier = 1.3;

  double maxSearchRadius = 10;
  double rideRequestTimeout = 30;
  double driverAcceptanceTimeout = 20;
  double cancellationWindow = 5;
  double minimumDriverRating = 4.0;

  final TextEditingController baseFareController =
      TextEditingController(text: "150");

  final TextEditingController pricePerKmController =
      TextEditingController(text: "35");

  final TextEditingController pricePerMinuteController =
      TextEditingController(text: "5");

  final TextEditingController bookingFeeController =
      TextEditingController(text: "20");

  final TextEditingController waitingFeeController =
      TextEditingController(text: "5");

  final TextEditingController cancellationFeeController =
      TextEditingController(text: "100");

  final TextEditingController minimumFareController =
      TextEditingController(text: "200");

  final TextEditingController maximumFareController =
      TextEditingController(text: "10000");

  final TextEditingController airportFeeController =
      TextEditingController(text: "300");

  final TextEditingController tollFeeController =
      TextEditingController(text: "0");

  final TextEditingController driverCommissionController =
      TextEditingController(text: "20");

  // Payment methods
  bool enableCashPayments = true;
  bool enableMpesa = true;
  bool enableStripe = false;
  bool enablePaypal = false;
  bool enableFlutterwave = false;
  bool enableAirtelMoney = false;
  bool enableWallet = true;

  // Driver payouts
  bool automaticDriverPayouts = false;
  bool allowPartialPayouts = true;
  bool enableRefunds = true;

  // M-Pesa
  final mpesaConsumerKeyController = TextEditingController();
  final mpesaConsumerSecretController = TextEditingController();
  final mpesaShortCodeController = TextEditingController();
  final mpesaPassKeyController = TextEditingController();
  final mpesaCallbackController = TextEditingController();

  // Stripe
  final stripePublicKeyController = TextEditingController();
  final stripeSecretKeyController = TextEditingController();
  final stripeWebhookController = TextEditingController();

  // PayPal
  final paypalClientIdController = TextEditingController();
  final paypalSecretController = TextEditingController();

  // Flutterwave
  final flutterwavePublicKeyController = TextEditingController();
  final flutterwaveSecretKeyController = TextEditingController();
  final flutterwaveEncryptionKeyController = TextEditingController();

  @override
void dispose() {

  _companyController.dispose();
  _emailController.dispose();
  _phoneController.dispose();
  _addressController.dispose();
  _websiteController.dispose();

  baseFareController.dispose();
  pricePerKmController.dispose();
  pricePerMinuteController.dispose();
  bookingFeeController.dispose();
  waitingFeeController.dispose();
  cancellationFeeController.dispose();
  minimumFareController.dispose();
  maximumFareController.dispose();
  airportFeeController.dispose();
  tollFeeController.dispose();
  driverCommissionController.dispose();

  mpesaConsumerKeyController.dispose();
  mpesaConsumerSecretController.dispose();
  mpesaShortCodeController.dispose();
  mpesaPassKeyController.dispose();
  mpesaCallbackController.dispose();

  stripePublicKeyController.dispose();
  stripeSecretKeyController.dispose();
  stripeWebhookController.dispose();

  paypalClientIdController.dispose();
  paypalSecretController.dispose();

  flutterwavePublicKeyController.dispose();
  flutterwaveSecretKeyController.dispose();
  flutterwaveEncryptionKeyController.dispose();

  super.dispose();
}

  void loadData(GeneralSettings settings) {
    if (initialized) return;

    initialized = true;

  _companyController.text =
    settings.companyName ?? "";

_emailController.text =
    settings.companyEmail ?? "";

_phoneController.text =
    settings.companyPhone ?? "";

_addressController.text =
    settings.companyAddress ?? "";

_websiteController.text =
    settings.website ?? "";

    timezone = settings.timezone;
    language = settings.language;
    currency = settings.currency;
    currencySymbol = settings.currencySymbol;
    distanceUnit = settings.distanceUnit;
    dateFormat = settings.dateFormat;
    timeFormat = settings.timeFormat;

    maintenance = settings.maintenanceMode;
    registration = settings.registrationEnabled;
    driverRegistration = settings.driverRegistrationEnabled;
    passengerRegistration = settings.passengerRegistrationEnabled;
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<GeneralSettingsProvider>(
      builder: (context, provider, child) {
        if (provider.loading) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        }

        if (provider.settings == null) {
          return const Center(
            child: Text("No settings found"),
          );
        }

        loadData(provider.settings!);

        return Scaffold(
          body: Column(
            children: [
              SettingsHeader(
                title: "General Settings",
                subtitle: "Manage company and platform information.",
                actions: [
                  ElevatedButton.icon(
                    onPressed: () {

  if (_formKey.currentState!.validate()) {

    // Save logic will be connected in next stage

  }

},
                    icon: const Icon(Icons.save),
                    label: const Text("Save Changes"),
                  ),
                ],
              ),
              Expanded(
                child: Form(
                  key: _formKey,
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildCompanyCard(),

                        const SizedBox(height: 24),

                        _buildLocalizationCard(),

                        const SizedBox(height: 24),

                        _buildSystemSettingsCard(),

                        const SizedBox(height: 24),

                        _buildPlatformSettingsCard(),

                        const SizedBox(height: 24),

                        _buildPricingCard(),

                        const SizedBox(height: 24),

                        _buildPaymentSettingsCard(),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildCompanyCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Company Information",
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 25),

            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _companyController,
                    decoration: const InputDecoration(
                      labelText: "Company Name",
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.business),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "Company name is required";
                      }
                      return null;
                    },
                  ),
                ),

                const SizedBox(width: 20),

                Expanded(
                  child: TextFormField(
                    controller: _emailController,
                    decoration: const InputDecoration(
                      labelText: "Support Email",
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.email),
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _phoneController,
                    decoration: const InputDecoration(
                      labelText: "Support Phone",
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.phone),
                    ),
                  ),
                ),

                const SizedBox(width: 20),

                Expanded(
                  child: TextFormField(
                    controller: _websiteController,
                    decoration: const InputDecoration(
                      labelText: "Website",
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.language),
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            TextFormField(
              controller: _addressController,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: "Business Address",
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.location_on),
              ),
            ),

            const SizedBox(height: 25),

            const Divider(),

            const SizedBox(height: 15),

            Row(
              children: [
                CircleAvatar(
                  radius: 35,
                  backgroundColor: Colors.grey.shade200,
                  child: const Icon(
                    Icons.business,
                    size: 40,
                  ),
                ),

                const SizedBox(width: 20),

                ElevatedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.upload),
                  label: const Text("Upload Logo"),
                ),

                const SizedBox(width: 10),

                OutlinedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.delete),
                  label: const Text("Remove"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLocalizationCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Localization & Regional Settings",
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 25),

            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: [
  "Africa/Nairobi",
  "UTC",
  "Africa/Kampala",
  "Africa/Dar_es_Salaam",
].contains(timezone)
    ? timezone
    : "Africa/Nairobi",
                    decoration: const InputDecoration(
                      labelText: "Timezone",
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.schedule),
                    ),
                    items: const [
                      DropdownMenuItem(
                        value: "Africa/Nairobi",
                        child: Text("Africa/Nairobi"),
                      ),
                      DropdownMenuItem(
                        value: "UTC",
                        child: Text("UTC"),
                      ),
                      DropdownMenuItem(
                        value: "Africa/Kampala",
                        child: Text("Africa/Kampala"),
                      ),
                      DropdownMenuItem(
                        value: "Africa/Dar_es_Salaam",
                        child: Text("Africa/Dar es Salaam"),
                      ),
                    ],
                    onChanged: (value) {
                      setState(() {
                        timezone = value!;
                      });
                    },
                  ),
                ),

                const SizedBox(width: 20),

                Expanded(
                  child: DropdownButtonFormField<String>(
                   value: [
  "English",
  "Swahili",
  "French",
].contains(language)
    ? language
    : "English",
                    decoration: const InputDecoration(
                      labelText: "Language",
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.language),
                    ),
                    items: const [
                      DropdownMenuItem(
                        value: "English",
                        child: Text("English"),
                      ),
                      DropdownMenuItem(
                        value: "Swahili",
                        child: Text("Swahili"),
                      ),
                      DropdownMenuItem(
                        value: "French",
                        child: Text("French"),
                      ),
                    ],
                    onChanged: (value) {
                      setState(() {
                        language = value!;
                      });
                    },
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: [
  "KES",
  "USD",
  "UGX",
  "TZS",
].contains(currency)
    ? currency
    : "KES",
                    decoration: const InputDecoration(
                      labelText: "Currency",
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.payments),
                    ),
                    items: const [
                      DropdownMenuItem(
                        value: "KES",
                        child: Text("KES"),
                      ),
                      DropdownMenuItem(
                        value: "USD",
                        child: Text("USD"),
                      ),
                      DropdownMenuItem(
                        value: "UGX",
                        child: Text("UGX"),
                      ),
                      DropdownMenuItem(
                        value: "TZS",
                        child: Text("TZS"),
                      ),
                    ],
                    onChanged: (value) {
                      setState(() {
                        currency = value!;
                      });
                    },
                  ),
                ),

                const SizedBox(width: 20),

                Expanded(
                  child: TextFormField(
                    initialValue: currencySymbol,
                    decoration: const InputDecoration(
                      labelText: "Currency Symbol",
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.attach_money),
                    ),
                    onChanged: (value) {
                      currencySymbol = value;
                    },
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: [
  "Kilometers",
  "Miles",
].contains(distanceUnit)
    ? distanceUnit
    : "Kilometers",
                    decoration: const InputDecoration(
                      labelText: "Distance Unit",
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.straighten),
                    ),
                    items: const [
                      DropdownMenuItem(
                        value: "Kilometers",
                        child: Text("Kilometers"),
                      ),
                      DropdownMenuItem(
                        value: "Miles",
                        child: Text("Miles"),
                      ),
                    ],
                    onChanged: (value) {
                      setState(() {
                        distanceUnit = value!;
                      });
                    },
                  ),
                ),

                const SizedBox(width: 20),

                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: [
  "dd/MM/yyyy",
  "MM/dd/yyyy",
  "yyyy-MM-dd",
].contains(dateFormat)
    ? dateFormat
    : "dd/MM/yyyy",
                    decoration: const InputDecoration(
                      labelText: "Date Format",
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.calendar_today),
                    ),
                    items: const [
                      DropdownMenuItem(
                        value: "dd/MM/yyyy",
                        child: Text("DD/MM/YYYY"),
                      ),
                      DropdownMenuItem(
                        value: "MM/dd/yyyy",
                        child: Text("MM/DD/YYYY"),
                      ),
                      DropdownMenuItem(
                        value: "yyyy-MM-dd",
                        child: Text("YYYY-MM-DD"),
                      ),
                    ],
                    onChanged: (value) {
                      setState(() {
                        dateFormat = value!;
                      });
                    },
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            DropdownButtonFormField<String>(
              value: [
  "24 Hour",
  "12 Hour",
].contains(timeFormat)
    ? timeFormat
    : "24 Hour",
              decoration: const InputDecoration(
                labelText: "Time Format",
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.access_time),
              ),
              items: const [
                DropdownMenuItem(
                  value: "24 Hour",
                  child: Text("24 Hour"),
                ),
                DropdownMenuItem(
                  value: "12 Hour",
                  child: Text("12 Hour (AM / PM)"),
                ),
              ],
              onChanged: (value) {
                setState(() {
                  timeFormat = value!;
                });
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSystemSettingsCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "System Configuration",
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 8),

            const Text(
              "Configure platform-wide system behaviour.",
              style: TextStyle(color: Colors.grey),
            ),

            const SizedBox(height: 30),

            _buildSwitchTile(
              title: "Maintenance Mode",
              subtitle: "Temporarily disable the platform for maintenance.",
              value: maintenance,
              onChanged: (value) {
                setState(() {
                  maintenance = value;
                });
              },
            ),

            const Divider(),

            _buildSwitchTile(
              title: "Enable User Registration",
              subtitle:
                  "Allow new passengers and drivers to create accounts.",
              value: registration,
              onChanged: (value) {
                setState(() {
                  registration = value;
                });
              },
            ),

            const Divider(),

            _buildSwitchTile(
              title: "Driver Registration",
              subtitle: "Allow new drivers to register.",
              value: driverRegistration,
              onChanged: (value) {
                setState(() {
                  driverRegistration = value;
                });
              },
            ),

            const Divider(),

            _buildSwitchTile(
              title: "Passenger Registration",
              subtitle: "Allow new passengers to register.",
              value: passengerRegistration,
              onChanged: (value) {
                setState(() {
                  passengerRegistration = value;
                });
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSwitchTile({
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return SwitchListTile(
      contentPadding: EdgeInsets.zero,
      title: Text(
        title,
        style: const TextStyle(
          fontWeight: FontWeight.w600,
        ),
      ),
      subtitle: Text(subtitle),
      value: value,
      onChanged: onChanged,
    );
  }

  Widget _buildPlatformSettingsCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Platform Configuration",
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 30),

            //-------------------------------------
            // DRIVER SETTINGS
            //-------------------------------------

            const Text(
              "Driver Settings",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),

            const SizedBox(height: 20),

            _buildSwitchTile(
              title: "Auto Approve Drivers",
              subtitle: "Automatically approve new driver accounts.",
              value: autoApproveDrivers,
              onChanged: (v) {
                setState(() {
                  autoApproveDrivers = v;
                });
              },
            ),

            _buildSwitchTile(
              title: "Require Vehicle Inspection",
              subtitle: "Vehicle must pass inspection before activation.",
              value: requireVehicleInspection,
              onChanged: (v) {
                setState(() {
                  requireVehicleInspection = v;
                });
              },
            ),

            _buildSwitchTile(
              title: "Require Background Check",
              subtitle: "Driver background verification is mandatory.",
              value: requireBackgroundCheck,
              onChanged: (v) {
                setState(() {
                  requireBackgroundCheck = v;
                });
              },
            ),

            _buildSwitchTile(
              title: "Require Driving License",
              subtitle: "Driving licence must be uploaded.",
              value: requireDrivingLicense,
              onChanged: (v) {
                setState(() {
                  requireDrivingLicense = v;
                });
              },
            ),

            const SizedBox(height: 30),

            //-------------------------------------
            // PASSENGER SETTINGS
            //-------------------------------------

            const Text(
              "Passenger Settings",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),

            const SizedBox(height: 20),

            _buildSwitchTile(
              title: "OTP Verification",
              subtitle: "Verify passenger phone number.",
              value: requirePassengerOtp,
              onChanged: (v) {
                setState(() {
                  requirePassengerOtp = v;
                });
              },
            ),

            _buildSwitchTile(
              title: "Email Verification",
              subtitle: "Require email verification.",
              value: requirePassengerEmailVerification,
              onChanged: (v) {
                setState(() {
                  requirePassengerEmailVerification = v;
                });
              },
            ),

            _buildSwitchTile(
              title: "Passenger Wallet",
              subtitle: "Enable wallet functionality.",
              value: enablePassengerWallet,
              onChanged: (v) {
                setState(() {
                  enablePassengerWallet = v;
                });
              },
            ),

            _buildSwitchTile(
              title: "Referral Program",
              subtitle: "Reward passengers for referrals.",
              value: enableReferralProgram,
              onChanged: (v) {
                setState(() {
                  enableReferralProgram = v;
                });
              },
            ),

            _buildSwitchTile(
              title: "Guest Ride Requests",
              subtitle: "Allow ride requests without an account.",
              value: allowGuestRideRequests,
              onChanged: (v) {
                setState(() {
                  allowGuestRideRequests = v;
                });
              },
            ),

            const SizedBox(height: 30),

            //-------------------------------------
            // RIDE SETTINGS
            //-------------------------------------

            const Text(
              "Ride Settings",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),

            const SizedBox(height: 20),

            _buildSwitchTile(
              title: "Auto Driver Assignment",
              subtitle: "Automatically assign the nearest driver.",
              value: autoAssignDrivers,
              onChanged: (v) {
                setState(() {
                  autoAssignDrivers = v;
                });
              },
            ),

            _buildSwitchTile(
              title: "Scheduled Rides",
              subtitle: "Allow future ride bookings.",
              value: enableScheduledRides,
              onChanged: (v) {
                setState(() {
                  enableScheduledRides = v;
                });
              },
            ),

            _buildSwitchTile(
              title: "Ride Sharing",
              subtitle: "Allow multiple passengers to share rides.",
              value: enableRideSharing,
              onChanged: (v) {
                setState(() {
                  enableRideSharing = v;
                });
              },
            ),

            _buildSwitchTile(
              title: "SOS Emergency Button",
              subtitle: "Enable emergency assistance.",
              value: enableSOS,
              onChanged: (v) {
                setState(() {
                  enableSOS = v;
                });
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _priceField({
    required String label,
    required TextEditingController controller,
    IconData? icon,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
        prefixIcon: Icon(icon ?? Icons.payments),
        prefixText: "KES ",
      ),
    );
  }

  Widget _buildPricingCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Pricing & Fare Configuration",
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 30),

            Wrap(
              spacing: 20,
              runSpacing: 20,
              children: [
                SizedBox(
                  width: 300,
                  child: _priceField(
                    label: "Base Fare",
                    controller: baseFareController,
                  ),
                ),

                SizedBox(
                  width: 300,
                  child: _priceField(
                    label: "Price Per Kilometer",
                    controller: pricePerKmController,
                  ),
                ),

                SizedBox(
                  width: 300,
                  child: _priceField(
                    label: "Price Per Minute",
                    controller: pricePerMinuteController,
                  ),
                ),

                SizedBox(
                  width: 300,
                  child: _priceField(
                    label: "Booking Fee",
                    controller: bookingFeeController,
                  ),
                ),

                SizedBox(
                  width: 300,
                  child: _priceField(
                    label: "Waiting Fee",
                    controller: waitingFeeController,
                  ),
                ),

                SizedBox(
                  width: 300,
                  child: _priceField(
                    label: "Cancellation Fee",
                    controller: cancellationFeeController,
                  ),
                ),

                SizedBox(
                  width: 300,
                  child: _priceField(
                    label: "Minimum Fare",
                    controller: minimumFareController,
                  ),
                ),

                SizedBox(
                  width: 300,
                  child: _priceField(
                    label: "Maximum Fare",
                    controller: maximumFareController,
                  ),
                ),

                SizedBox(
                  width: 300,
                  child: _priceField(
                    label: "Airport Fee",
                    controller: airportFeeController,
                  ),
                ),

                SizedBox(
                  width: 300,
                  child: _priceField(
                    label: "Toll Fee",
                    controller: tollFeeController,
                  ),
                ),

                SizedBox(
                  width: 300,
                  child: _priceField(
                    label: "Driver Commission %",
                    controller: driverCommissionController,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 35),

            const Divider(),

            const SizedBox(height: 20),

            const Text(
              "Dynamic Pricing",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),

            const SizedBox(height: 20),

            _buildSwitchTile(
              title: "Enable Surge Pricing",
              subtitle: "Increase fares during peak demand.",
              value: surgePricing,
              onChanged: (v) {
                setState(() {
                  surgePricing = v;
                });
              },
            ),

            Slider(
              value: surgeMultiplier,
              min: 1,
              max: 5,
              divisions: 40,
              label: "${surgeMultiplier.toStringAsFixed(1)}x",
              onChanged: (v) {
                setState(() {
                  surgeMultiplier = v;
                });
              },
            ),

            const Divider(),

            _buildSwitchTile(
              title: "Night Pricing",
              subtitle: "Apply night fare multiplier.",
              value: nightPricing,
              onChanged: (v) {
                setState(() {
                  nightPricing = v;
                });
              },
            ),

            Slider(
              value: nightMultiplier,
              min: 1,
              max: 3,
              divisions: 20,
              label: "${nightMultiplier.toStringAsFixed(1)}x",
              onChanged: (v) {
                setState(() {
                  nightMultiplier = v;
                });
              },
            ),

            const Divider(),

            _buildSwitchTile(
              title: "Holiday Pricing",
              subtitle: "Apply holiday fare multiplier.",
              value: holidayPricing,
              onChanged: (v) {
                setState(() {
                  holidayPricing = v;
                });
              },
            ),

            Slider(
              value: holidayMultiplier,
              min: 1,
              max: 3,
              divisions: 20,
              label: "${holidayMultiplier.toStringAsFixed(1)}x",
              onChanged: (v) {
                setState(() {
                  holidayMultiplier = v;
                });
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _secretField(
    String label,
    TextEditingController controller,
  ) {
    return TextFormField(
      controller: controller,
      obscureText: true,
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
        prefixIcon: const Icon(Icons.key),
      ),
    );
  }

  Widget _buildPaymentSettingsCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Payment Gateway Settings",
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 30),

            const Text(
              "Accepted Payment Methods",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),

            const SizedBox(height: 15),

            _buildSwitchTile(
              title: "Cash Payments",
              subtitle: "Allow passengers to pay cash.",
              value: enableCashPayments,
              onChanged: (v) {
                setState(() {
                  enableCashPayments = v;
                });
              },
            ),

            _buildSwitchTile(
              title: "M-Pesa",
              subtitle: "Enable Safaricom M-Pesa.",
              value: enableMpesa,
              onChanged: (v) {
                setState(() {
                  enableMpesa = v;
                });
              },
            ),

            _buildSwitchTile(
              title: "Stripe",
              subtitle: "Enable Stripe cards.",
              value: enableStripe,
              onChanged: (v) {
                setState(() {
                  enableStripe = v;
                });
              },
            ),

            _buildSwitchTile(
              title: "PayPal",
              subtitle: "Enable PayPal.",
              value: enablePaypal,
              onChanged: (v) {
                setState(() {
                  enablePaypal = v;
                });
              },
            ),

            _buildSwitchTile(
              title: "Flutterwave",
              subtitle: "Enable Flutterwave.",
              value: enableFlutterwave,
              onChanged: (v) {
                setState(() {
                  enableFlutterwave = v;
                });
              },
            ),

            _buildSwitchTile(
              title: "Airtel Money",
              subtitle: "Enable Airtel Money.",
              value: enableAirtelMoney,
              onChanged: (v) {
                setState(() {
                  enableAirtelMoney = v;
                });
              },
            ),

            _buildSwitchTile(
              title: "Wallet",
              subtitle: "Enable passenger wallet.",
              value: enableWallet,
              onChanged: (v) {
                setState(() {
                  enableWallet = v;
                });
              },
            ),

            const Divider(height: 40),

            const Text(
              "Driver Payout Settings",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),

            _buildSwitchTile(
              title: "Automatic Driver Payouts",
              subtitle: "Automatically transfer earnings.",
              value: automaticDriverPayouts,
              onChanged: (v) {
                setState(() {
                  automaticDriverPayouts = v;
                });
              },
            ),

            _buildSwitchTile(
              title: "Allow Partial Payouts",
              subtitle: "Drivers can withdraw part of their balance.",
              value: allowPartialPayouts,
              onChanged: (v) {
                setState(() {
                  allowPartialPayouts = v;
                });
              },
            ),

            _buildSwitchTile(
              title: "Enable Refunds",
              subtitle: "Allow passenger refunds.",
              value: enableRefunds,
              onChanged: (v) {
                setState(() {
                  enableRefunds = v;
                });
              },
            ),

            const SizedBox(height: 40),

            ExpansionTile(
              title: const Text("M-Pesa Configuration"),
              leading: const Icon(Icons.phone_android),
              children: [
                TextFormField(
                  controller: mpesaConsumerKeyController,
                  decoration: const InputDecoration(
                    labelText: "Consumer Key",
                    border: OutlineInputBorder(),
                  ),
                ),

                const SizedBox(height: 15),

                _secretField(
                  "Consumer Secret",
                  mpesaConsumerSecretController,
                ),

                const SizedBox(height: 15),

                TextFormField(
                  controller: mpesaShortCodeController,
                  decoration: const InputDecoration(
                    labelText: "Short Code",
                    border: OutlineInputBorder(),
                  ),
                ),

                const SizedBox(height: 15),

                _secretField(
                  "Pass Key",
                  mpesaPassKeyController,
                ),

                const SizedBox(height: 15),

                TextFormField(
                  controller: mpesaCallbackController,
                  decoration: const InputDecoration(
                    labelText: "Callback URL",
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}