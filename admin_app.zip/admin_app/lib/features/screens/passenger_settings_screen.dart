import 'package:flutter/material.dart';

import '../widgets/settings_card.dart';
import '../widgets/settings_header.dart';
import '../widgets/settings_save_bar.dart';


class PassengerSettingsScreen extends StatefulWidget {

  const PassengerSettingsScreen({
    super.key,
  });


  @override
  State<PassengerSettingsScreen> createState() =>
      _PassengerSettingsScreenState();

}



class _PassengerSettingsScreenState
    extends State<PassengerSettingsScreen> {


  final TextEditingController minimumAgeController =
      TextEditingController(
        text: "18",
      );


  final TextEditingController maxDailyRidesController =
      TextEditingController(
        text: "20",
      );


  final TextEditingController referralRewardController =
      TextEditingController(
        text: "100",
      );


  bool requirePhoneVerification = true;

  bool requireEmailVerification = false;

  bool requireProfilePhoto = false;

  bool enablePassengerWallet = true;

  bool enableReferralSystem = true;

  bool enableLoyaltyPoints = true;

  bool allowGuestBooking = false;

  bool enablePassengerBlocking = true;

  bool enableSafetyFeatures = true;



  @override
  void dispose() {

    minimumAgeController.dispose();

    maxDailyRidesController.dispose();

    referralRewardController.dispose();

    super.dispose();

  }



  @override
  Widget build(BuildContext context) {


    return Scaffold(

      body: Column(

        children: [


          SettingsHeader(

            title:
                "Passenger Settings",

            subtitle:
                "Manage passenger accounts, verification and features.",

          ),



          Expanded(

            child: SingleChildScrollView(

              padding:
                  const EdgeInsets.all(24),


              child: Column(

                children: [


                  SettingsCard(

                    title:
                        "Passenger Registration",

                    subtitle:
                        "Control account creation requirements.",


                    child: Column(

                      children: [


                        SwitchListTile(

                          title:
                              const Text(
                                "Phone Verification",
                              ),

                          subtitle:
                              const Text(
                                "Require OTP verification.",
                              ),


                          value:
                              requirePhoneVerification,


                          onChanged:(v){

                            setState(() {

                              requirePhoneVerification=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Email Verification",
                              ),


                          value:
                              requireEmailVerification,


                          onChanged:(v){

                            setState(() {

                              requireEmailVerification=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Profile Photo Required",
                              ),


                          value:
                              requireProfilePhoto,


                          onChanged:(v){

                            setState(() {

                              requireProfilePhoto=v;

                            });

                          },

                        ),



                        TextFormField(

                          controller:
                              minimumAgeController,


                          keyboardType:
                              TextInputType.number,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Minimum Passenger Age",

                            border:
                                OutlineInputBorder(),

                          ),

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Passenger Wallet",

                    subtitle:
                        "Manage passenger balance features.",


                    child: SwitchListTile(

                      title:
                          const Text(
                            "Enable Wallet",
                          ),

                      subtitle:
                          const Text(
                            "Allow passengers to store balance.",
                          ),


                      value:
                          enablePassengerWallet,


                      onChanged:(v){

                        setState(() {

                          enablePassengerWallet=v;

                        });

                      },

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Rewards & Referrals",

                    subtitle:
                        "Manage passenger incentives.",


                    child: Column(

                      children: [


                        SwitchListTile(

                          title:
                              const Text(
                                "Referral System",
                              ),


                          value:
                              enableReferralSystem,


                          onChanged:(v){

                            setState(() {

                              enableReferralSystem=v;

                            });

                          },

                        ),



                        TextFormField(

                          controller:
                              referralRewardController,


                          keyboardType:
                              TextInputType.number,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Referral Reward",

                            border:
                                OutlineInputBorder(),

                            prefixText:
                                "KES ",

                          ),

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Loyalty Points",
                              ),


                          value:
                              enableLoyaltyPoints,


                          onChanged:(v){

                            setState(() {

                              enableLoyaltyPoints=v;

                            });

                          },

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Ride Restrictions",

                    subtitle:
                        "Control passenger usage limits.",


                    child: Column(

                      children: [


                        TextFormField(

                          controller:
                              maxDailyRidesController,


                          keyboardType:
                              TextInputType.number,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Maximum Daily Rides",

                            border:
                                OutlineInputBorder(),

                          ),

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Allow Guest Booking",
                              ),


                          value:
                              allowGuestBooking,


                          onChanged:(v){

                            setState(() {

                              allowGuestBooking=v;

                            });

                          },

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Passenger Safety",

                    child: Column(

                      children: [


                        SwitchListTile(

                          title:
                              const Text(
                                "Safety Features",
                              ),

                          subtitle:
                              const Text(
                                "Emergency contacts and SOS.",
                              ),


                          value:
                              enableSafetyFeatures,


                          onChanged:(v){

                            setState(() {

                              enableSafetyFeatures=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Passenger Blocking",
                              ),

                          subtitle:
                              const Text(
                                "Block abusive accounts.",
                              ),


                          value:
                              enablePassengerBlocking,


                          onChanged:(v){

                            setState(() {

                              enablePassengerBlocking=v;

                            });

                          },

                        ),


                      ],

                    ),

                  ),


                ],

              ),

            ),

          ),



          SettingsSaveBar(

            onSave: (){

              ScaffoldMessenger.of(context)
              .showSnackBar(

                const SnackBar(

                  content:
                      Text(
                        "Passenger settings saved",
                      ),

                ),

              );

            },


            onReset: (){},

          ),

        ],

      ),

    );

  }

}