import 'package:flutter/material.dart';

import '../widgets/settings_card.dart';
import '../widgets/settings_header.dart';
import '../widgets/settings_save_bar.dart';


class DriverSettingsScreen extends StatefulWidget {

  const DriverSettingsScreen({
    super.key,
  });


  @override
  State<DriverSettingsScreen> createState() =>
      _DriverSettingsScreenState();

}



class _DriverSettingsScreenState
    extends State<DriverSettingsScreen> {


  final TextEditingController minimumRatingController =
      TextEditingController(
        text: "4.0",
      );


  final TextEditingController commissionController =
      TextEditingController(
        text: "20",
      );


  final TextEditingController maxOnlineHoursController =
      TextEditingController(
        text: "12",
      );


  bool autoApproveDrivers = false;

  bool requireDrivingLicense = true;

  bool requireVehicleDocuments = true;

  bool requireVehicleInspection = true;

  bool requireProfilePhoto = true;

  bool allowDriverOnlineWithoutRide = true;

  bool allowDriverWallet = true;

  bool automaticSuspension = true;


  String approvalMode = "Manual Approval";



  @override
  void dispose() {

    minimumRatingController.dispose();

    commissionController.dispose();

    maxOnlineHoursController.dispose();

    super.dispose();

  }



  @override
  Widget build(BuildContext context) {


    return Scaffold(

      body: Column(

        children: [


          SettingsHeader(

            title:
                "Driver Settings",

            subtitle:
                "Manage driver registration, verification and earnings.",

          ),



          Expanded(

            child: SingleChildScrollView(

              padding:
                  const EdgeInsets.all(24),


              child: Column(

                children: [


                  SettingsCard(

                    title:
                        "Driver Registration",

                    subtitle:
                        "Control driver onboarding process.",


                    child: Column(

                      children: [


                        DropdownButtonFormField<String>(

                          value:
                              approvalMode,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Approval Mode",

                            border:
                                OutlineInputBorder(),

                          ),


                          items: const [

                            DropdownMenuItem(

                              value:
                                  "Manual Approval",

                              child:
                                  Text(
                                    "Manual Approval",
                                  ),

                            ),


                            DropdownMenuItem(

                              value:
                                  "Automatic Approval",

                              child:
                                  Text(
                                    "Automatic Approval",
                                  ),

                            ),

                          ],


                          onChanged:(value){

                            setState(() {

                              approvalMode=value!;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Auto Approve Drivers",
                              ),

                          value:
                              autoApproveDrivers,


                          onChanged:(v){

                            setState(() {

                              autoApproveDrivers=v;

                            });

                          },

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Verification Requirements",

                    subtitle:
                        "Documents required before activation.",


                    child: Column(

                      children: [


                        SwitchListTile(

                          title:
                              const Text(
                                "Driving License Required",
                              ),

                          value:
                              requireDrivingLicense,


                          onChanged:(v){

                            setState(() {

                              requireDrivingLicense=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Vehicle Documents Required",
                              ),

                          value:
                              requireVehicleDocuments,


                          onChanged:(v){

                            setState(() {

                              requireVehicleDocuments=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Vehicle Inspection Required",
                              ),

                          value:
                              requireVehicleInspection,


                          onChanged:(v){

                            setState(() {

                              requireVehicleInspection=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Profile Photo Required",
                              ),

                          value:
                              requireProfilePhoto,


                          onChanged:(v){

                            setState(() {

                              requireProfilePhoto=v;

                            });

                          },

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Driver Availability",

                    subtitle:
                        "Control online driver behaviour.",


                    child: Column(

                      children: [


                        SwitchListTile(

                          title:
                              const Text(
                                "Allow Online Mode",
                              ),

                          subtitle:
                              const Text(
                                "Drivers can receive rides.",
                              ),

                          value:
                              allowDriverOnlineWithoutRide,


                          onChanged:(v){

                            setState(() {

                              allowDriverOnlineWithoutRide=v;

                            });

                          },

                        ),



                        TextFormField(

                          controller:
                              maxOnlineHoursController,


                          keyboardType:
                              TextInputType.number,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Maximum Online Hours",

                            border:
                                OutlineInputBorder(),

                          ),

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Driver Earnings",

                    subtitle:
                        "Manage commissions and payouts.",


                    child: Column(

                      children: [


                        TextFormField(

                          controller:
                              commissionController,


                          keyboardType:
                              TextInputType.number,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Platform Commission (%)",

                            border:
                                OutlineInputBorder(),

                            prefixIcon:
                                Icon(
                                  Icons.percent,
                                ),

                          ),

                        ),



                        const SizedBox(height:20),



                        SwitchListTile(

                          title:
                              const Text(
                                "Driver Wallet",
                              ),

                          subtitle:
                              const Text(
                                "Allow drivers to track earnings.",
                              ),


                          value:
                              allowDriverWallet,


                          onChanged:(v){

                            setState(() {

                              allowDriverWallet=v;

                            });

                          },

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Driver Rating & Suspension",

                    child: Column(

                      children: [


                        TextFormField(

                          controller:
                              minimumRatingController,


                          keyboardType:
                              TextInputType.number,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Minimum Driver Rating",

                            border:
                                OutlineInputBorder(),

                          ),

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Automatic Suspension",
                              ),

                          subtitle:
                              const Text(
                                "Suspend drivers below rating threshold.",
                              ),


                          value:
                              automaticSuspension,


                          onChanged:(v){

                            setState(() {

                              automaticSuspension=v;

                            });

                          },

                        ),


                      ],

                    ),

                  ),


                ],

              ),

            ),

          ),



          SettingsSaveBar(

            onSave: (){

              ScaffoldMessenger.of(context)
              .showSnackBar(

                const SnackBar(

                  content:
                      Text(
                        "Driver settings saved",
                      ),

                ),

              );

            },


            onReset: (){},


          ),


        ],

      ),

    );

  }

}