import 'package:flutter/material.dart';

import '../widgets/settings_card.dart';
import '../widgets/settings_header.dart';
import '../widgets/settings_save_bar.dart';


class MapSettingsScreen extends StatefulWidget {

  const MapSettingsScreen({
    super.key,
  });

  @override
  State<MapSettingsScreen> createState() =>
      _MapSettingsScreenState();

}


class _MapSettingsScreenState
    extends State<MapSettingsScreen> {


  final TextEditingController googleMapsKeyController =
      TextEditingController();


  final TextEditingController defaultCountryController =
      TextEditingController(
        text: "Kenya",
      );


  final TextEditingController defaultCityController =
      TextEditingController(
        text: "Nairobi",
      );


  String mapProvider = "Google Maps";


  bool liveTracking = true;

  bool highAccuracyLocation = true;

  bool geofencing = true;

  bool routeOptimization = true;


  double trackingInterval = 5;

  double maximumDriverDistance = 20;



  @override
  void dispose() {

    googleMapsKeyController.dispose();

    defaultCountryController.dispose();

    defaultCityController.dispose();

    super.dispose();

  }



  @override
  Widget build(BuildContext context) {


    return Scaffold(

      body: Column(

        children: [


          SettingsHeader(

            title:
                "Maps & Location Settings",

            subtitle:
                "Configure location services and map behaviour.",

          ),



          Expanded(

            child: SingleChildScrollView(

              padding:
                  const EdgeInsets.all(24),


              child: Column(

                children: [


                  SettingsCard(

                    title:
                        "Map Provider",

                    subtitle:
                        "Select your mapping service.",


                    child: Column(

                      children: [


                        DropdownButtonFormField<String>(

                          value:
                              mapProvider,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Map Provider",

                            border:
                                OutlineInputBorder(),

                          ),


                          items: const [

                            DropdownMenuItem(

                              value:
                                  "Google Maps",

                              child:
                                  Text(
                                    "Google Maps",
                                  ),

                            ),


                            DropdownMenuItem(

                              value:
                                  "OpenStreetMap",

                              child:
                                  Text(
                                    "OpenStreetMap",
                                  ),

                            ),

                          ],


                          onChanged:(value){

                            setState(() {

                              mapProvider =
                                  value!;

                            });

                          },

                        ),


                        const SizedBox(height:20),



                        TextFormField(

                          controller:
                              googleMapsKeyController,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Google Maps API Key",

                            border:
                                OutlineInputBorder(),

                            prefixIcon:
                                Icon(
                                  Icons.key,
                                ),

                          ),

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Default Location",

                    subtitle:
                        "Platform default operating area.",


                    child: Column(

                      children: [


                        TextFormField(

                          controller:
                              defaultCountryController,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "Country",

                            border:
                                OutlineInputBorder(),

                          ),

                        ),


                        const SizedBox(height:20),


                        TextFormField(

                          controller:
                              defaultCityController,


                          decoration:
                              const InputDecoration(

                            labelText:
                                "City",

                            border:
                                OutlineInputBorder(),

                          ),

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Tracking Configuration",


                    subtitle:
                        "Control GPS tracking behaviour.",



                    child: Column(

                      children: [


                        SwitchListTile(

                          title:
                              const Text(
                                "Live Driver Tracking",
                              ),

                          value:
                              liveTracking,


                          onChanged:(v){

                            setState(() {

                              liveTracking=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "High Accuracy GPS",
                              ),

                          value:
                              highAccuracyLocation,


                          onChanged:(v){

                            setState(() {

                              highAccuracyLocation=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Geofencing",
                              ),

                          subtitle:
                              const Text(
                                "Restrict operations to allowed areas.",
                              ),


                          value:
                              geofencing,


                          onChanged:(v){

                            setState(() {

                              geofencing=v;

                            });

                          },

                        ),



                        SwitchListTile(

                          title:
                              const Text(
                                "Route Optimization",
                              ),

                          value:
                              routeOptimization,


                          onChanged:(v){

                            setState(() {

                              routeOptimization=v;

                            });

                          },

                        ),


                      ],

                    ),

                  ),



                  const SizedBox(height:24),



                  SettingsCard(

                    title:
                        "Tracking Limits",


                    child: Column(

                      children: [


                        Text(
                          "Location Update Interval: ${trackingInterval.toInt()} seconds",
                        ),


                        Slider(

                          value:
                              trackingInterval,


                          min:
                              1,


                          max:
                              60,


                          divisions:
                              59,


                          onChanged:(v){

                            setState(() {

                              trackingInterval=v;

                            });

                          },

                        ),



                        const SizedBox(height:15),



                        Text(
                          "Maximum Driver Search Radius: ${maximumDriverDistance.toInt()} KM",
                        ),



                        Slider(

                          value:
                              maximumDriverDistance,


                          min:
                              1,


                          max:
                              100,


                          divisions:
                              99,


                          onChanged:(v){

                            setState(() {

                              maximumDriverDistance=v;

                            });

                          },

                        ),


                      ],

                    ),

                  ),


                ],

              ),

            ),

          ),



          SettingsSaveBar(

            onSave: (){


              ScaffoldMessenger.of(context)
              .showSnackBar(

                const SnackBar(

                  content:
                      Text(
                        "Map settings saved",
                      ),

                ),

              );


            },


            onReset: (){},


          ),


        ],

      ),

    );


  }

}