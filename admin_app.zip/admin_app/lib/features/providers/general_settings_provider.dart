import 'package:flutter/material.dart';

import '../models/general_settings_model.dart';
import '../services/general_settings_service.dart';

class GeneralSettingsProvider extends ChangeNotifier {
  final GeneralSettingsService _service = GeneralSettingsService();

  bool _loading = false;
  bool _saving = false;

  String? _error;

  GeneralSettings? _settings;

  bool get loading => _loading;

  bool get saving => _saving;

  String? get error => _error;

  GeneralSettings? get settings => _settings;

  Future<void> loadSettings({String? token}) async {
    try {
      _loading = true;
      _error = null;
      notifyListeners();

      _settings = await _service.getSettings(
        token: token,
      );
    } catch (e) {
      _error = e.toString();
    }

    _loading = false;
    notifyListeners();
  }

  Future<bool> saveSettings({
    required GeneralSettings settings,
    String? token,
  }) async {
    try {
      _saving = true;
      _error = null;

      notifyListeners();

      _settings = await _service.updateSettings(
        settings: settings,
        token: token,
      );

      _saving = false;

      notifyListeners();

      return true;
    } catch (e) {
      _saving = false;
      _error = e.toString();

      notifyListeners();

      return false;
    }
  }

  void updateLocal(
    GeneralSettings value,
  ) {
    _settings = value;
    notifyListeners();
  }
}